<?php
session_start();
require_once 'conexion_dbs.php';
require_once 'auth.php';
verificarStaff();

// --- MANEJO DE SOLICITUD AJAX ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['msg'])) {
    header('Content-Type: text/html; charset=utf-8');
    
    $msg = strtolower(trim($_POST['msg']));
    $respuesta = "";

    try {
        // Saludo
        if (preg_match('/(hola|buenos|buenas|saludos|hey)/i', $msg)) {
            $respuesta = "👋 ¡Hola! Soy tu asistente virtual de gestión de equipos. ¿En qué puedo ayudarte hoy?";
        }
        // Ayuda - Qué puedo preguntar
        elseif (preg_match('/(ayuda|que puedo|puedo preguntar|comandos|opciones)/i', $msg)) {
            $respuesta = "🤖 <strong>¿Qué puedo preguntarle al asistente?</strong><br><br>";
            $respuesta .= "📊 <strong>Estadísticas y Reportes:</strong><ul>";
            $respuesta .= "<li>'Mostrar estadísticas' - Ver resumen completo del sistema</li>";
            $respuesta .= "<li>'Cuántos equipos' - Total de equipos registrados</li>";
            $respuesta .= "<li>'Ver equipos eliminados' - Lista de equipos dados de baja</li>";
            $respuesta .= "</ul>";
            
            $respuesta .= "🔍 <strong>Búsquedas por Estado:</strong><ul>";
            $respuesta .= "<li>'Equipos en espera' - Equipos que están esperando</li>";
            $respuesta .= "<li>'Equipos en revisión' - Equipos siendo revisados</li>";
            $respuesta .= "<li>'Equipos por hacer' - Equipos pendientes de trabajo</li>";
            $respuesta .= "<li>'Equipos en mantenimiento' - Todos los equipos en proceso</li>";
            $respuesta .= "<li>'Equipos activos' - Equipos operativos</li>";
            $respuesta .= "</ul>";
            
            $respuesta .= "🔖 <strong>Búsquedas por Marca:</strong><ul>";
            $respuesta .= "<li>'Equipos marca Dell' - Ver todos los equipos Dell</li>";
            $respuesta .= "<li>'Equipos HP' - Ver todos los equipos HP</li>";
            $respuesta .= "<li>'Equipos Lenovo' - Ver todos los equipos Lenovo</li>";
            $respuesta .= "<li>'Equipos Asus' - Ver todos los equipos Asus</li>";
            $respuesta .= "</ul>";
            
            $respuesta .= "📅 <strong>Calendario y Fechas:</strong><ul>";
            $respuesta .= "<li>'Ver calendario' - Equipos con fechas de salida próximas</li>";
            $respuesta .= "<li>'Equipos por entregar' - Equipos que vencen pronto</li>";
            $respuesta .= "<li>'Fechas de entrega' - Lista de entregas programadas</li>";
            $respuesta .= "</ul>";
            
            $respuesta .= "💰 <strong>Análisis de Costos:</strong><ul>";
            $respuesta .= "<li>'Análisis de costos' - Ver inversión total</li>";
            $respuesta .= "<li>'Costo promedio' - Costo promedio por equipo</li>";
            $respuesta .= "</ul>";
            
            $respuesta .= "<br>💡 <strong>Tip:</strong> Puedes escribir de forma natural, ¡entenderé tu pregunta!";
        }
        // Estadísticas
        elseif (preg_match('/(estad|resumen|mostrar)/i', $msg) && !preg_match('/(eliminado|dell|hp|lenovo|espera|revision)/i', $msg)) {
            // Equipos activos y eliminados
            $equiposActivos = $conexion_local->query("SELECT COUNT(*) AS total FROM equipos")->fetch_assoc()['total'];
            $equiposEliminados = $conexion_local->query("SELECT COUNT(*) AS total FROM equipos_eliminados")->fetch_assoc()['total'];
            $total = $equiposActivos + $equiposEliminados;
            
            // Equipos por estado
            $porEstado = $conexion_local->query("SELECT estado, COUNT(*) as total FROM equipos WHERE estado IS NOT NULL GROUP BY estado");
            
            // Equipos por categoría
            $porCategoria = $conexion_local->query("SELECT categoria_equipo, COUNT(*) as total FROM equipos WHERE categoria_equipo IS NOT NULL GROUP BY categoria_equipo ORDER BY total DESC LIMIT 5");
            
            // Equipos por marca
            $porMarca = $conexion_local->query("SELECT marca, COUNT(*) as total FROM equipos WHERE marca IS NOT NULL GROUP BY marca ORDER BY total DESC LIMIT 5");
            
            // Equipos por tipo de servicio
            $porTipoServicio = $conexion_local->query("SELECT tipo_servicio, COUNT(*) as total FROM equipos WHERE tipo_servicio IS NOT NULL GROUP BY tipo_servicio ORDER BY total DESC");
            
            // Costos
            $costos = $conexion_local->query("SELECT 
                SUM(costo_inicial) as total_inicial, 
                SUM(costo_final) as total_final,
                AVG(costo_inicial) as promedio_inicial,
                COUNT(*) as equipos_con_costo
                FROM equipos WHERE costo_inicial IS NOT NULL AND costo_inicial > 0")->fetch_assoc();
            
            // Equipos ingresados este año
            $equiposEsteAno = $conexion_local->query("SELECT COUNT(*) as total FROM equipos WHERE YEAR(fecha_ingreso) = YEAR(CURDATE())")->fetch_assoc()['total'];
            
            // Motivos de eliminación
            $motivosEliminacion = $conexion_local->query("SELECT motivo_eliminacion, COUNT(*) as total FROM equipos_eliminados WHERE motivo_eliminacion IS NOT NULL AND motivo_eliminacion != '' GROUP BY motivo_eliminacion ORDER BY total DESC LIMIT 5");
            
            // Equipos eliminados este año
            $eliminadosEsteAno = $conexion_local->query("SELECT COUNT(*) as total FROM equipos_eliminados WHERE YEAR(fecha_eliminacion) = YEAR(CURDATE())")->fetch_assoc()['total'];
            
            // Construir respuesta
            $respuesta = "📊 <strong>ESTADÍSTICAS COMPLETAS DEL SISTEMA</strong><br><br>";
            
            // Resumen general
            $respuesta .= "📈 <strong>Resumen General:</strong><ul>";
            $respuesta .= "<li>💻 <b>Total de equipos:</b> $total</li>";
            $respuesta .= "<li>✅ Equipos activos: <b>$equiposActivos</b> (" . ($total > 0 ? round(($equiposActivos/$total)*100, 1) : 0) . "%)</li>";
            $respuesta .= "<li>🗑️ Equipos eliminados: <b>$equiposEliminados</b> (" . ($total > 0 ? round(($equiposEliminados/$total)*100, 1) : 0) . "%)</li>";
            $respuesta .= "<li>📅 Equipos ingresados este año: <b>$equiposEsteAno</b></li>";
            $respuesta .= "<li>🗓️ Equipos eliminados este año: <b>$eliminadosEsteAno</b></li>";
            $respuesta .= "</ul><br>";
            
            // Por estado
            if ($porEstado && $porEstado->num_rows > 0) {
                $respuesta .= "📌 <strong>Equipos por Estado:</strong><ul>";
                while ($row = $porEstado->fetch_assoc()) {
                    $estado = $row['estado'] ?? 'sin_estado';
                    $emoji = '📋';
                    if (stripos($estado, 'espera') !== false) $emoji = '⏳';
                    elseif (stripos($estado, 'revision') !== false) $emoji = '🔍';
                    elseif (stripos($estado, 'hacer') !== false || stripos($estado, 'pendiente') !== false) $emoji = '📝';
                    elseif (stripos($estado, 'activo') !== false || stripos($estado, 'operativo') !== false) $emoji = '✅';
                    elseif (stripos($estado, 'reparacion') !== false || stripos($estado, 'mantenimiento') !== false) $emoji = '🔧';
                    elseif (stripos($estado, 'inactivo') !== false || stripos($estado, 'fuera') !== false) $emoji = '⚠️';
                    
                    $respuesta .= "<li>$emoji " . ucfirst(str_replace('_', ' ', $estado)) . ": <b>{$row['total']}</b></li>";
                }
                $respuesta .= "</ul><br>";
            }
            
            // Por categoría
            if ($porCategoria && $porCategoria->num_rows > 0) {
                $respuesta .= "🏷️ <strong>Top Categorías:</strong><ul>";
                while ($row = $porCategoria->fetch_assoc()) {
                    $cat = $row['categoria_equipo'] ?? 'Sin categoría';
                    $respuesta .= "<li>" . ucfirst($cat) . ": <b>{$row['total']}</b> equipos</li>";
                }
                $respuesta .= "</ul><br>";
            }
            
            // Por marca
            if ($porMarca && $porMarca->num_rows > 0) {
                $respuesta .= "🔖 <strong>Top Marcas:</strong><ul>";
                while ($row = $porMarca->fetch_assoc()) {
                    $respuesta .= "<li>{$row['marca']}: <b>{$row['total']}</b> equipos</li>";
                }
                $respuesta .= "</ul><br>";
            }
            
            // Por tipo de servicio
            if ($porTipoServicio && $porTipoServicio->num_rows > 0) {
                $respuesta .= "⚙️ <strong>Equipos por Tipo de Servicio:</strong><ul>";
                while ($row = $porTipoServicio->fetch_assoc()) {
                    $tipo = ucfirst($row['tipo_servicio']);
                    $respuesta .= "<li>$tipo: <b>{$row['total']}</b> equipos</li>";
                }
                $respuesta .= "</ul><br>";
            }
            
            // Costos
            if ($costos && $costos['equipos_con_costo'] > 0) {
                $respuesta .= "💰 <strong>Análisis de Costos:</strong><ul>";
                $respuesta .= "<li>Inversión total inicial: <b>$" . number_format($costos['total_inicial'], 2) . "</b></li>";
                if ($costos['total_final'] > 0) {
                    $respuesta .= "<li>Costo total final: <b>$" . number_format($costos['total_final'], 2) . "</b></li>";
                    $respuesta .= "<li>Diferencia de costos: <b>$" . number_format($costos['total_final'] - $costos['total_inicial'], 2) . "</b></li>";
                }
                $respuesta .= "<li>Costo promedio por equipo: <b>$" . number_format($costos['promedio_inicial'], 2) . "</b></li>";
                $respuesta .= "<li>Equipos con registro de costo: <b>{$costos['equipos_con_costo']}</b></li>";
                $respuesta .= "</ul><br>";
            }
            
            // Motivos de eliminación
            if ($motivosEliminacion && $motivosEliminacion->num_rows > 0) {
                $respuesta .= "📋 <strong>Principales Motivos de Eliminación:</strong><ul>";
                while ($row = $motivosEliminacion->fetch_assoc()) {
                    $motivo = ucfirst($row['motivo_eliminacion']);
                    $respuesta .= "<li>$motivo: <b>{$row['total']}</b> equipos</li>";
                }
                $respuesta .= "</ul>";
            }
        }
        // Equipos por estado (en espera, revisión, por hacer, mantenimiento)
        elseif (preg_match('/(espera|revision|por hacer|pendiente|mantenimiento|proceso)/i', $msg)) {
            $estadoBuscar = '';
            $emoji = '📋';
            $titulo = 'Equipos';
            
            if (preg_match('/espera/i', $msg)) {
                $estadoBuscar = 'en_espera';
                $emoji = '⏳';
                $titulo = 'Equipos en Espera';
            } elseif (preg_match('/revision|revisando/i', $msg)) {
                $estadoBuscar = 'en_revision';
                $emoji = '🔍';
                $titulo = 'Equipos en Revisión';
            } elseif (preg_match('/por hacer|pendiente/i', $msg)) {
                $estadoBuscar = 'por_hacer';
                $emoji = '📝';
                $titulo = 'Equipos Por Hacer';
            } elseif (preg_match('/mantenimiento|proceso/i', $msg)) {
                // Mostrar todos los estados de trabajo
                $res = $conexion_local->query("SELECT marca, equipo, serie, estado, fecha_ingreso, fecha_salida 
                    FROM equipos 
                    WHERE estado IN ('en_espera', 'en_revision', 'por_hacer', 'en_reparacion') 
                    ORDER BY fecha_salida ASC, fecha_ingreso DESC 
                    LIMIT 20");
                    
                if ($res && $res->num_rows > 0) {
                    $respuesta = "🔧 <strong>Equipos en Proceso de Mantenimiento:</strong> ({$res->num_rows} equipos)<br><br>";
                    $respuesta .= "<ul>";
                    while ($r = $res->fetch_assoc()) {
                        $estadoEmoji = '📋';
                        if ($r['estado'] == 'en_espera') $estadoEmoji = '⏳';
                        elseif ($r['estado'] == 'en_revision') $estadoEmoji = '🔍';
                        elseif ($r['estado'] == 'por_hacer') $estadoEmoji = '📝';
                        elseif ($r['estado'] == 'en_reparacion') $estadoEmoji = '🔧';
                        
                        $estadoNombre = ucfirst(str_replace('_', ' ', $r['estado']));
                        $fechaSalida = $r['fecha_salida'] ? " - <b>Entrega: {$r['fecha_salida']}</b>" : "";
                        
                        $respuesta .= "<li>$estadoEmoji <b>{$r['marca']} {$r['equipo']}</b> (Serie: {$r['serie']})<br>";
                        $respuesta .= "&nbsp;&nbsp;&nbsp;Estado: $estadoNombre | Ingreso: {$r['fecha_ingreso']}$fechaSalida</li>";
                    }
                    $respuesta .= "</ul>";
                } else {
                    $respuesta = "✅ No hay equipos en proceso de mantenimiento en este momento.";
                }
                echo $respuesta;
                exit;
            }
            
            if ($estadoBuscar != '') {
                $res = $conexion_local->query("SELECT marca, equipo, serie, fecha_ingreso, fecha_salida, observacion 
                    FROM equipos 
                    WHERE estado = '$estadoBuscar' 
                    ORDER BY fecha_salida ASC, fecha_ingreso DESC 
                    LIMIT 15");
                    
                if ($res && $res->num_rows > 0) {
                    $respuesta = "$emoji <strong>$titulo:</strong> ({$res->num_rows} equipos)<br><br><ul>";
                    while ($r = $res->fetch_assoc()) {
                        $fechaSalida = $r['fecha_salida'] ? "<br>&nbsp;&nbsp;&nbsp;📅 <b>Fecha de entrega:</b> {$r['fecha_salida']}" : "";
                        $obs = !empty($r['observacion']) ? "<br>&nbsp;&nbsp;&nbsp;📝 " . substr($r['observacion'], 0, 50) . "..." : "";
                        
                        $respuesta .= "<li><b>{$r['marca']} {$r['equipo']}</b> (Serie: {$r['serie']})<br>";
                        $respuesta .= "&nbsp;&nbsp;&nbsp;📆 Ingreso: {$r['fecha_ingreso']}$fechaSalida$obs</li>";
                    }
                    $respuesta .= "</ul>";
                } else {
                    $respuesta = "✅ No hay equipos $titulo en este momento.";
                }
            }
        }
        // Calendario - Fechas de entrega próximas
        elseif (preg_match('/(calendario|fecha|entrega|entregar|vence|proximo)/i', $msg)) {
            $hoy = date('Y-m-d');
            $proximosDias = date('Y-m-d', strtotime('+15 days'));
            
            // Equipos que vencen en los próximos 15 días
            $res = $conexion_local->query("SELECT marca, equipo, serie, estado, fecha_salida, fecha_ingreso, 
                DATEDIFF(fecha_salida, CURDATE()) as dias_restantes
                FROM equipos 
                WHERE fecha_salida IS NOT NULL 
                AND fecha_salida BETWEEN '$hoy' AND '$proximosDias'
                ORDER BY fecha_salida ASC 
                LIMIT 20");
            
            // Equipos que ya vencieron
            $vencidos = $conexion_local->query("SELECT marca, equipo, serie, estado, fecha_salida, 
                DATEDIFF(CURDATE(), fecha_salida) as dias_vencidos
                FROM equipos 
                WHERE fecha_salida IS NOT NULL 
                AND fecha_salida < '$hoy'
                AND estado != 'entregado'
                ORDER BY fecha_salida ASC 
                LIMIT 10");
            
            $respuesta = "📅 <strong>CALENDARIO DE ENTREGAS</strong><br><br>";
            
            // Equipos vencidos
            if ($vencidos && $vencidos->num_rows > 0) {
                $respuesta .= "🚨 <strong>ATENCIÓN - Equipos con fecha de entrega vencida:</strong> ({$vencidos->num_rows})<br><ul>";
                while ($r = $vencidos->fetch_assoc()) {
                    $respuesta .= "<li><b style='color:red;'>{$r['marca']} {$r['equipo']}</b> (Serie: {$r['serie']})<br>";
                    $respuesta .= "&nbsp;&nbsp;&nbsp;❌ <b>Venció hace {$r['dias_vencidos']} días</b> ({$r['fecha_salida']})<br>";
                    $respuesta .= "&nbsp;&nbsp;&nbsp;Estado: " . ucfirst(str_replace('_', ' ', $r['estado'])) . "</li>";
                }
                $respuesta .= "</ul><br>";
            }
            
            // Próximas entregas
            if ($res && $res->num_rows > 0) {
                $respuesta .= "⏰ <strong>Próximas entregas (15 días):</strong><br><ul>";
                while ($r = $res->fetch_assoc()) {
                    $urgencia = $r['dias_restantes'] <= 3 ? '🔴 URGENTE' : ($r['dias_restantes'] <= 7 ? '🟡 Pronto' : '🟢');
                    $respuesta .= "<li>$urgencia <b>{$r['marca']} {$r['equipo']}</b> (Serie: {$r['serie']})<br>";
                    $respuesta .= "&nbsp;&nbsp;&nbsp;📆 Entrega: <b>{$r['fecha_salida']}</b> (en {$r['dias_restantes']} días)<br>";
                    $respuesta .= "&nbsp;&nbsp;&nbsp;Estado: " . ucfirst(str_replace('_', ' ', $r['estado'])) . "</li>";
                }
                $respuesta .= "</ul>";
            } else {
                $respuesta .= "✅ No hay entregas programadas para los próximos 15 días.";
            }
        }
        // Equipos eliminados
        elseif (preg_match('/(eliminado|eliminados|borrado|baja)/i', $msg)) {
            $res = $conexion_local->query("SELECT marca, nombre_equipo, serie, fecha_eliminacion, motivo_eliminacion, eliminado_por 
                FROM equipos_eliminados 
                ORDER BY fecha_eliminacion DESC 
                LIMIT 10");
            if ($res && $res->num_rows > 0) {
                $respuesta = "🗑️ <strong>Últimos equipos eliminados:</strong> ({$res->num_rows})<br><br><ul>";
                while ($r = $res->fetch_assoc()) {
                    $motivo = !empty($r['motivo_eliminacion']) ? "<br>&nbsp;&nbsp;&nbsp;📋 Motivo: {$r['motivo_eliminacion']}" : "";
                    $respuesta .= "<li><b>{$r['marca']} {$r['nombre_equipo']}</b> (Serie: {$r['serie']})<br>";
                    $respuesta .= "&nbsp;&nbsp;&nbsp;📅 Eliminado: {$r['fecha_eliminacion']} por {$r['eliminado_por']}$motivo</li>";
                }
                $respuesta .= "</ul>";
            } else {
                $respuesta = "✅ No hay equipos eliminados recientemente.";
            }
        }
        // Búsqueda por marca
        elseif (preg_match('/(dell|hp|lenovo|asus|apple|cisco|marca)/i', $msg)) {
            $palabra = "";
            if (preg_match('/dell/i', $msg)) $palabra = "Dell";
            elseif (preg_match('/hp/i', $msg)) $palabra = "HP";
            elseif (preg_match('/lenovo/i', $msg)) $palabra = "Lenovo";
            elseif (preg_match('/asus/i', $msg)) $palabra = "Asus";
            elseif (preg_match('/apple/i', $msg)) $palabra = "Apple";
            elseif (preg_match('/cisco/i', $msg)) $palabra = "Cisco";
            
            if ($palabra != "") {
                $res = $conexion_local->query("SELECT marca, equipo, serie, estado FROM equipos WHERE marca LIKE '%$palabra%' LIMIT 15");
                if ($res && $res->num_rows > 0) {
                    $respuesta = "🔍 <strong>Equipos de la marca $palabra:</strong> (Total: {$res->num_rows})<ul>";
                    while ($r = $res->fetch_assoc()) {
                        $estadoEmoji = stripos($r['estado'], 'espera') !== false ? '⏳' : '📋';
                        $respuesta .= "<li>$estadoEmoji <b>{$r['marca']} {$r['equipo']}</b> - Serie: {$r['serie']} | Estado: " . ucfirst(str_replace('_', ' ', $r['estado'])) . "</li>";
                    }
                    $respuesta .= "</ul>";
                } else {
                    $respuesta = "❌ No se encontraron equipos de la marca $palabra en el sistema.";
                }
            } else {
                $respuesta = "🔢 Puedo buscar equipos por marca. Intenta con:<br>• 'Equipos marca Dell'<br>• 'Mostrar equipos HP'<br>• 'Ver Lenovo'<br>• 'Buscar Asus'";
            }
        }
        // Equipos en general
        elseif (preg_match('/(equipos|cuantos|total|lista|cantidad)/i', $msg)) {
            $equiposActivos = $conexion_local->query("SELECT COUNT(*) AS total FROM equipos")->fetch_assoc()['total'];
            $ultimosEquipos = $conexion_local->query("SELECT marca, equipo, serie, fecha_ingreso, estado 
                FROM equipos 
                ORDER BY fecha_ingreso DESC 
                LIMIT 8");
            
            $respuesta = "💻 <strong>Equipos en el sistema:</strong> <b>$equiposActivos</b> registrados<br><br><strong>Últimos equipos ingresados:</strong><ul>";
            while ($eq = $ultimosEquipos->fetch_assoc()) {
                $estadoEmoji = '📋';
                if (stripos($eq['estado'], 'espera') !== false) $estadoEmoji = '⏳';
                elseif (stripos($eq['estado'], 'revision') !== false) $estadoEmoji = '🔍';
                
                $respuesta .= "<li>$estadoEmoji <b>{$eq['marca']} {$eq['equipo']}</b> (Serie: {$eq['serie']})<br>";
                $respuesta .= "&nbsp;&nbsp;&nbsp;Ingreso: {$eq['fecha_ingreso']} | Estado: " . ucfirst(str_replace('_', ' ', $eq['estado'])) . "</li>";
            }
            $respuesta .= "</ul>";
        }
        // Respuesta por defecto
        else {
            $respuesta = "🤖 No entiendo tu pregunta. Aquí tienes algunas sugerencias:<br><br>";
            $respuesta .= "<strong>📊 Consultas disponibles:</strong><ul>";
            $respuesta .= "<li><b>'Mostrar estadísticas'</b> - Ver resumen general completo</li>";
            $respuesta .= "<li><b>'Equipos en espera'</b> - Ver equipos esperando atención</li>";
            $respuesta .= "<li><b>'Equipos en revisión'</b> - Ver equipos siendo revisados</li>";
            $respuesta .= "<li><b>'Ver calendario'</b> - Fechas de entrega próximas</li>";
            $respuesta .= "<li><b>'Equipos marca Dell'</b> - Buscar por marca</li>";
            $respuesta .= "<li><b>'Cuántos equipos'</b> - Total de equipos</li>";
            $respuesta .= "<li><b>'Ver equipos eliminados'</b> - Equipos dados de baja</li>";
            $respuesta .= "</ul>";
            $respuesta .= "💡 <strong>Tip:</strong> Escribe '<b>ayuda</b>' para ver todas las opciones disponibles.";
        }

    } catch (Exception $e) {
        $respuesta = "❌ Error al procesar tu consulta: " . $e->getMessage();
    }

    echo $respuesta;
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asistente Virtual - Sistema de Equipos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/3ee79e7c0a.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Poppins', sans-serif;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .chat-container {
            width: 95%;
            max-width: 850px;
            height: 90vh;
            background: white;
            border-radius: 20px;
            box-shadow: 0 15px 50px rgba(0,0,0,0.3);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        .chat-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .chat-header h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
        }
        .chat-header p {
            margin: 5px 0 0 0;
            font-size: 14px;
            opacity: 0.9;
        }
        .chat-messages {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background: #f5f7fb;
            display: flex;
            flex-direction: column;
        }
        .message {
            display: flex;
            margin-bottom: 15px;
            animation: fadeIn 0.3s ease-in;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .message.user {
            justify-content: flex-end;
        }
        .message.bot {
            justify-content: flex-start;
        }
        .message-bubble {
            max-width: 75%;
            padding: 12px 18px;
            border-radius: 18px;
            word-wrap: break-word;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .message.user .message-bubble {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-bottom-right-radius: 4px;
        }
        .message.bot .message-bubble {
            background: white;
            color: #333;
            border-bottom-left-radius: 4px;
            border: 1px solid #e0e0e0;
        }
        .message-bubble ul {
            margin: 8px 0 0 0;
            padding-left: 20px;
        }
        .message-bubble li {
            margin: 5px 0;
            line-height: 1.5;
        }
        .chat-input-area {
            padding: 20px;
            background: white;
            border-top: 1px solid #e0e0e0;
        }
        .suggestions {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-bottom: 15px;
            justify-content: center;
        }
        .suggestion-btn {
            background: #f0f0f0;
            border: 1px solid #d0d0d0;
            border-radius: 20px;
            padding: 8px 16px;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.3s;
            color: #555;
        }
        .suggestion-btn:hover {
            background: #667eea;
            color: white;
            border-color: #667eea;
            transform: translateY(-2px);
        }
        .input-group {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        .input-group input {
            flex: 1;
            border: 2px solid #e0e0e0;
            border-radius: 25px;
            padding: 12px 20px;
            font-size: 15px;
            transition: all 0.3s;
        }
        .input-group input:focus {
            outline: none;
            border-color: #667eea;
        }
        .input-group input:disabled {
            background: #f5f5f5;
            cursor: not-allowed;
        }
        .send-btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            cursor: pointer;
            font-size: 18px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .send-btn:hover:not(:disabled) {
            transform: scale(1.1);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        .send-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        .back-btn {
            background: #ff6b6b;
            color: white;
            border: none;
            border-radius: 25px;
            padding: 10px 20px;
            cursor: pointer;
            font-size: 14px;
            margin-top: 10px;
            width: 100%;
            transition: all 0.3s;
        }
        .back-btn:hover {
            background: #ee5a52;
            transform: translateY(-2px);
        }
        .welcome-message {
            text-align: center;
            padding: 40px 20px;
            color: #999;
        }
        .welcome-message i {
            font-size: 60px;
            margin-bottom: 20px;
            color: #667eea;
        }
        .welcome-message h3 {
            color: #333;
            margin-bottom: 10px;
        }
        .typing-indicator {
            display: none;
            align-items: center;
            gap: 5px;
            padding: 10px 15px;
            background: white;
            border-radius: 18px;
            border-bottom-left-radius: 4px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            max-width: 70px;
            margin-bottom: 15px;
        }
        .typing-indicator span {
            width: 8px;
            height: 8px;
            background: #667eea;
            border-radius: 50%;
            animation: typing 1.4s infinite;
        }
        .typing-indicator span:nth-child(2) {
            animation-delay: 0.2s;
        }
        .typing-indicator span:nth-child(3) {
            animation-delay: 0.4s;
        }
        @keyframes typing {
            0%, 60%, 100% { transform: translateY(0); }
            30% { transform: translateY(-10px); }
        }
        ::-webkit-scrollbar {
            width: 6px;
        }
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        ::-webkit-scrollbar-thumb {
            background: #667eea;
            border-radius: 10px;
        }
    </style>
</head>
<body>

<div class="chat-container">
    <div class="chat-header">
        <h2><i class="fa-solid fa-robot"></i> Asistente Virtual</h2>
        <p>Sistema de Gestión de Equipos</p>
    </div>
    
    <div class="chat-messages" id="chatMessages">
        <div class="welcome-message">
            <i class="fa-solid fa-comments"></i>
            <h3>¡Hola! 👋</h3>
            <p>Soy tu asistente virtual. ¿En qué puedo ayudarte hoy?</p>
            <p style="font-size: 12px; margin-top: 10px;">💡 Escribe "ayuda" para ver todas las opciones</p>
        </div>
        <div class="typing-indicator" id="typingIndicator">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
    
    <div class="chat-input-area">
        <div class="suggestions">
            <button class="suggestion-btn" onclick="sendPredefinedMessage('mostrar estadísticas')">📊 Estadísticas</button>
            <button class="suggestion-btn" onclick="sendPredefinedMessage('equipos en mantenimiento')">🔧 Mantenimiento</button>
            <button class="suggestion-btn" onclick="sendPredefinedMessage('ver calendario')">📅 Calendario</button>
            <button class="suggestion-btn" onclick="sendPredefinedMessage('equipos en espera')">⏳ En Espera</button>
        </div>
        
        <div class="input-group">
            <input type="text" id="userInput" placeholder="Escribe tu pregunta aquí..." autofocus>
            <button class="send-btn" id="sendBtn">
                <i class="fa-solid fa-paper-plane"></i>
            </button>
        </div>
        
        <button class="back-btn" onclick="window.location.href='index.php'">
            <i class="fa-solid fa-arrow-left"></i> Volver al Inicio
        </button>
    </div>
</div>

<script>
let isProcessing = false;

document.getElementById("sendBtn").addEventListener("click", sendMessage);
document.getElementById("userInput").addEventListener("keypress", function(e){
    if(e.key === "Enter" && !isProcessing){ 
        sendMessage(); 
    }
});

function sendMessage() {
    if (isProcessing) return;
    
    let input = document.getElementById("userInput");
    let sendBtn = document.getElementById("sendBtn");
    let message = input.value.trim();
    
    if(message === "") return;

    const welcomeMsg = document.querySelector('.welcome-message');
    if (welcomeMsg) {
        welcomeMsg.remove();
    }

    isProcessing = true;
    appendMessage("user", message);
    input.value = "";
    input.disabled = true;
    sendBtn.disabled = true;

    showTypingIndicator();

    const formData = new FormData();
    formData.append('msg', message);

    fetch(window.location.href, {
        method: "POST",
        body: formData
    })
    .then(res => {
        if (!res.ok) {
            throw new Error('Error HTTP: ' + res.status);
        }
        return res.text();
    })
    .then(data => {
        hideTypingIndicator();
        setTimeout(() => {
            if (data && data.trim() !== '') {
                appendMessage("bot", data);
            } else {
                appendMessage("bot", "❌ No recibí una respuesta válida del servidor.");
            }
            isProcessing = false;
            input.disabled = false;
            sendBtn.disabled = false;
            input.focus();
        }, 500);
    })
    .catch(error => {
        console.error('Error completo:', error);
        hideTypingIndicator();
        appendMessage("bot", "❌ Error de conexión. Verifica que la base de datos esté funcionando correctamente.");
        isProcessing = false;
        input.disabled = false;
        sendBtn.disabled = false;
        input.focus();
    });
}

function appendMessage(sender, text) {
    let chatMessages = document.getElementById("chatMessages");
    let messageDiv = document.createElement("div");
    messageDiv.classList.add("message", sender);
    
    let bubbleDiv = document.createElement("div");
    bubbleDiv.classList.add("message-bubble");
    bubbleDiv.innerHTML = text;
    
    messageDiv.appendChild(bubbleDiv);
    
    const typingIndicator = document.getElementById("typingIndicator");
    chatMessages.insertBefore(messageDiv, typingIndicator);
    
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function showTypingIndicator() {
    document.getElementById("typingIndicator").style.display = "flex";
    document.getElementById("chatMessages").scrollTop = document.getElementById("chatMessages").scrollHeight;
}

function hideTypingIndicator() {
    document.getElementById("typingIndicator").style.display = "none";
}

function sendPredefinedMessage(message) {
    if (!isProcessing) {
        document.getElementById("userInput").value = message;
        sendMessage();
    }
}
</script>

</body>
</html>