<?php
// includes/header.php
require_once 'auth.php';

$usuario_actual = obtenerUsuarioActual();

// Verificar si el usuario está logueado
if (!$usuario_actual) {
    header("Location: login.php");
    exit;
}

// Función para verificar acceso a la página de Equipos
function verificarAccesoEquipos($usuario) {
    if ($usuario['rol'] !== 'admin') {
        echo '<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Permiso Denegado</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
  <div class="container my-5">
    <div class="card border-danger shadow text-center p-4">
      <h2 class="text-danger mb-3"><i class="fas fa-ban"></i> Permiso Denegado</h2>
      <p>No tienes permisos para acceder a esta sección.</p>
      <a href="index.php" class="btn btn-primary mt-3"><i class="fas fa-home me-1"></i> Volver al Inicio</a>
    </div>
  </div>
</body>
</html>';
        exit;
    }
}

// Verificar acceso si estamos en equipos.php
if (basename($_SERVER['PHP_SELF']) === 'equipos.php') {
    verificarAccesoEquipos($usuario_actual);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sistema NIBARRA</title>
  <link rel="stylesheet" href="css/estilo.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    /* Header estilo moderno */
    .navbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0.5rem 1rem;
        background: linear-gradient(135deg, #007bff, #0056b3);
        color: white;
        border-radius: 0 0 10px 10px;
        box-shadow: 0 3px 10px rgba(0,0,0,0.2);
    }

    .navbar .logo-link {
        font-size: 1.5rem;
        font-weight: bold;
        text-decoration: none;
        color: white;
    }

    .menu a {
        margin: 0 0.8rem;
        color: white;
        text-decoration: none;
        font-weight: 500;
        transition: 0.3s;
    }

    .menu a:hover {
        text-decoration: underline;
        color: #ffd700;
    }

    .user-info {
        display: flex;
        align-items: center;
        gap: 0.8rem;
    }

    .user-info .user-name {
        font-weight: bold;
    }

    .user-info .user-role {
        font-size: 0.85rem;
        color: #f0f0f0;
    }

    .logout-btn {
        background: #dc3545;
        border: none;
        padding: 5px 12px;
        border-radius: 5px;
        color: white;
        font-size: 0.9rem;
        transition: 0.3s;
    }

    .logout-btn:hover {
        background: #c82333;
        text-decoration: none;
        color: white;
    }

    /* 🔹 Estilo del botón Chat-Bot y Facturas */
    .chatbot-link {
        background: #00c3ff;
        border-radius: 5px;
        padding: 6px 14px;
        color: white !important;
        font-size: 0.9rem;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all 0.3s;
        text-decoration: none;
    }

    .chatbot-link:hover {
        background: #0099cc;
        box-shadow: 0 0 10px rgba(0,195,255,0.5);
        transform: translateY(-2px);
        color: white !important;
    }

    .chatbot-badge {
        background: #ffd700;
        color: #000;
        font-size: 0.7rem;
        padding: 2px 6px;
        border-radius: 4px;
        font-weight: bold;
    }
  </style>
</head>
<body class="no-select">
  <header class="navbar">
    <div class="logo">
      <a href="index.php" class="logo-link">🧰 NIBARRA</a>
    </div>

    <nav class="menu">
      <a href="index.php">Inicio</a>
      <a href="mantenimiento.php">Mantenimientos</a>
      <?php if ($usuario_actual['rol'] === 'admin'): ?>
        <a href="equipos.php">Equipos</a>
      <?php endif; ?>
      <a href="calendario.php">Calendario</a>

      <!-- 🔹 Botón Chat-Bot -->
      <a href="asistente_virtual.php" class="chatbot-link">
        🤖 Chat-Bot
        <span class="chatbot-badge">AI</span>
      </a>

      <!-- 🔹 Botón Facturas -->
      <a href="facturas.php" class="chatbot-link">
        📑 Facturas
        <span class="chatbot-badge"></span>
      </a>
    </nav>

    <div class="user-info">
      <i class="fas fa-user-circle fa-lg"></i>
      <div>
        <div class="user-name"><?php echo htmlspecialchars($usuario_actual['nombre_completo']); ?></div>
        <div class="user-role"><?php echo ucfirst($usuario_actual['rol']); ?></div>
      </div>
      <a href="logout.php" class="logout-btn"
         onclick="return confirm('¿Estás seguro de que deseas cerrar sesión?')">
        <i class="fas fa-sign-out-alt"></i>
      </a>
    </div>
  </header>

  <main class="contenido">
