<?php
// includes/footer.php
?>
</main>

<footer class="footer">
    <p>© 2025 NIBARRA | Desarrollado por Carlos Miranda</p>
</footer>
<script src="scripts/protect.js"></script>

</body>
</html>
