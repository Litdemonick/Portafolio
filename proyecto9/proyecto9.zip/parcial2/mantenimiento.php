<?php
session_start();
require_once 'conexion_dbs.php';
require_once 'auth.php';
verificarStaff();

// Obtener datos desde la base de datos
$sql = "SELECT * FROM equipos ORDER BY fecha_ingreso DESC";
$resultado = $conexion_local->query($sql);

$equipos = [];
if ($resultado && $resultado->num_rows > 0) {
    while ($row = $resultado->fetch_assoc()) {
        $equipos[] = $row;
    }
}

include 'includes/header.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gestión de Mantenimientos</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root {
    --bg-primary: #4d4c4cff;
    --bg-secondary: #1e1e1e;
    --bg-tertiary: #979494ff;
    --text-primary: #2e791cff;
    --text-secondary: #b0b0b0;
    --border-color: #333;
    --accent-blue: #00b4d8;
    --accent-blue-hover: #0096b8;
}

body {
    background: var(--bg-primary);
    color: var(--text-primary);
}

.kanban-column {
    min-height: 600px;
    background-color: var(--bg-secondary);
    border-radius: 12px;
    padding: 15px;
    border: 1px solid var(--border-color);
}

.kanban-header {
    background: linear-gradient(135deg, var(--bg-secondary) 0%, #2a2a2a 100%);
    padding: 15px;
    border-radius: 10px;
    margin-bottom: 15px;
    border: 1px solid var(--border-color);
}

.task-card {
    background: var(--bg-secondary);
    border-left: 4px solid;
    margin-bottom: 15px;
    transition: all 0.3s;
    cursor: pointer;
    border: 1px solid var(--border-color);
    border-radius: 8px;
}

.task-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(0, 180, 216, 0.3);
}

.task-predictivo { border-left-color: #28a745; }
.task-preventivo { border-left-color: #ffc107; }
.task-correctivo { border-left-color: #dc3545; }

.progress { 
    height: 10px; 
    background: #2a2a2a;
    border-radius: 5px;
}

.card-title {
    color: var(--text-primary);
    font-weight: 600;
}

.text-muted {
    color: var(--text-secondary) !important;
}
#searchInput::placeholder {
    color: #b0b0b0; /* gris claro o el color que desees */
    opacity: 1; /* para que no se vea muy tenue */
}

/* Panel lateral desplegable */
.side-panel {
    position: fixed;
    top: 0;
    right: -500px;
    width: 500px;
    height: 100vh;
    background: var(--bg-secondary);
    box-shadow: -5px 0 25px rgba(240, 240, 240, 0.5);
    transition: right 0.4s ease;
    z-index: 9999;
    overflow-y: auto;
    border-left: 2px solid var(--accent-blue);
}

.side-panel.active {
    right: 0;
}

.side-panel-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100vh;
    background: rgba(0, 0, 0, 0.7);
    opacity: 0;
    visibility: hidden;
    transition: all 0.4s ease;
    z-index: 9998;
}

.side-panel-overlay.active {
    opacity: 1;
    visibility: visible;
}

.side-panel-header {
    background: linear-gradient(135deg, var(--accent-blue) 0%, var(--accent-blue-hover) 100%);
    padding: 20px;
    position: sticky;
    top: 0;
    z-index: 10;
}

.side-panel-body {
    padding: 20px;
}

.panel-card {
    background: #2a2a2a;
    border-radius: 10px;
    padding: 15px;
    margin-bottom: 15px;
    border-left: 4px solid;
    transition: all 0.2s;
    cursor: pointer;
}

.panel-card:hover {
    transform: translateX(-5px);
    box-shadow: 0 4px 12px rgba(0, 180, 216, 0.3);
}

.filter-section {
    background: #918484ff;
    border-radius: 10px;
    padding: 15px;
    margin-bottom: 20px;
}

.filter-btn {
    width: 100%;
    text-align: left;
    margin-bottom: 8px;
    border: 1px solid var(--border-color);
    transition: all 0.2s;
}

.filter-btn:hover {
    border-color: var(--accent-blue);
    transform: translateX(5px);
}

.filter-btn.active {
    background: var(--accent-blue);
    border-color: var(--accent-blue);
    color: white;
}

.search-box {
    position: relative;
    margin-bottom: 20px;
}

.search-box input {
    background: #2a2a2a;
    border: 1px solid var(--border-color);
    color: var(--text-primary);
    padding-left: 45px;
}

.search-box input:focus {
    background: #2a2a2a;
    border-color: var(--accent-blue);
    color: var(--text-primary);
    box-shadow: 0 0 0 0.2rem rgba(0, 180, 216, 0.25);
}

.search-box .search-icon {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--accent-blue);
}

.badge-count {
    font-size: 1.1rem;
    padding: 8px 12px;
}

.btn-view-all {
    background: linear-gradient(135deg, var(--accent-blue) 0%, var(--accent-blue-hover) 100%);
    border: none;
    color: white;
    padding: 8px 20px;
    border-radius: 8px;
    font-size: 0.85rem;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    gap: 8px;
}

.btn-view-all:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 180, 216, 0.4);
    color: white;
}

.close-panel {
    background: rgba(255, 255, 255, 0.2);
    border: none;
    color: white;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s;
}

.close-panel:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: rotate(90deg);
}

.empty-state {
    text-align: center;
    padding: 40px 20px;
    color: var(--text-secondary);
}

.empty-state i {
    font-size: 3rem;
    margin-bottom: 15px;
    opacity: 0.5;
}

@media (max-width: 768px) {
    .side-panel {
        width: 100%;
        right: -100%;
    }
}

/* Scrollbar personalizado para el panel */
.side-panel::-webkit-scrollbar {
    width: 8px;
}

.side-panel::-webkit-scrollbar-track {
    background: var(--bg-secondary);
}

.side-panel::-webkit-scrollbar-thumb {
    background: var(--accent-blue);
    border-radius: 4px;
}

.side-panel::-webkit-scrollbar-thumb:hover {
    background: var(--accent-blue-hover);
}

/* Animación de entrada para las tarjetas */
@keyframes slideInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.panel-card {
    animation: slideInUp 0.3s ease-out;
}
</style>
</head>
<body>

<!-- Overlay del panel -->
<div class="side-panel-overlay" id="panelOverlay"></div>

<!-- Panel lateral desplegable -->
<div class="side-panel" id="sidePanel">
    <div class="side-panel-header">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="mb-1"><i class="fas fa-list me-2"></i>Lista de Mantenimientos</h4>
                <p class="mb-0 small">Total: <span id="totalCount">0</span> equipos</p>
            </div>
            <button class="close-panel" id="closePanel">
                <i class="fas fa-times"></i>
            </button>
        </div>
    </div>
    
    <div class="side-panel-body">
        <!-- Búsqueda -->
        <div class="search-box">
            <i class="fas fa-search search-icon"></i>
            <input type="text" class="form-control" id="searchInput" placeholder="Buscar equipo, marca, serie...">
        </div>

        <!-- Filtros por Estado -->
        <div class="filter-section">
            <h6 class="mb-3"><i class="fas fa-filter me-2"></i>Filtrar por Estado</h6>
            <button class="btn btn-sm filter-btn active" data-filter="all">
                <i class="fas fa-th me-2"></i>Todos los estados
            </button>
            <button class="btn btn-sm filter-btn" data-filter="por_hacer">
                <i class="fas fa-clipboard-list me-2"></i>Por Hacer
            </button>
            <button class="btn btn-sm filter-btn" data-filter="en_espera">
                <i class="fas fa-clock me-2"></i>En Espera
            </button>
            <button class="btn btn-sm filter-btn" data-filter="en_revision">
                <i class="fas fa-search me-2"></i>En Revisión
            </button>
            <button class="btn btn-sm filter-btn" data-filter="terminada">
                <i class="fas fa-check-circle me-2"></i>Terminada
            </button>
        </div>

        <!-- Filtros por Tipo -->
        <div class="filter-section">
            <h6 class="mb-3"><i class="fas fa-tools me-2"></i>Filtrar por Tipo</h6>
            <button class="btn btn-sm filter-btn active" data-type-filter="all">
                <i class="fas fa-th me-2"></i>Todos los tipos
            </button>
            <button class="btn btn-sm filter-btn" data-type-filter="preventivo">
                <i class="fas fa-wrench me-2"></i>Preventivo
            </button>
            <button class="btn btn-sm filter-btn" data-type-filter="correctivo">
                <i class="fas fa-tools me-2"></i>Correctivo
            </button>
            <button class="btn btn-sm filter-btn" data-type-filter="predictivo">
                <i class="fas fa-chart-area me-2"></i>Predictivo
            </button>
        </div>

        <!-- Lista de equipos -->
        <div id="equiposList">
            <!-- Se llenará dinámicamente con JavaScript -->
        </div>

        <!-- Estado vacío -->
        <div class="empty-state d-none" id="emptyState">
            <i class="fas fa-inbox"></i>
            <p class="mb-0">No se encontraron mantenimientos</p>
        </div>
    </div>
</div>

<div class="container-fluid py-4">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3"><i class="fa-solid fa-screwdriver-wrench me-2" style="color: var(--accent-blue);"></i>Gestión de Mantenimientos</h1>
                <p class="text-muted mb-0">Organiza y monitorea el progreso de todos los mantenimientos</p>
            </div>
        </div>

        <div class="row g-3">
            <!-- Columnas Kanban -->
            <?php
            $estados = [
                'por_hacer' => ['icon'=>'fa-clipboard-list', 'color'=>'primary', 'titulo'=>'Por Hacer', 'bg'=>'#3498db'],
                'en_espera' => ['icon'=>'fa-clock', 'color'=>'warning', 'titulo'=>'En Espera', 'bg'=>'#f1c40f'],
                'en_revision' => ['icon'=>'fa-search', 'color'=>'info', 'titulo'=>'En Revisión', 'bg'=>'#9b59b6'],
                'terminada' => ['icon'=>'fa-check-circle', 'color'=>'success', 'titulo'=>'Terminada', 'bg'=>'#27ae60']
            ];

            foreach ($estados as $estado => $info):
            $filtered = array_filter($equipos, fn($e)=>$e['estado']==$estado);
            $count = count($filtered);
            ?>
            <div class="col-lg-3 col-md-6">
                <div class="kanban-column">
                    <div class="kanban-header">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h5 class="mb-0" style="color: <?= $info['bg'] ?>;">
                                <i class="fa-solid <?= $info['icon'] ?> me-2"></i><?= $info['titulo'] ?>
                            </h5>
                            <span class="badge badge-count" style="background: <?= $info['bg'] ?>;">
                                <?= $count ?>
                            </span>
                        </div>
                        <?php if ($count > 3): ?>
                        <button class="btn-view-all" onclick="openPanel('<?= $estado ?>')">
                            <i class="fas fa-list"></i>
                            Ver todos (<?= $count ?>)
                        </button>
                        <?php endif; ?>
                    </div>
                    
                    <?php
                    if ($count > 0):
                        $display_count = 0;
                        foreach ($filtered as $eq):
                            if ($display_count >= 3) break;
                            $display_count++;
                    ?>
                    <div class="card task-card task-<?= htmlspecialchars($eq['tipo_mantenimiento']) ?>" 
                         onclick="window.location.href='equipos.php?editar=<?= $eq['id'] ?>'">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h6 class="card-title mb-0"><?= htmlspecialchars($eq['equipo']) ?></h6>
                                <span class="badge text-uppercase" style="background: <?= 
                                    $eq['tipo_mantenimiento']=='preventivo' ? '#ffc107' : 
                                    ($eq['tipo_mantenimiento']=='correctivo' ? '#dc3545' : '#28a745') 
                                ?>; color: <?= $eq['tipo_mantenimiento']=='preventivo' ? '#000' : '#fff' ?>;">
                                    <?= htmlspecialchars($eq['tipo_mantenimiento']) ?>
                                </span>
                            </div>
                            <p class="small text-muted mb-2">
                                <?= htmlspecialchars(strlen($eq['observacion'] ?? '') > 80 ? 
                                    substr($eq['observacion'], 0, 80) . '...' : 
                                    ($eq['observacion'] ?? 'Sin descripción')) ?>
                            </p>
                            <div class="mb-2">
                                <small class="text-muted">Avance:</small>
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar"
                                         style="width: <?= intval($eq['avance']) ?>%; background: <?= 
                                            intval($eq['avance']) < 30 ? '#dc3545' : 
                                            (intval($eq['avance']) < 70 ? '#ffc107' : '#28a745') 
                                         ?>;">
                                        <?= intval($eq['avance']) ?>%
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted">
                                    <i class="far fa-calendar me-1"></i>
                                    <?= date('d/m/Y', strtotime($eq['fecha_programada'] ?? $eq['fecha_ingreso'])) ?>
                                </small>
                                <button class="btn btn-sm btn-outline-primary" onclick="event.stopPropagation(); window.location.href='equipos.php?editar=<?= $eq['id'] ?>'">
                                    <i class="fa-solid fa-pen"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php
                        endforeach;
                    else:
                        echo '<p class="text-center text-muted mt-3"><i class="fas fa-inbox me-2"></i>No hay mantenimientos</p>';
                    endif;
                    ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Datos de equipos desde PHP
const equiposData = <?= json_encode($equipos) ?>;

// Filtros activos
let activeStateFilter = 'all';
let activeTypeFilter = 'all';
let searchTerm = '';

// Abrir panel con filtro específico
function openPanel(estado = 'all') {
    document.getElementById('sidePanel').classList.add('active');
    document.getElementById('panelOverlay').classList.add('active');
    
    // Activar el filtro correspondiente
    document.querySelectorAll('[data-filter]').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.filter === estado) {
            btn.classList.add('active');
            activeStateFilter = estado;
        }
    });
    
    renderEquipos();
}

// Cerrar panel
function closePanel() {
    document.getElementById('sidePanel').classList.remove('active');
    document.getElementById('panelOverlay').classList.remove('active');
}

// Event listeners
document.getElementById('closePanel').addEventListener('click', closePanel);
document.getElementById('panelOverlay').addEventListener('click', closePanel);

// Filtros por estado
document.querySelectorAll('[data-filter]').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('[data-filter]').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        activeStateFilter = this.dataset.filter;
        renderEquipos();
    });
});

// Filtros por tipo
document.querySelectorAll('[data-type-filter]').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('[data-type-filter]').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        activeTypeFilter = this.dataset.typeFilter;
        renderEquipos();
    });
});

// Búsqueda
document.getElementById('searchInput').addEventListener('input', function(e) {
    searchTerm = e.target.value.toLowerCase();
    renderEquipos();
});

// Renderizar equipos filtrados
function renderEquipos() {
    const container = document.getElementById('equiposList');
    const emptyState = document.getElementById('emptyState');
    
    // Filtrar equipos
    let filtered = equiposData.filter(eq => {
        const matchState = activeStateFilter === 'all' || eq.estado === activeStateFilter;
        const matchType = activeTypeFilter === 'all' || eq.tipo_mantenimiento === activeTypeFilter;
        const matchSearch = searchTerm === '' || 
            eq.equipo.toLowerCase().includes(searchTerm) ||
            (eq.marca && eq.marca.toLowerCase().includes(searchTerm)) ||
            (eq.serie && eq.serie.toLowerCase().includes(searchTerm)) ||
            (eq.observacion && eq.observacion.toLowerCase().includes(searchTerm));
        
        return matchState && matchType && matchSearch;
    });
    
    // Actualizar contador
    document.getElementById('totalCount').textContent = filtered.length;
    
    // Mostrar/ocultar estado vacío
    if (filtered.length === 0) {
        container.innerHTML = '';
        emptyState.classList.remove('d-none');
        return;
    } else {
        emptyState.classList.add('d-none');
    }
    
    // Generar HTML
    const html = filtered.map(eq => {
        const tipoColor = eq.tipo_mantenimiento === 'preventivo' ? '#ffc107' : 
                         (eq.tipo_mantenimiento === 'correctivo' ? '#dc3545' : '#28a745');
        const tipoTextColor = eq.tipo_mantenimiento === 'preventivo' ? '#000' : '#fff';
        
        const estadoColor = eq.estado === 'por_hacer' ? '#3498db' :
                           (eq.estado === 'en_espera' ? '#f1c40f' :
                           (eq.estado === 'en_revision' ? '#9b59b6' : '#27ae60'));
        
        const estadoText = eq.estado === 'por_hacer' ? 'Por Hacer' :
                          (eq.estado === 'en_espera' ? 'En Espera' :
                          (eq.estado === 'en_revision' ? 'En Revisión' : 'Terminada'));
        
        const avanceColor = parseInt(eq.avance) < 30 ? '#dc3545' :
                           (parseInt(eq.avance) < 70 ? '#ffc107' : '#28a745');
        
        return `
            <div class="panel-card task-${eq.tipo_mantenimiento}" 
                 style="border-left-color: ${tipoColor};" 
                 onclick="window.location.href='equipos.php?editar=${eq.id}'">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <div>
                        <h6 class="mb-1" style="color: var(--text-primary);">${eq.equipo}</h6>
                        <small class="text-muted">
                            <i class="fas fa-hashtag me-1"></i>ID: ${eq.id}
                            ${eq.marca ? ` | ${eq.marca}` : ''}
                        </small>
                    </div>
                    <span class="badge text-uppercase" style="background: ${tipoColor}; color: ${tipoTextColor};">
                        ${eq.tipo_mantenimiento}
                    </span>
                </div>
                
                <p class="small text-muted mb-2">
                    ${eq.observacion ? (eq.observacion.length > 100 ? eq.observacion.substring(0, 100) + '...' : eq.observacion) : 'Sin descripción'}
                </p>
                
                <div class="d-flex gap-2 mb-2">
                    <span class="badge" style="background: ${estadoColor};">
                        ${estadoText}
                    </span>
                    ${eq.serie ? `<span class="badge bg-secondary"><i class="fas fa-barcode me-1"></i>${eq.serie}</span>` : ''}
                </div>
                
                <div class="mb-2">
                    <div class="d-flex justify-content-between mb-1">
                        <small class="text-muted">Avance:</small>
                        <small style="color: ${avanceColor}; font-weight: bold;">${parseInt(eq.avance)}%</small>
                    </div>
                    <div class="progress" style="height: 8px;">
                        <div class="progress-bar" role="progressbar"
                             style="width: ${parseInt(eq.avance)}%; background: ${avanceColor};">
                        </div>
                    </div>
                </div>
                
                <div class="d-flex justify-content-between align-items-center">
                    <small class="text-muted">
                        <i class="far fa-calendar me-1"></i>
                        ${new Date(eq.fecha_programada || eq.fecha_ingreso).toLocaleDateString('es-ES')}
                    </small>
                    <div>
                        <small class="text-muted me-2">
                            <i class="fas fa-dollar-sign me-1"></i>
                            <span style="color: #28a745;">${parseFloat(eq.costo_final || 0).toFixed(2)}</span>
                        </small>
                        <button class="btn btn-sm btn-outline-primary" onclick="event.stopPropagation(); window.location.href='equipos.php?editar=${eq.id}'">
                            <i class="fa-solid fa-pen"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
    }).join('');
    
    container.innerHTML = html;
}

// Inicializar
renderEquipos();

// Cerrar con tecla ESC
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closePanel();
    }
});
</script>
</body>
</html>
<?php
$conexion_local->close();
?>