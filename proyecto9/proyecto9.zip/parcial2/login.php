<?php
session_start();
require_once 'conexion_dbs.php';

// Redirigir si ya está logueado
if (isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit();
}

$error = "";

// Procesar login
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $usuario = trim($_POST['usuario']);
    $contraseña = $_POST['contraseña'];
    
    if (empty($usuario) || empty($contraseña)) {
        $error = "Usuario y contraseña son obligatorios";
    } else {
        // Buscar usuario en la base de datos local
        $sql = "SELECT * FROM datos_admins WHERE usuario = ? AND activo = 1";
        $stmt = $conexion_local->prepare($sql);
        $stmt->bind_param("s", $usuario);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        if ($resultado->num_rows === 1) {
            $usuario_data = $resultado->fetch_assoc();
            
            // VERIFICAR CONTRASEÑA HASHEADA
            if (password_verify($contraseña, $usuario_data['contraseña'])) {
                // Iniciar sesión
                $_SESSION['usuario_id'] = $usuario_data['id'];
                $_SESSION['usuario'] = $usuario_data['usuario'];
                $_SESSION['rol'] = $usuario_data['rol'];
                $_SESSION['nombre_completo'] = $usuario_data['nombre_completo'];
                
                header("Location: index.php");
                exit();
            } else {
                $error = "Contraseña incorrecta. Usa 'password' para ambos usuarios.";
            }
        } else {
            $error = "Usuario no encontrado o inactivo";
        }
        
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - Sistema de Equipos</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .login-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
            overflow: hidden;
        }
        
        .login-header {
            background: linear-gradient(135deg, #2c3e50, #34495e);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .login-header h1 {
            font-size: 1.8em;
            margin-bottom: 10px;
        }
        
        .login-body {
            padding: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2c3e50;
        }
        
        input {
            width: 100%;
            padding: 12px;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        input:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .btn-login {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #f5c6cb;
            text-align: center;
            font-weight: 600;
        }
        
        .demo-accounts {
            margin-top: 25px;
            padding: 15px;
            background: #e8f4fd;
            border-radius: 8px;
            font-size: 0.9em;
        }
        
        .demo-accounts h4 {
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .demo-accounts ul {
            list-style: none;
            padding-left: 0;
        }
        
        .demo-accounts li {
            margin-bottom: 5px;
            padding: 5px;
            background: white;
            border-radius: 4px;
        }

        /* Footer */
        footer {
            margin-top: 30px;
            text-align: center;
            font-size: 0.9em;
            color: #f5f5f5;
        }

    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1>🔐 Iniciar Sesión</h1>
            <p>Sistema de Gestión de Equipos</p>
        </div>
        
        <div class="login-body">
            <?php if ($error): ?>
                <div class="error-message">
                    ❌ <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="usuario">👤 Usuario</label>
                    <input type="text" id="usuario" name="usuario" 
                           value="<?php echo isset($_POST['usuario']) ? htmlspecialchars($_POST['usuario']) : ''; ?>" 
                           required placeholder="Ingrese su usuario">
                </div>
                
                <div class="form-group">
                    <label for="contraseña">🔒 Contraseña</label>
                    <input type="password" id="contraseña" name="contraseña" 
                           required placeholder="Ingrese su contraseña">
                </div>
                
                <button type="submit" name="login" class="btn-login">
                    🚀 Iniciar Sesión
                </button>
            </form>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script>
        // Prevenir el reenvío del formulario
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</body>
</html>

<?php
// Cerrar conexiones
$conexion_local->close();
$conexion_remota->close();
?>
