<?php
// ========================================
// ARCHIVO: auth.php
// Descripción: Funciones de autenticación y autorización
// ========================================

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Verificar si el usuario está logueado
function verificarAutenticacion() {
    if (!isset($_SESSION['usuario_id'])) {
        header("Location: login.php");
        exit();
    }
}

// Verificar si el usuario tiene rol de admin
function verificarAdmin() {
    if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
        $_SESSION['error'] = "❌ Acceso denegado. Se requiere rol de administrador.";
        header("Location: index.php");
        exit();
    }
}

// Verificar si el usuario tiene rol de staff o admin
function verificarStaff() {
    if (!isset($_SESSION['rol']) || ($_SESSION['rol'] !== 'admin' && $_SESSION['rol'] !== 'staff')) {
        $_SESSION['error'] = "❌ Acceso denegado. Se requiere autenticación.";
        header("Location: login.php");
        exit();
    }
}

// Obtener información del usuario actual
function obtenerUsuarioActual() {
    return [
        'id' => $_SESSION['usuario_id'] ?? null,
        'usuario' => $_SESSION['usuario'] ?? null,
        'rol' => $_SESSION['rol'] ?? null,
        'nombre_completo' => $_SESSION['nombre_completo'] ?? null
    ];
}

// Cerrar sesión
function logout() {
    session_destroy();
    header("Location: login.php");
    exit();
}
?>
