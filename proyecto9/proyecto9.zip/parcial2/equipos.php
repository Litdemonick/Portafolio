<?php
// ========================================
// ARCHIVO: equipos.php
// Descripción: CRUD completo para equipos con replicación
// ========================================

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'conexion_dbs.php';
require_once 'auth.php';
verificarStaff(); // Solo usuarios con rol staff o admin

// Variables para mensajes
$mensaje = "";
$tipo_mensaje = ""; // success, error, warning

// ========================================
// PAGINACIÓN Y FILTROS
// ========================================
$items_por_pagina = 5;
$pagina_actual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;
$offset = ($pagina_actual - 1) * $items_por_pagina;

// Paginación para equipos eliminados
$items_por_pagina_eliminados = 5;
$pagina_eliminados = isset($_GET['pagina_eliminados']) ? max(1, intval($_GET['pagina_eliminados'])) : 1;
$offset_eliminados = ($pagina_eliminados - 1) * $items_por_pagina_eliminados;

// Filtro por categoría
$filtro_categoria = isset($_GET['categoria']) ? $_GET['categoria'] : '';

// Parámetros de búsqueda
$buscar = isset($_GET['buscar']) ? trim($_GET['buscar']) : '';

// ========================================
// OPERACIONES CRUD
// ========================================

// CREAR NUEVO EQUIPO
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['crear_equipo'])) {
    $equipo = trim($_POST['equipo']);
    $marca = trim($_POST['marca']);
    $serie = trim($_POST['serie']);
    $tipo_servicio = $_POST['tipo_servicio'];
    $fecha_programada = $_POST['fecha_programada'];
    $fecha_salida = $_POST['fecha_salida'];
    $costo_inicial = $_POST['costo_inicial'];
    $costo_final = $_POST['costo_final'];
    $observacion = trim($_POST['observacion']);
    $categoria_equipo = $_POST['categoria_equipo'];
    $estado = $_POST['estado'];
    $avance = $_POST['avance'];

    if (empty($equipo)) {
        $mensaje = "El nombre del equipo es obligatorio";
        $tipo_mensaje = "error";
    } else {
        $sql = "INSERT INTO equipos (equipo, marca, serie, tipo_servicio, fecha_ingreso, fecha_programada, fecha_salida, costo_inicial, costo_final, observacion, categoria_equipo, estado, avance)
                VALUES (
                    '".$conexion_local->real_escape_string($equipo)."',
                    '".$conexion_local->real_escape_string($marca)."',
                    '".$conexion_local->real_escape_string($serie)."',
                    '".$conexion_local->real_escape_string($tipo_servicio)."',
                    NOW(),
                    '".$conexion_local->real_escape_string($fecha_programada)."',
                    '".$conexion_local->real_escape_string($fecha_salida)."',
                    '".$conexion_local->real_escape_string($costo_inicial)."',
                    '".$conexion_local->real_escape_string($costo_final)."',
                    '".$conexion_local->real_escape_string($observacion)."',
                    '".$conexion_local->real_escape_string($categoria_equipo)."',
                    '".$conexion_local->real_escape_string($estado)."',
                    '".$conexion_local->real_escape_string($avance)."'
                )";

        if (replicar_consulta($sql)) {
            $mensaje = "✅ Equipo creado exitosamente en ambas bases de datos";
            $tipo_mensaje = "success";
        } else {
            $mensaje = "❌ Error al crear el equipo";
            $tipo_mensaje = "error";
        }
    }
}

// ACTUALIZAR EQUIPO
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['actualizar_equipo'])) {
    $id = intval($_POST['id']);
    $equipo = trim($_POST['equipo']);
    $marca = trim($_POST['marca']);
    $serie = trim($_POST['serie']);
    $tipo_servicio = $_POST['tipo_servicio'];
    $fecha_programada = $_POST['fecha_programada'];
    $fecha_salida = $_POST['fecha_salida'];
    $costo_inicial = $_POST['costo_inicial'];
    $costo_final = $_POST['costo_final'];
    $observacion = trim($_POST['observacion']);
    $categoria_equipo = $_POST['categoria_equipo'];
    $estado = $_POST['estado'];
    $avance = $_POST['avance'];

    if (empty($equipo)) {
        $mensaje = "El nombre del equipo es obligatorio";
        $tipo_mensaje = "error";
    } else {
        $sql = "UPDATE equipos SET 
                equipo='".$conexion_local->real_escape_string($equipo)."',
                marca='".$conexion_local->real_escape_string($marca)."',
                serie='".$conexion_local->real_escape_string($serie)."',
                tipo_servicio='".$conexion_local->real_escape_string($tipo_servicio)."',
                fecha_programada='".$conexion_local->real_escape_string($fecha_programada)."',
                fecha_salida='".$conexion_local->real_escape_string($fecha_salida)."',
                costo_inicial='".$conexion_local->real_escape_string($costo_inicial)."',
                costo_final='".$conexion_local->real_escape_string($costo_final)."',
                observacion='".$conexion_local->real_escape_string($observacion)."',
                categoria_equipo='".$conexion_local->real_escape_string($categoria_equipo)."',
                estado='".$conexion_local->real_escape_string($estado)."',
                avance='".$conexion_local->real_escape_string($avance)."'
                WHERE id=".$id;

        if (replicar_consulta($sql)) {
            $mensaje = "✅ Equipo actualizado exitosamente en ambas bases de datos";
            $tipo_mensaje = "success";
        } else {
            $mensaje = "❌ Error al actualizar el equipo";
            $tipo_mensaje = "error";
        }
    }
}

// ELIMINAR EQUIPO CON HISTORIAL
if (isset($_GET['eliminar'])) {
    $id = intval($_GET['eliminar']);
    
    // Obtener usuario actual
    $usuario = $_SESSION['usuario'] ?? 'Desconocido';
    
    // Primero obtenemos los datos del equipo
    $sql_select = "SELECT * FROM equipos WHERE id = " . $id;
    $resultado_select = $conexion_local->query($sql_select);
    
    if ($resultado_select && $resultado_select->num_rows > 0) {
        $equipo = $resultado_select->fetch_assoc();
        
        // Preparar observaciones con información adicional
        $observaciones = "Categoría: ".$equipo['categoria_equipo']." | Tipo Servicio: ".$equipo['tipo_servicio'];
        $observaciones .= " | Estado: ".$equipo['estado']." | Avance: ".$equipo['avance']."%";
        if (!empty($equipo['observacion'])) {
            $observaciones .= " | Obs: ".$equipo['observacion'];
        }
        
        // Insertar en equipos_eliminados (LOCAL)
        $sql_insert = "INSERT INTO equipos_eliminados 
            (id_equipo_original, nombre_equipo, marca, modelo, serie, fecha_ingreso, 
             eliminado_por, motivo_eliminacion, observaciones)
            VALUES (
                ".$equipo['id'].",
                '".$conexion_local->real_escape_string($equipo['equipo'])."',
                '".$conexion_local->real_escape_string($equipo['marca'])."',
                '".$conexion_local->real_escape_string($equipo['tipo_servicio'])."',
                '".$conexion_local->real_escape_string($equipo['serie'])."',
                '".date('Y-m-d', strtotime($equipo['fecha_ingreso']))."',
                '".$conexion_local->real_escape_string($usuario)."',
                'Eliminación desde el sistema',
                '".$conexion_local->real_escape_string($observaciones)."'
            )";
        
        $insert_local = $conexion_local->query($sql_insert);
        
        // Insertar en equipos_eliminados (REMOTA)
        $insert_remota = $conexion_remota->query($sql_insert);
        
        // Si ambas inserciones fueron exitosas, eliminamos el equipo
        if ($insert_local && $insert_remota) {
            $sql_delete = "DELETE FROM equipos WHERE id=" . $id;
            if (replicar_consulta($sql_delete)) {
                $mensaje = "✅ Equipo eliminado y guardado en historial correctamente";
                $tipo_mensaje = "success";
            } else {
                $mensaje = "❌ Error al eliminar el equipo de la tabla principal";
                $tipo_mensaje = "error";
            }
        } else {
            $mensaje = "❌ Error al guardar el equipo en el historial de eliminados";
            $tipo_mensaje = "error";
        }
    } else {
        $mensaje = "❌ Equipo no encontrado";
        $tipo_mensaje = "error";
    }
}

// ========================================
// OBTENER DATOS PARA MOSTRAR
// ========================================

// Contar total de equipos eliminados
$sql_count_eliminados = "SELECT COUNT(*) as total FROM equipos_eliminados";
$resultado_count_eliminados = $conexion_local->query($sql_count_eliminados);
$total_eliminados = $resultado_count_eliminados->fetch_assoc()['total'];
$total_paginas_eliminados = ceil($total_eliminados / $items_por_pagina_eliminados);

// Obtener equipos eliminados con paginación
$sql_eliminados = "SELECT * FROM equipos_eliminados ORDER BY fecha_eliminacion DESC LIMIT ".$items_por_pagina_eliminados." OFFSET ".$offset_eliminados;
$resultado_eliminados = $conexion_local->query($sql_eliminados);

// Construir consulta con filtros para equipos activos
$where_conditions = [];
$params = [];
$types = "";

if (!empty($filtro_categoria) && $filtro_categoria != 'todos') {
    $where_conditions[] = "categoria_equipo = ?";
    $params[] = $filtro_categoria;
    $types .= "s";
}

if (!empty($buscar)) {
    $where_conditions[] = "(marca LIKE ? OR equipo LIKE ? OR serie LIKE ? OR estado LIKE ? OR observacion LIKE ?)";
    $search_param = "%$buscar%";
    $params = array_merge($params, [$search_param, $search_param, $search_param, $search_param, $search_param]);
    $types .= "sssss";
}

// Construir WHERE clause
$where_clause = "";
if (count($where_conditions) > 0) {
    $where_clause = "WHERE " . implode(" AND ", $where_conditions);
}

// Contar total de equipos (con filtro)
$sql_count = "SELECT COUNT(*) as total FROM equipos " . $where_clause;
if (!empty($params)) {
    $stmt_count = $conexion_local->prepare($sql_count);
    if (!empty($types)) {
        $stmt_count->bind_param($types, ...$params);
    }
    $stmt_count->execute();
    $result_count = $stmt_count->get_result();
    $total_equipos = $result_count->fetch_assoc()['total'];
} else {
    $resultado_count = $conexion_local->query($sql_count);
    $total_equipos = $resultado_count->fetch_assoc()['total'];
}
$total_paginas = ceil($total_equipos / $items_por_pagina);

// Obtener equipos con paginación y filtro
$sql_equipos = "SELECT * FROM equipos " . $where_clause . " ORDER BY fecha_ingreso DESC LIMIT ".$items_por_pagina." OFFSET ".$offset;
if (!empty($params)) {
    $stmt_equipos = $conexion_local->prepare($sql_equipos);
    if (!empty($types)) {
        $stmt_equipos->bind_param($types, ...$params);
    }
    $stmt_equipos->execute();
    $resultado_equipos = $stmt_equipos->get_result();
} else {
    $resultado_equipos = $conexion_local->query($sql_equipos);
}

// Obtener equipo específico para editar
$equipo_editar = null;
if (isset($_GET['editar'])) {
    $id_editar = intval($_GET['editar']);
    $sql_editar = "SELECT * FROM equipos WHERE id=".$id_editar;
    $resultado_editar = $conexion_local->query($sql_editar);
    if ($resultado_editar && $resultado_editar->num_rows>0) {
        $equipo_editar = $resultado_editar->fetch_assoc();
    }
}

// Estados de conexión
$estado_local = $conexion_local->ping();
$estado_remota = $conexion_remota->ping();

include 'includes/header.php';
?>

<style>
.content {
    display: flex;
    flex-wrap: wrap;
    gap: 25px;
    margin-top: 20px;
    max-width: 1800px;
    margin-left: auto;
    margin-right: auto;
}

.form-section, .list-section {
    background: #1e1e1e;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
}

.form-section {
    flex: 0 0 400px;
    min-width: 350px;
    margin: 0 auto;
}

.list-section {
    flex: 1;
    min-width: 800px;
}

.section-title {
    margin-bottom: 15px;
    color: #00b4d8;
    text-align: center;
}

.form-group {
    margin-bottom: 12px;
}

.form-group label {
    display: block;
    font-weight: bold;
    color: #ddd;
    margin-bottom: 5px;
}

.form-group input, .form-group select, .form-group textarea {
    width: 100%;
    padding: 8px;
    border-radius: 8px;
    border: none;
    background: #2a2a2a;
    color: white;
}

textarea {
    resize: vertical;
}

.btn {
    padding: 10px 18px;
    border-radius: 6px;
    text-decoration: none;
    color: white;
    cursor: pointer;
    border: none;
    display: inline-block;
    margin: 4px;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.3s ease;
}

.btn-primary { 
    background: #0078ff; 
}
.btn-primary:hover { 
    background: #0066cc; 
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0, 120, 255, 0.3);
}

.btn-secondary { 
    background: #555; 
}
.btn-secondary:hover { 
    background: #444; 
}

.btn-warning { 
    background: #f1c40f; 
}
.btn-warning:hover { 
    background: #d4ac0d; 
}

.btn-danger { 
    background: #e74c3c; 
}
.btn-danger:hover { 
    background: #c0392b; 
}

.table-container {
    overflow-x: auto;
}

.table-container table {
    width: 100%;
    border-collapse: collapse;
    color: #ddd;
    min-width: 1400px;
}

.table-container th, .table-container td {
    padding: 12px 8px;
    border-bottom: 1px solid #333;
    text-align: center;
    font-size: 13px;
}

.table-container th { 
    background: #333;
    position: sticky;
    top: 0;
    z-index: 10;
}

.table-container td {
    background: #1e1e1e;
}

.table-container tr:hover td {
    background: #252525;
}

.actions {
    white-space: nowrap;
}

.actions .btn {
    padding: 6px 12px;
    font-size: 13px;
    margin: 2px;
}

.message {
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 15px;
    text-align: center;
    font-weight: 500;
}

.message.success { 
    background: #2ecc71; 
    color: white; 
}

.message.error { 
    background: #e74c3c; 
    color: white; 
}

.message.warning { 
    background: #f39c12; 
    color: white; 
}

.button-group {
    text-align: center;
    margin-top: 15px;
}

.progress-bar-container {
    background: #e0e0e0;
    border-radius: 5px;
    overflow: hidden;
    width: 100px;
    height: 24px;
    margin: 0 auto;
}

.progress-bar-fill {
    height: 100%;
    background: #3498db;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 11px;
    font-weight: bold;
    transition: width 0.3s ease;
}

.estado-badge {
    padding: 6px 12px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: bold;
    display: inline-block;
    white-space: nowrap;
}

/* ESTILOS PARA FILTROS */
.filter-section {
    background: #252525;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
}

.filter-section label {
    color: #ddd;
    font-weight: bold;
}

.filter-section select {
    padding: 8px 12px;
    border-radius: 6px;
    border: none;
    background: #2a2a2a;
    color: white;
    cursor: pointer;
    min-width: 200px;
}

.filter-btn {
    padding: 8px 16px;
    background: #00b4d8;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-weight: 500;
    transition: all 0.3s ease;
}

.filter-btn:hover {
    background: #0096b8;
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
}

/* ESTILOS PARA PAGINACIÓN */
.pagination {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
    margin-top: 20px;
    flex-wrap: wrap;
}

.pagination a, .pagination span {
    padding: 8px 14px;
    background: #2a2a2a;
    color: #ddd;
    text-decoration: none;
    border-radius: 6px;
    transition: all 0.3s ease;
}

.pagination a:hover {
    background: #00b4d8;
    color: white;
}

.pagination .active {
    background: #0078ff;
    color: white;
    font-weight: bold;
}

.pagination .disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.pagination-info {
    color: #999;
    font-size: 14px;
    text-align: center;
    margin-top: 10px;
}

#search-input:focus {
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

/* Responsive */
@media (max-width: 1400px) {
    .content {
        flex-direction: column;
    }
    
    .form-section, .list-section {
        flex: 1 1 100%;
        min-width: 100%;
    }
}

@media (max-width: 768px) {
    .filter-section form {
        flex-direction: column;
    }
    .filter-section form > div {
        width: 100% !important;
        min-width: 100% !important;
    }
}
</style>

<div class="content">

<!-- Sección de Equipos Eliminados -->
<div class="list-section" style="flex: 1 1 100%; min-width: 100%;" id="eliminados">
    <h2 class="section-title">🗑️ Historial de Equipos Eliminados</h2>
    
    <div class="table-container">
        <?php if ($resultado_eliminados && $resultado_eliminados->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID Original</th>
                        <th>Nombre Equipo</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Serie</th>
                        <th>Fecha Ingreso</th>
                        <th>Eliminado Por</th>
                        <th>Fecha Eliminación</th>
                        <th>Motivo</th>
                        <th>Observaciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($elim = $resultado_eliminados->fetch_assoc()): ?>
                        <tr style="opacity: 0.7;">
                            <td><?php echo $elim['id_equipo_original']; ?></td>
                            <td><strong><?php echo htmlspecialchars($elim['nombre_equipo']); ?></strong></td>
                            <td><?php echo htmlspecialchars($elim['marca']); ?></td>
                            <td><?php echo htmlspecialchars($elim['modelo']); ?></td>
                            <td><?php echo htmlspecialchars($elim['serie']); ?></td>
                            <td><?php echo $elim['fecha_ingreso'] ? date('d/m/Y', strtotime($elim['fecha_ingreso'])) : '-'; ?></td>
                            <td><strong style="color: #e74c3c;"><?php echo htmlspecialchars($elim['eliminado_por']); ?></strong></td>
                            <td><?php echo date('d/m/Y H:i', strtotime($elim['fecha_eliminacion'])); ?></td>
                            <td><?php echo htmlspecialchars($elim['motivo_eliminacion']); ?></td>
                            <td style="font-size: 11px; max-width: 300px;">
                                <?php echo htmlspecialchars($elim['observaciones']); ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            
            <!-- Paginación para equipos eliminados -->
            <?php if ($total_paginas_eliminados > 1): ?>
                <div class="pagination">
                    <?php if ($pagina_eliminados > 1): ?>
                        <a href="?pagina_eliminados=<?php echo $pagina_eliminados - 1; ?><?php echo !empty($filtro_categoria) && $filtro_categoria != 'todos' ? '&categoria='.$filtro_categoria : ''; ?><?php echo !empty($buscar) ? '&buscar='.urlencode($buscar) : ''; ?><?php echo isset($_GET['pagina']) ? '&pagina='.$_GET['pagina'] : ''; ?>#eliminados">« Anterior</a>
                    <?php else: ?>
                        <span class="disabled">« Anterior</span>
                    <?php endif; ?>
                    
                    <?php
                    // Mostrar números de página para eliminados
                    $rango = 2;
                    $inicio = max(1, $pagina_eliminados - $rango);
                    $fin = min($total_paginas_eliminados, $pagina_eliminados + $rango);
                    
                    if ($inicio > 1) {
                        echo '<a href="?pagina_eliminados=1' . (!empty($filtro_categoria) && $filtro_categoria != 'todos' ? '&categoria='.$filtro_categoria : '') . (!empty($buscar) ? '&buscar='.urlencode($buscar) : '') . (isset($_GET['pagina']) ? '&pagina='.$_GET['pagina'] : '') . '#eliminados">1</a>';
                        if ($inicio > 2) echo '<span>...</span>';
                    }
                    
                    for ($i = $inicio; $i <= $fin; $i++) {
                        if ($i == $pagina_eliminados) {
                            echo '<span class="active">' . $i . '</span>';
                        } else {
                            echo '<a href="?pagina_eliminados=' . $i . (!empty($filtro_categoria) && $filtro_categoria != 'todos' ? '&categoria='.$filtro_categoria : '') . (!empty($buscar) ? '&buscar='.urlencode($buscar) : '') . (isset($_GET['pagina']) ? '&pagina='.$_GET['pagina'] : '') . '#eliminados">' . $i . '</a>';
                        }
                    }
                    
                    if ($fin < $total_paginas_eliminados) {
                        if ($fin < $total_paginas_eliminados - 1) echo '<span>...</span>';
                        echo '<a href="?pagina_eliminados=' . $total_paginas_eliminados . (!empty($filtro_categoria) && $filtro_categoria != 'todos' ? '&categoria='.$filtro_categoria : '') . (!empty($buscar) ? '&buscar='.urlencode($buscar) : '') . (isset($_GET['pagina']) ? '&pagina='.$_GET['pagina'] : '') . '#eliminados">' . $total_paginas_eliminados . '</a>';
                    }
                    ?>
                    
                    <?php if ($pagina_eliminados < $total_paginas_eliminados): ?>
                        <a href="?pagina_eliminados=<?php echo $pagina_eliminados + 1; ?><?php echo !empty($filtro_categoria) && $filtro_categoria != 'todos' ? '&categoria='.$filtro_categoria : ''; ?><?php echo !empty($buscar) ? '&buscar='.urlencode($buscar) : ''; ?><?php echo isset($_GET['pagina']) ? '&pagina='.$_GET['pagina'] : ''; ?>#eliminados">Siguiente »</a>
                    <?php else: ?>
                        <span class="disabled">Siguiente »</span>
                    <?php endif; ?>
                </div>
                
                <div class="pagination-info">
                    Mostrando <?php echo ($offset_eliminados + 1); ?> - <?php echo min($offset_eliminados + $items_por_pagina_eliminados, $total_eliminados); ?> de <?php echo $total_eliminados; ?> equipos eliminados
                </div>
            <?php endif; ?>
            
        <?php else: ?>
            <div style="text-align: center; padding: 60px 20px; color: #6c757d;">
                <h3 style="font-size: 24px; margin-bottom: 10px;">✨ Sin equipos eliminados</h3>
                <p style="font-size: 16px;">No hay equipos en el historial de eliminados.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Formulario -->
<div class="form-section">
    <h2 class="section-title"><?php echo $equipo_editar ? '✏️ Editar Equipo' : '➕ Crear Nuevo Equipo'; ?></h2>
    
    <?php if ($mensaje): ?>
        <div class="message <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <?php if($equipo_editar): ?>
            <input type="hidden" name="id" value="<?php echo $equipo_editar['id']; ?>">
        <?php endif; ?>

        <div class="form-group">
            <label>Equipo *</label>
            <input type="text" name="equipo" maxlength="50" required value="<?php echo $equipo_editar ? $equipo_editar['equipo'] : ''; ?>">
        </div>

        <div class="form-group">
            <label>Marca</label>
            <input type="text" name="marca" maxlength="30" value="<?php echo $equipo_editar ? $equipo_editar['marca'] : ''; ?>">
        </div>

        <div class="form-group">
            <label>Serie</label>
            <input type="text" name="serie" maxlength="30" value="<?php echo $equipo_editar ? $equipo_editar['serie'] : ''; ?>">
        </div>

        <div class="form-group">
            <label>Tipo de Servicio</label>
            <select name="tipo_servicio" required>
                <option value="preventivo" <?php echo ($equipo_editar && $equipo_editar['tipo_servicio']=='preventivo') ? 'selected' : ''; ?>>Preventivo</option>
                <option value="correctivo" <?php echo ($equipo_editar && $equipo_editar['tipo_servicio']=='correctivo') ? 'selected' : ''; ?>>Correctivo</option>
                <option value="predictivo" <?php echo ($equipo_editar && $equipo_editar['tipo_servicio']=='predictivo') ? 'selected' : ''; ?>>Predictivo</option>
            </select>
        </div>

        <div class="form-group">
            <label>Fecha Programada</label>
            <input type="date" name="fecha_programada" value="<?php echo $equipo_editar ? $equipo_editar['fecha_programada'] : ''; ?>">
        </div>

        <div class="form-group">
            <label>Fecha de Salida</label>
            <input type="date" name="fecha_salida" value="<?php echo $equipo_editar ? $equipo_editar['fecha_salida'] : ''; ?>">
        </div>

        <div class="form-group">
            <label>Costo Inicial ($)</label>
            <input type="number" step="0.01" min="0" max="999999.99" name="costo_inicial" value="<?php echo $equipo_editar ? $equipo_editar['costo_inicial'] : ''; ?>">
        </div>

        <div class="form-group">
            <label>Costo Final ($)</label>
            <input type="number" step="0.01" min="0" max="999999.99" name="costo_final" value="<?php echo $equipo_editar ? $equipo_editar['costo_final'] : ''; ?>">
        </div>

        <div class="form-group">
            <label>Observación</label>
            <textarea name="observacion" maxlength="200" rows="3"><?php echo $equipo_editar ? $equipo_editar['observacion'] : ''; ?></textarea>
        </div>

        <div class="form-group">
            <label>Categoría de Equipo</label>
            <select name="categoria_equipo" required>
                <option value="computadoras" <?php echo ($equipo_editar && $equipo_editar['categoria_equipo']=='computadoras') ? 'selected' : ''; ?>>Computadoras</option>
                <option value="impresoras" <?php echo ($equipo_editar && $equipo_editar['categoria_equipo']=='impresoras') ? 'selected' : ''; ?>>Impresoras</option>
                <option value="moviles" <?php echo ($equipo_editar && $equipo_editar['categoria_equipo']=='moviles') ? 'selected' : ''; ?>>Móviles</option>
                <option value="servidores" <?php echo ($equipo_editar && $equipo_editar['categoria_equipo']=='servidores') ? 'selected' : ''; ?>>Servidores</option>
                <option value="hardware" <?php echo ($equipo_editar && $equipo_editar['categoria_equipo']=='hardware') ? 'selected' : ''; ?>>Hardware</option>
                <option value="redes" <?php echo ($equipo_editar && $equipo_editar['categoria_equipo']=='redes') ? 'selected' : ''; ?>>Redes</option>
            </select>
        </div>

        <div class="form-group">
            <label>Estado</label>
            <select name="estado">
                <option value="por_hacer" <?php echo ($equipo_editar && $equipo_editar['estado']=='por_hacer') ? 'selected' : ''; ?>>Por Hacer</option>
                <option value="en_espera" <?php echo ($equipo_editar && $equipo_editar['estado']=='en_espera') ? 'selected' : ''; ?>>En Espera</option>
                <option value="en_revision" <?php echo ($equipo_editar && $equipo_editar['estado']=='en_revision') ? 'selected' : ''; ?>>En Revisión</option>
                <option value="terminada" <?php echo ($equipo_editar && $equipo_editar['estado']=='terminada') ? 'selected' : ''; ?>>Terminada</option>
            </select>
        </div>

        <div class="form-group">
            <label>Avance (%)</label>
            <input type="number" min="0" max="100" name="avance" value="<?php echo $equipo_editar ? $equipo_editar['avance'] : 0; ?>">
        </div>

        <div class="button-group">
            <?php if ($equipo_editar): ?>
                <button type="submit" name="actualizar_equipo" class="btn btn-primary">✅ Actualizar Equipo</button>
                <a href="equipos.php" class="btn btn-secondary">❌ Cancelar</a>
            <?php else: ?>
                <button type="submit" name="crear_equipo" class="btn btn-primary">🚀 Crear Equipo</button>
            <?php endif; ?>
        </div>
    </form>
</div>

<!-- Lista de equipos -->
<div class="list-section">
    <h2 class="section-title">📋 Lista de Equipos</h2>

    <!-- Filtros y Búsqueda -->
    <div class="filter-section">
        <form method="GET" action="" style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap; width: 100%;">
            
            <!-- Buscador -->
            <div style="flex: 1; min-width: 250px; position: relative;">
                <label style="display: block; margin-bottom: 5px; font-weight: 500;">🔍 Buscar Equipo:</label>
                <div style="position: relative;">
                    <input 
                        type="text" 
                        name="buscar" 
                        id="search-input"
                        placeholder="Buscar por marca, modelo, serie..." 
                        value="<?php echo isset($_GET['buscar']) ? htmlspecialchars($_GET['buscar']) : ''; ?>"
                        style="width: 100%; padding: 10px 40px 10px 15px; border: 2px solid #ddd; border-radius: 8px; font-size: 14px; transition: all 0.3s;"
                        onfocus="this.style.borderColor='#667eea'"
                        onblur="this.style.borderColor='#ddd'"
                    >
                    <span style="position: absolute; right: 15px; top: 50%; transform: translateY(-50%); color: #999;">🔍</span>
                </div>
            </div>

            <!-- Filtro por Categoría -->
            <div style="flex: 0.8; min-width: 200px;">
                <label style="display: block; margin-bottom: 5px; font-weight: 500;">🏷️ Categoría:</label>
                <select 
                        name="categoria" 
                        id="categoria-filter"
                        style="width: 100%; padding: 10px; border: 2px solid #ddd; border-radius: 8px; font-size: 14px; background: white; cursor: pointer; color: #333;"
                    >
                    <option value="todos" <?php echo ($filtro_categoria == '' || $filtro_categoria == 'todos') ? 'selected' : ''; ?>>Todos</option>
                    <option value="computadoras" <?php echo $filtro_categoria == 'computadoras' ? 'selected' : ''; ?>>💻 Computadoras</option>
                    <option value="impresoras" <?php echo $filtro_categoria == 'impresoras' ? 'selected' : ''; ?>>🖨️ Impresoras</option>
                    <option value="moviles" <?php echo $filtro_categoria == 'moviles' ? 'selected' : ''; ?>>📱 Móviles</option>
                    <option value="servidores" <?php echo $filtro_categoria == 'servidores' ? 'selected' : ''; ?>>🖥️ Servidores</option>
                    <option value="hardware" <?php echo $filtro_categoria == 'hardware' ? 'selected' : ''; ?>>🔌 Hardware</option>
                    <option value="redes" <?php echo $filtro_categoria == 'redes' ? 'selected' : ''; ?>>📡 Redes</option>
                </select>
            </div>

            <!-- Mantener paginación de eliminados -->
            <?php if (isset($_GET['pagina_eliminados'])): ?>
                <input type="hidden" name="pagina_eliminados" value="<?php echo $_GET['pagina_eliminados']; ?>">
            <?php endif; ?>

            <!-- Botones -->
            <div style="display: flex; gap: 10px; align-items: flex-end;">
                <button type="submit" class="filter-btn" style="padding: 10px 25px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 8px; font-weight: 500; cursor: pointer; transition: all 0.3s;">
                    🔍 Buscar
                </button>
                <?php if (!empty($_GET['buscar']) || (!empty($filtro_categoria) && $filtro_categoria != 'todos')): ?>
                    <a href="equipos.php<?php echo isset($_GET['pagina_eliminados']) ? '?pagina_eliminados='.$_GET['pagina_eliminados'] : ''; ?>" class="btn" style="padding: 10px 25px; background: #ff6b6b; color: white; text-decoration: none; border-radius: 8px; font-weight: 500; display: inline-flex; align-items: center; gap: 5px; transition: all 0.3s;">
                        ❌ Limpiar
                    </a>
                <?php endif; ?>
            </div>
        </form>
        
        <!-- Contador de resultados -->
        <?php if (!empty($_GET['buscar']) || (!empty($filtro_categoria) && $filtro_categoria != 'todos')): ?>
            <div style="margin-top: 15px; padding: 10px 15px; background: #e8f4f8; border-left: 4px solid #667eea; border-radius: 5px;">
                <strong>
                    <?php 
                    echo "🔍 Se encontraron <span style='color: #667eea;'>$total_equipos</span> resultado(s)";
                    if (!empty($_GET['buscar'])) {
                        echo " para '<em>" . htmlspecialchars($_GET['buscar']) . "</em>'";
                    }
                    ?>
                </strong>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="table-container">
        <?php if ($resultado_equipos && $resultado_equipos->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Equipo</th>
                        <th>Marca</th>
                        <th>Serie</th>
                        <th>Tipo Servicio</th>
                        <th>Fecha Ingreso</th>
                        <th>Fecha Programada</th>
                        <th>Fecha Salida</th>
                        <th>Costo Inicial</th>
                        <th>Costo Final</th>
                        <th>Observación</th>
                        <th>Categoría</th>
                        <th>Estado</th>
                        <th>Avance</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($eq = $resultado_equipos->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $eq['id']; ?></td>
                            <td><?php echo htmlspecialchars($eq['equipo']); ?></td>
                            <td><?php echo htmlspecialchars($eq['marca']); ?></td>
                            <td><?php echo htmlspecialchars($eq['serie']); ?></td>
                            <td><?php echo htmlspecialchars($eq['tipo_servicio']); ?></td>
                            <td><?php echo date('d/m/Y H:i', strtotime($eq['fecha_ingreso'])); ?></td>
                            <td><?php echo $eq['fecha_programada'] ? date('d/m/Y', strtotime($eq['fecha_programada'])) : '-'; ?></td>
                            <td><?php echo $eq['fecha_salida'] ? date('d/m/Y', strtotime($eq['fecha_salida'])) : '-'; ?></td>
                            <td>$<?php echo number_format($eq['costo_inicial'], 2); ?></td>
                            <td>$<?php echo number_format($eq['costo_final'], 2); ?></td>
                            <td><?php echo htmlspecialchars($eq['observacion']); ?></td>
                            <td><?php echo ucfirst(htmlspecialchars($eq['categoria_equipo'])); ?></td>
                            <td>
                                <?php
                                $color_estado = match($eq['estado']) {
                                    'por_hacer' => '#3498db',
                                    'en_espera' => '#f1c40f',
                                    'en_revision' => '#9b59b6',
                                    'terminada' => '#27ae60',
                                    default => '#7f8c8d'
                                };
                                $titulo_estado = [
                                    'por_hacer' => 'Por Hacer',
                                    'en_espera' => 'En Espera',
                                    'en_revision' => 'En Revisión',
                                    'terminada' => 'Terminada'
                                ][$eq['estado']] ?? ucfirst($eq['estado']);
                                ?>
                                <span class="estado-badge" style="background: <?php echo $color_estado; ?>; color: white;">
                                    <?php echo $titulo_estado; ?>
                                </span>
                            </td>
                            <td>
                                <div class="progress-bar-container">
                                    <div class="progress-bar-fill" style="width: <?php echo $eq['avance']; ?>%;">
                                        <?php echo $eq['avance']; ?>%
                                    </div>
                                </div>
                            </td>
                            <td class="actions">
                                <?php
                                // Construir parámetros de URL de forma segura
                                $url_params = array();
                                if (!empty($filtro_categoria) && $filtro_categoria != 'todos') {
                                    $url_params[] = 'categoria=' . urlencode($filtro_categoria);
                                }
                                if (!empty($buscar)) {
                                    $url_params[] = 'buscar=' . urlencode($buscar);
                                }
                                if (isset($_GET['pagina'])) {
                                    $url_params[] = 'pagina=' . intval($_GET['pagina']);
                                }
                                if (isset($_GET['pagina_eliminados'])) {
                                    $url_params[] = 'pagina_eliminados=' . intval($_GET['pagina_eliminados']);
                                }
                                $query_string = !empty($url_params) ? '&' . implode('&', $url_params) : '';
                                ?>
                                <a href="equipos.php?editar=<?php echo $eq['id'] . $query_string; ?>" class="btn btn-warning">✏️ Editar</a>
                                <a href="equipos.php?eliminar=<?php echo $eq['id'] . $query_string; ?>" class="btn btn-danger" onclick="return confirm('¿Seguro que deseas eliminar este equipo?')">🗑️ Eliminar</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            
            <!-- Paginación de equipos activos -->
            <?php if ($total_paginas > 1): ?>
                <div class="pagination">
                    <?php if ($pagina_actual > 1): ?>
                        <a href="?pagina=<?php echo $pagina_actual - 1; ?><?php echo !empty($filtro_categoria) && $filtro_categoria != 'todos' ? '&categoria='.$filtro_categoria : ''; ?><?php echo !empty($buscar) ? '&buscar='.urlencode($buscar) : ''; ?><?php echo isset($_GET['pagina_eliminados']) ? '&pagina_eliminados='.$_GET['pagina_eliminados'] : ''; ?>">« Anterior</a>
                    <?php else: ?>
                        <span class="disabled">« Anterior</span>
                    <?php endif; ?>
                    
                    <?php
                    // Mostrar números de página
                    $rango = 2;
                    $inicio = max(1, $pagina_actual - $rango);
                    $fin = min($total_paginas, $pagina_actual + $rango);
                    
                    if ($inicio > 1) {
                        echo '<a href="?pagina=1' . (!empty($filtro_categoria) && $filtro_categoria != 'todos' ? '&categoria='.$filtro_categoria : '') . (!empty($buscar) ? '&buscar='.urlencode($buscar) : '') . (isset($_GET['pagina_eliminados']) ? '&pagina_eliminados='.$_GET['pagina_eliminados'] : '') . '">1</a>';
                        if ($inicio > 2) echo '<span>...</span>';
                    }
                    
                    for ($i = $inicio; $i <= $fin; $i++) {
                        if ($i == $pagina_actual) {
                            echo '<span class="active">' . $i . '</span>';
                        } else {
                            echo '<a href="?pagina=' . $i . (!empty($filtro_categoria) && $filtro_categoria != 'todos' ? '&categoria='.$filtro_categoria : '') . (!empty($buscar) ? '&buscar='.urlencode($buscar) : '') . (isset($_GET['pagina_eliminados']) ? '&pagina_eliminados='.$_GET['pagina_eliminados'] : '') . '">' . $i . '</a>';
                        }
                    }
                    
                    if ($fin < $total_paginas) {
                        if ($fin < $total_paginas - 1) echo '<span>...</span>';
                        echo '<a href="?pagina=' . $total_paginas . (!empty($filtro_categoria) && $filtro_categoria != 'todos' ? '&categoria='.$filtro_categoria : '') . (!empty($buscar) ? '&buscar='.urlencode($buscar) : '') . (isset($_GET['pagina_eliminados']) ? '&pagina_eliminados='.$_GET['pagina_eliminados'] : '') . '">' . $total_paginas . '</a>';
                    }
                    ?>
                    
                    <?php if ($pagina_actual < $total_paginas): ?>
                        <a href="?pagina=<?php echo $pagina_actual + 1; ?><?php echo !empty($filtro_categoria) && $filtro_categoria != 'todos' ? '&categoria='.$filtro_categoria : ''; ?><?php echo !empty($buscar) ? '&buscar='.urlencode($buscar) : ''; ?><?php echo isset($_GET['pagina_eliminados']) ? '&pagina_eliminados='.$_GET['pagina_eliminados'] : ''; ?>">Siguiente »</a>
                    <?php else: ?>
                        <span class="disabled">Siguiente »</span>
                    <?php endif; ?>
                </div>
                
                <div class="pagination-info">
                    Mostrando <?php echo ($offset + 1); ?> - <?php echo min($offset + $items_por_pagina, $total_equipos); ?> de <?php echo $total_equipos; ?> equipos
                </div>
            <?php endif; ?>
            
        <?php else: ?>
            <div style="text-align: center; padding: 60px 20px; color: #6c757d;">
                <h3 style="font-size: 24px; margin-bottom: 10px;">📭 No hay equipos registrados</h3>
                <?php if (!empty($filtro_categoria) && $filtro_categoria != 'todos'): ?>
                    <p style="font-size: 16px;">No se encontraron equipos en la categoría seleccionada.</p>
                    <a href="equipos.php<?php echo isset($_GET['pagina_eliminados']) ? '?pagina_eliminados='.$_GET['pagina_eliminados'] : ''; ?>" class="btn btn-primary" style="margin-top: 15px;">Ver Todos los Equipos</a>
                <?php elseif (!empty($buscar)): ?>
                    <p style="font-size: 16px;">No se encontraron resultados para tu búsqueda.</p>
                    <a href="equipos.php<?php echo isset($_GET['pagina_eliminados']) ? '?pagina_eliminados='.$_GET['pagina_eliminados'] : ''; ?>" class="btn btn-primary" style="margin-top: 15px;">Limpiar Búsqueda</a>
                <?php else: ?>
                    <p style="font-size: 16px;">Comienza creando tu primer equipo usando el formulario.</p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

</div>

<?php include 'includes/footer.php'; ?>

<script>
// Auto-ocultar mensajes después de 5 segundos
setTimeout(function() {
    document.querySelectorAll('.message').forEach(function(message) {
        message.style.opacity = '0';
        message.style.transition = 'opacity 0.5s';
        setTimeout(() => message.remove(), 500);
    });
}, 5000);

// Highlight de términos buscados (solo en celdas de texto, no en enlaces)
<?php if (!empty($buscar)): ?>
document.addEventListener('DOMContentLoaded', function() {
    const searchTerm = "<?php echo addslashes($buscar); ?>";
    const tbody = document.querySelectorAll('.table-container tbody tr');
    
    tbody.forEach(function(row) {
        if (searchTerm) {
            // Solo resaltar en las celdas de texto, no en la columna de acciones
            const cells = row.querySelectorAll('td:not(.actions)');
            cells.forEach(function(cell) {
                // Solo procesar nodos de texto, no elementos HTML
                const textNodes = [];
                const walker = document.createTreeWalker(cell, NodeFilter.SHOW_TEXT, null, false);
                let node;
                while(node = walker.nextNode()) {
                    textNodes.push(node);
                }
                
                textNodes.forEach(function(textNode) {
                    const text = textNode.textContent;
                    if (text.toLowerCase().includes(searchTerm.toLowerCase())) {
                        const span = document.createElement('span');
                        span.innerHTML = text.replace(
                            new RegExp('(' + searchTerm + ')', 'gi'),
                            '<mark style="background: #fff59d; padding: 2px 4px; border-radius: 3px;">$1</mark>'
                        );
                        textNode.parentNode.replaceChild(span, textNode);
                    }
                });
            });
        }
    });
});
<?php endif; ?>
</script>