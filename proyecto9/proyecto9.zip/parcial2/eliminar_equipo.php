<?php
session_start();
require_once 'conexion_dbs.php';

// Obtener el ID del equipo a eliminar
$id_equipo = $_GET['id'];

// Verificar usuario que elimina (si tienes sistema de login)
$usuario = $_SESSION['usuario'] ?? 'Desconocido';

// Primero obtenemos los datos del equipo
$sql_select = "SELECT * FROM equipos WHERE id = ?";
$stmt_select = $conexion_local->prepare($sql_select);
$stmt_select->bind_param("i", $id_equipo);
$stmt_select->execute();
$result = $stmt_select->get_result();

if ($result->num_rows > 0) {
    $equipo = $result->fetch_assoc();

    // Insertar los datos en equipos_eliminados
    $sql_insert = "INSERT INTO equipos_eliminados 
        (id_equipo_original, nombre_equipo, marca, modelo, serie, fecha_ingreso, eliminado_por, motivo_eliminacion, observaciones)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt_insert = $conexion_local->prepare($sql_insert);
    $motivo = 'Eliminación desde el sistema';
    $obs = 'Registro movido automáticamente';
    $stmt_insert->bind_param(
        "issssssss",
        $equipo['id'],
        $equipo['nombre_equipo'],
        $equipo['marca'],
        $equipo['modelo'],
        $equipo['serie'],
        $equipo['fecha_ingreso'],
        $usuario,
        $motivo,
        $obs
    );
    $stmt_insert->execute();

    // Luego eliminamos el equipo de la tabla principal
    $sql_delete = "DELETE FROM equipos WHERE id = ?";
    $stmt_delete = $conexion_local->prepare($sql_delete);
    $stmt_delete->bind_param("i", $id_equipo);
    $stmt_delete->execute();

    echo "<script>alert('Equipo eliminado correctamente y guardado en historial.'); window.location='equipos.php';</script>";
} else {
    echo "<script>alert('Equipo no encontrado.'); window.location='equipos.php';</script>";
}
?>
