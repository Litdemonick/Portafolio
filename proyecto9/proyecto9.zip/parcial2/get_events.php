<?php
// get_events.php
include 'conexion_dbs.php';
header('Content-Type: application/json');
$year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');
$month = isset($_GET['month']) ? intval($_GET['month']) : date('n');

$desde = sprintf('%04d-%02d-01', $year, $month);
$hasta = date('Y-m-d', strtotime("$desde +1 month -1 day"));

$stmt = $conexion_local->prepare("SELECT id, equipo, tipo_mantenimiento, fecha_programada FROM equipos WHERE fecha_programada BETWEEN ? AND ?");
$stmt->bind_param('ss', $desde, $hasta);
$stmt->execute();
$res = $stmt->get_result();
$events = [];
while ($r = $res->fetch_assoc()) $events[] = $r;
echo json_encode(['ok'=>true,'events'=>$events]);
