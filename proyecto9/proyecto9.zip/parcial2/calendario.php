<?php
session_start();
require_once 'conexion_dbs.php';
require_once 'auth.php';
verificarStaff(); // Solo usuarios con rol staff o admin
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendario de Mantenimientos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css">
    <link rel="stylesheet" href="css/estilo.css">
    <style>
        :root {
    --bg-primary: #4d4c4cff;
    --bg-secondary: #1e1e1e;
    --bg-tertiary: #979494ff;
    --text-primary: #e0e0e0;
    --text-secondary: #b0b0b0;
    --border-color: #cc0000ff;
    --accent-blue: #00b4d8;
    --accent-blue-hover: #0096b8;
}

/* Ajustes para mejorar visibilidad con bg-tertiary gris claro */
.fc-col-header-cell {
    background: var(--bg-secondary) !important; /* Cambio de bg-tertiary a bg-secondary */
    color: var(--accent-blue);
    font-weight: 700;
    text-transform: uppercase;
    font-size: 0.85rem;
    letter-spacing: 0.5px;
    padding: 15px 5px;
    border: 1px solid var(--border-color);
}

.fc-daygrid-day:hover {
    background: #2a2a2a !important; /* Color más oscuro para hover */
}

.form-check:hover {
    background: #2a2a2a; /* Color más oscuro para hover de checkboxes */
}

.form-check-input {
    background-color: var(--bg-secondary); /* Cambio para mejor contraste */
    border: 2px solid #555;
    width: 1.25rem;
    height: 1.25rem;
    cursor: pointer;
    transition: all 0.2s;
}

.legend-item:hover {
    background: #2a2a2a; /* Color más oscuro para hover */
}

/* Ajuste para modal-header */
.modal-header {
    border-bottom: 1px solid var(--border-color);
    border-radius: 16px 16px 0 0;
    padding: 1.5rem;
    background: linear-gradient(135deg, var(--bg-secondary) 0%, #1a1a1a 100%); /* Cambio de bg-tertiary */
}

/* Ajuste para progress bar */
.progress {
    background-color: var(--bg-secondary); /* Cambio para mejor contraste */
    border-radius: 8px;
    height: 24px;
    overflow: hidden;
    box-shadow: inset 0 2px 4px rgba(0,0,0,0.2);
}

/* Ajuste para stats-card */
.stats-card {
    background: linear-gradient(135deg, var(--bg-secondary) 0%, #2a2a2a 100%); /* Cambio para mejor contraste */
    border-left: 4px solid var(--accent-blue);
    padding: 1rem;
    border-radius: 10px;
    margin-bottom: 1rem;
    transition: all 0.2s;
}

/* Ajuste para observación en modal */
.modal-body .observacion-box {
    background: var(--bg-secondary) !important; /* Mejor contraste */
    border-radius: 8px;
    border-left: 4px solid var(--accent-blue);
    color: var(--text-primary);
}

/* Ajuste para botón secondary */
.btn-secondary {
    background: var(--bg-secondary); /* Cambio para mejor contraste */
    border: 1px solid var(--border-color);
    color: var(--text-primary);
}

/* Ajuste para popover */
.fc-popover-header {
    background: var(--bg-secondary) !important; /* Cambio para mejor contraste */
    color: var(--text-primary) !important;
    border-radius: 12px 12px 0 0 !important;
    font-weight: 700;
}

/* Ajuste para scrollbar */
::-webkit-scrollbar-thumb {
    background: var(--bg-secondary); /* Cambio para mejor contraste */
    border-radius: 5px;
}

/* Ajuste para lista de FullCalendar */
.fc-list-event:hover {
    background: #2a2a2a !important; /* Color más oscuro para hover */
}

.fc-list-day-cushion {
    background: var(--bg-secondary) !important; /* Cambio para mejor contraste */
    color: var(--accent-blue) !important;
    font-weight: 700;
}

/* Mejor contraste para números del día */
.fc-daygrid-day-number {
    color: #ffffff !important; /* Blanco puro para mejor visibilidad */
    font-size: 0.95rem;
    font-weight: 600;
    padding: 8px;
}
        body {
            background: var(--bg-primary);
            color: var(--text-primary);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .container-fluid {
            background: var(--bg-primary);
            min-height: 100vh;
        }
        
        .card {
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            border-radius: 12px;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(0, 180, 216, 0.1);
        }
        
        .card-header {
            border-bottom: 1px solid var(--border-color);
            border-radius: 12px 12px 0 0 !important;
            padding: 1rem 1.25rem;
            font-weight: 600;
            color: white;
        }
        
        .breadcrumb {
            background: var(--bg-secondary);
            padding: 12px 20px;
            border-radius: 10px;
            border: 1px solid var(--border-color);
        }
        
        .breadcrumb-item a {
            color: var(--accent-blue);
            text-decoration: none;
            transition: color 0.2s;
        }

        .breadcrumb-item a:hover {
            color: var(--accent-blue-hover);
        }
        
        .breadcrumb-item.active {
            color: var(--text-secondary);
        }

        .page-title {
            color: var(--text-primary);
            font-weight: 700;
        }

        .page-subtitle {
            color: var(--text-secondary);
            font-size: 0.95rem;
        }

        /* Mejoras al calendario */
        .fc {
            background: var(--bg-secondary);
            color: var(--text-primary);
            border-radius: 12px;
            padding: 20px;
        }
        
        .fc-theme-standard td,
        .fc-theme-standard th {
            border-color: var(--border-color);
        }
        
        .fc-col-header-cell {
            background: var(--bg-tertiary);
            color: var(--accent-blue);
            font-weight: 700;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
            padding: 15px 5px;
            border: 1px solid var(--border-color);
        }
        
        .fc-daygrid-day {
            background: var(--bg-secondary);
            transition: background 0.2s;
            min-height: 120px;
        }
        
        .fc-daygrid-day:hover {
            background: var(--bg-tertiary);
        }
        
        .fc-day-today {
            background: rgba(0, 180, 216, 0.1) !important;
            border: 2px solid var(--accent-blue) !important;
        }

        .fc-day-today .fc-daygrid-day-number {
            background: var(--accent-blue);
            color: white;
            border-radius: 50%;
            width: 32px;
            height: 32px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        
        .fc-button {
            background: var(--accent-blue) !important;
            border-color: var(--accent-blue) !important;
            color: white !important;
            border-radius: 8px !important;
            padding: 8px 16px !important;
            font-weight: 600 !important;
            text-transform: uppercase;
            font-size: 0.85rem;
            transition: all 0.2s !important;
        }
        
        .fc-button:hover {
            background: var(--accent-blue-hover) !important;
            border-color: var(--accent-blue-hover) !important;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 180, 216, 0.3);
        }
        
        .fc-button-active {
            background: #0078ff !important;
            border-color: #0078ff !important;
            box-shadow: inset 0 2px 4px rgba(0,0,0,0.3);
        }

        .fc-button:disabled {
            opacity: 0.4 !important;
        }
        
        .fc-daygrid-day-number {
            color: var(--text-primary);
            font-size: 0.95rem;
            font-weight: 600;
            padding: 8px;
        }

        .fc-daygrid-day-top {
            flex-direction: row;
            justify-content: center;
        }

        .fc-scrollgrid {
            border-color: var(--border-color) !important;
            border-radius: 8px;
            overflow: hidden;
        }

        .fc-toolbar-title {
            font-size: 1.75rem !important;
            font-weight: 700 !important;
            color: var(--text-primary);
            text-transform: capitalize;
        }

        /* Eventos mejorados y escalables */
        .fc-event {
            cursor: pointer;
            border-radius: 6px;
            padding: 4px 6px;
            font-size: 0.75rem;
            margin: 1px 2px;
            border: none !important;
            font-weight: 500;
            transition: all 0.2s;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            position: relative;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }

        .fc-event:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 12px rgba(0,0,0,0.4);
            z-index: 10;
        }

        .fc-event-title {
            font-weight: 600;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .fc-event-time {
            display: none;
        }

        .fc-daygrid-day-events {
            margin-top: 2px;
        }

        .fc-daygrid-more-link {
            background: var(--accent-blue) !important;
            color: white !important;
            border-radius: 4px;
            padding: 2px 6px;
            font-size: 0.7rem;
            font-weight: 600;
            margin: 2px;
            transition: all 0.2s;
        }

        .fc-daygrid-more-link:hover {
            background: var(--accent-blue-hover) !important;
            transform: scale(1.05);
        }

        /* Colores por tipo de servicio */
        .event-preventivo {
            background: linear-gradient(135deg, #ffc107 0%, #ffb300 100%);
            color: #000;
        }
        
        .event-correctivo {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            color: white;
        }
        
        .event-predictivo {
            background: linear-gradient(135deg, #28a745 0%, #218838 100%);
            color: white;
        }
        
        /* Indicadores de estado */
        .event-estado-por_hacer {
            opacity: 0.75;
            border-left: 4px solid #3498db !important;
        }
        
        .event-estado-en_espera {
            opacity: 0.85;
            border-left: 4px solid #f1c40f !important;
        }
        
        .event-estado-en_revision {
            opacity: 0.95;
            border-left: 4px solid #9b59b6 !important;
        }
        
        .event-estado-terminada {
            opacity: 1;
            font-weight: 700;
            border-left: 4px solid #27ae60 !important;
        }

        /* Íconos para eventos */
        .fc-event::before {
            font-family: "Font Awesome 6 Free";
            font-weight: 900;
            margin-right: 4px;
            font-size: 0.7rem;
        }

        .event-preventivo::before {
            content: "\f0ad";
        }

        .event-correctivo::before {
            content: "\f7d9";
        }

        .event-predictivo::before {
            content: "\f080";
        }

        /* Vista de lista mejorada */
        .fc-list-event {
            background: var(--bg-secondary) !important;
            border-left: 4px solid var(--accent-blue) !important;
        }

        .fc-list-event:hover {
            background: var(--bg-tertiary) !important;
        }

        .fc-list-event-dot {
            display: none;
        }

        .fc-list-day-cushion {
            background: var(--bg-tertiary) !important;
            color: var(--accent-blue) !important;
            font-weight: 700;
        }
        
        /* Modal mejorado */
        .modal-content {
            background: var(--bg-secondary);
            color: var(--text-primary);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.5);
        }
        
        .modal-header {
            border-bottom: 1px solid var(--border-color);
            border-radius: 16px 16px 0 0;
            padding: 1.5rem;
            background: linear-gradient(135deg, var(--bg-tertiary) 0%, var(--bg-secondary) 100%);
        }

        .modal-title {
            font-weight: 700;
            font-size: 1.5rem;
            color: var(--text-primary);
        }
        
        .modal-footer {
            border-top: 1px solid var(--border-color);
            padding: 1.5rem;
            background: var(--bg-secondary);
        }
        
        .btn-close {
            filter: invert(1);
            opacity: 0.8;
            transition: opacity 0.2s;
        }

        .btn-close:hover {
            opacity: 1;
        }

        .modal-body {
            padding: 1.5rem;
        }

        .modal-body .row > div {
            margin-bottom: 1rem;
        }

        .modal-body strong {
            color: var(--accent-blue);
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            display: block;
            margin-bottom: 0.25rem;
        }

        .modal-body .fs-5 {
            color: var(--text-primary);
            font-weight: 600;
        }

        .modal-body .mt-1 {
            color: var(--text-primary);
        }
        
        /* Checkboxes mejorados */
        .form-check {
            padding: 0.5rem;
            border-radius: 8px;
            transition: background 0.2s;
        }

        .form-check:hover {
            background: var(--bg-tertiary);
        }

        .form-check-input {
            background-color: var(--bg-tertiary);
            border: 2px solid #555;
            width: 1.25rem;
            height: 1.25rem;
            cursor: pointer;
            transition: all 0.2s;
        }

        .form-check-input:hover {
            border-color: var(--accent-blue);
        }
        
        .form-check-input:checked {
            background-color: var(--accent-blue);
            border-color: var(--accent-blue);
        }

        .form-check-label {
            cursor: pointer;
            user-select: none;
            font-weight: 500;
            color: var(--text-primary);
        }
        
        /* Progress bar mejorado */
        .progress {
            background-color: var(--bg-tertiary);
            border-radius: 8px;
            height: 24px;
            overflow: hidden;
            box-shadow: inset 0 2px 4px rgba(0,0,0,0.2);
        }

        .progress-bar {
            font-weight: 700;
            font-size: 0.8rem;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: width 0.6s ease;
        }
        
        /* Legend box mejorado */
        .legend-box {
            width: 24px;
            height: 24px;
            border-radius: 6px;
            display: inline-block;
            box-shadow: 0 2px 4px rgba(0,0,0,0.3);
            transition: transform 0.2s;
        }

        .legend-item {
            padding: 0.5rem;
            border-radius: 8px;
            transition: background 0.2s;
        }

        .legend-item:hover {
            background: var(--bg-tertiary);
        }

        .legend-item:hover .legend-box {
            transform: scale(1.1);
        }

        .legend-item span {
            color: var(--text-primary);
        }
        
        .text-muted {
            color: var(--text-secondary) !important;
        }

        /* Badges mejorados */
        .badge {
            padding: 0.5rem 0.75rem;
            font-size: 0.8rem;
            font-weight: 600;
            border-radius: 6px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        /* Botones mejorados */
        .btn {
            border-radius: 8px;
            padding: 0.6rem 1.5rem;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.85rem;
            transition: all 0.2s;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--accent-blue) 0%, var(--accent-blue-hover) 100%);
            border: none;
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(0, 180, 216, 0.4);
        }

        .btn-secondary {
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
        }

        .btn-secondary:hover {
            background: var(--bg-primary);
            border-color: var(--accent-blue);
            color: var(--text-primary);
        }
        /* Mini Calendario de Navegación */
        input[type="date"] {
            cursor: pointer;
            padding: 0.6rem;
            font-size: 0.9rem;
            border-radius: 8px;
            transition: all 0.2s;
        }

        input[type="date"]:hover {
            border-color: var(--accent-blue) !important;
            box-shadow: 0 0 0 0.2rem rgba(0, 180, 216, 0.25);
        }

        input[type="date"]:focus {
            border-color: var(--accent-blue) !important;
            box-shadow: 0 0 0 0.2rem rgba(0, 180, 216, 0.25);
            outline: none;
        }

        /* Calendario nativo - estilos oscuros */
        input[type="date"]::-webkit-calendar-picker-indicator {
            filter: invert(0.7);
            cursor: pointer;
            padding: 4px;
            border-radius: 4px;
            transition: all 0.2s;
        }

        input[type="date"]::-webkit-calendar-picker-indicator:hover {
            filter: invert(1);
            background: var(--accent-blue);
        }

        /* Estadísticas rápidas */
        .stats-card {
            background: linear-gradient(135deg, var(--bg-tertiary) 0%, var(--bg-secondary) 100%);
            border-left: 4px solid var(--accent-blue);
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1rem;
            transition: all 0.2s;
        }

        .stats-card:hover {
            transform: translateX(4px);
            border-left-width: 6px;
        }

        .stats-number {
            font-size: 2rem;
            font-weight: 700;
            color: var(--accent-blue);
            line-height: 1;
        }

        .stats-label {
            font-size: 0.85rem;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-top: 0.25rem;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .fc-toolbar-title {
                font-size: 1.25rem !important;
            }

            .fc-button {
                padding: 6px 10px !important;
                font-size: 0.75rem !important;
            }

            .fc-daygrid-day {
                min-height: 80px;
            }

            .fc-event {
                font-size: 0.65rem;
                padding: 2px 4px;
            }

            .card-header h6 {
                font-size: 0.9rem;
            }

            .stats-number {
                font-size: 1.5rem;
            }
        }

        /* Animaciones */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .card {
            animation: fadeIn 0.4s ease-out;
        }

        /* Scrollbar personalizado */
        ::-webkit-scrollbar {
            width: 10px;
            height: 10px;
        }

        ::-webkit-scrollbar-track {
            background: var(--bg-secondary);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--bg-tertiary);
            border-radius: 5px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }

        /* Popover */
        .fc-popover {
            background: var(--bg-secondary) !important;
            border: 1px solid var(--border-color) !important;
            border-radius: 12px !important;
            box-shadow: 0 8px 24px rgba(0,0,0,0.4) !important;
        }

        .fc-popover-header {
            background: var(--bg-tertiary) !important;
            color: var(--text-primary) !important;
            border-radius: 12px 12px 0 0 !important;
            font-weight: 700;
        }

        .fc-popover-close {
            color: var(--text-primary) !important;
            opacity: 0.8;
        }

        .fc-popover-close:hover {
            opacity: 1;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container-fluid py-4">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-3">
                            <li class="breadcrumb-item"><a href="index.php"><i class="fas fa-home me-1"></i>Inicio</a></li>
                            <li class="breadcrumb-item active"><i class="fas fa-calendar-alt me-1"></i>Calendario</li>
                        </ol>
                    </nav>
                    <h1 class="h2 mb-2 page-title"><i class="fas fa-calendar-alt me-2" style="color: var(--accent-blue);"></i>Calendario de Mantenimientos</h1>
                    <p class="page-subtitle">Visualiza y gestiona la agenda mensual de todos los mantenimientos programados</p>
                </div>
            </div>

            <div class="row mb-4">
                <div class="col-lg-9 mb-3">
                    <div class="card shadow-lg">
                        <div class="card-body p-3">
                            <div id="calendar"></div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3">
                    <!-- Mini Calendario de Navegación -->
<div class="card shadow-sm mb-3">
    <div class="card-header" style="background: linear-gradient(135deg, #00b4d8 0%, #0096b8 100%);">
        <h6 class="mb-0"><i class="fas fa-calendar me-2"></i>Navegación Rápida</h6>
    </div>
    <div class="card-body p-2">
        <input type="date" id="miniCalendar" class="form-control" 
               style="background: var(--bg-tertiary); color: var(--text-primary); border: 1px solid var(--border-color);">
        <div class="d-grid gap-2 mt-2">
            <button id="btnHoy" class="btn btn-sm btn-primary">
                <i class="fas fa-calendar-day me-1"></i>Ir a Hoy
            </button>
        </div>
    </div>
</div>
                    <!-- Estadísticas rápidas -->
                    <div class="card shadow-sm mb-3">
                        <div class="card-header" style="background: linear-gradient(135deg, #00b4d8 0%, #0096b8 100%);">
                            <h6 class="mb-0"><i class="fas fa-chart-pie me-2"></i>Estadísticas</h6>
                        </div>
                        <div class="card-body p-3">
                            <div class="stats-card">
                                <div class="stats-number" id="totalEventos">0</div>
                                <div class="stats-label">Total Eventos</div>
                            </div>
                            <div class="stats-card" style="border-left-color: #ffc107;">
                                <div class="stats-number" style="color: #ffc107;" id="totalPreventivos">0</div>
                                <div class="stats-label">Preventivos</div>
                            </div>
                            <div class="stats-card" style="border-left-color: #dc3545;">
                                <div class="stats-number" style="color: #dc3545;" id="totalCorrectivos">0</div>
                                <div class="stats-label">Correctivos</div>
                            </div>
                            <div class="stats-card" style="border-left-color: #28a745;">
                                <div class="stats-number" style="color: #28a745;" id="totalPredictivos">0</div>
                                <div class="stats-label">Predictivos</div>
                            </div>
                        </div>
                    </div>

                    <!-- Filtros por Tipo -->
                    <div class="card shadow-sm mb-3">
                        <div class="card-header" style="background: linear-gradient(135deg, #9b59b6 0%, #8e44ad 100%);">
                            <h6 class="mb-0"><i class="fas fa-filter me-2"></i>Filtros por Tipo</h6>
                        </div>
                        <div class="card-body p-3">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="preventivo" id="filterPreventivo" checked>
                                <label class="form-check-label" for="filterPreventivo">
                                    <span class="badge bg-warning text-dark"><i class="fas fa-wrench me-1"></i>Preventivo</span>
                                </label>
                            </div>
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="correctivo" id="filterCorrectivo" checked>
                                <label class="form-check-label" for="filterCorrectivo">
                                    <span class="badge bg-danger"><i class="fas fa-tools me-1"></i>Correctivo</span>
                                </label>
                            </div>
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="predictivo" id="filterPredictivo" checked>
                                <label class="form-check-label" for="filterPredictivo">
                                    <span class="badge bg-success"><i class="fas fa-chart-area me-1"></i>Predictivo</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Filtros por Estado -->
                    <div class="card shadow-sm mb-3">
                        <div class="card-header" style="background: linear-gradient(135deg, #6c757d 0%, #5a6268 100%);">
                            <h6 class="mb-0"><i class="fas fa-tasks me-2"></i>Filtros por Estado</h6>
                        </div>
                        <div class="card-body p-3">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="por_hacer" id="filterPorHacer" checked>
                                <label class="form-check-label" for="filterPorHacer">
                                    <span class="badge" style="background: #3498db;"><i class="fas fa-clock me-1"></i>Por Hacer</span>
                                </label>
                            </div>
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="en_espera" id="filterEnEspera" checked>
                                <label class="form-check-label" for="filterEnEspera">
                                    <span class="badge" style="background: #f1c40f; color: #000;"><i class="fas fa-pause me-1"></i>En Espera</span>
                                </label>
                            </div>
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="en_revision" id="filterEnRevision" checked>
                                <label class="form-check-label" for="filterEnRevision">
                                    <span class="badge" style="background: #9b59b6;"><i class="fas fa-search me-1"></i>En Revisión</span>
                                </label>
                            </div>
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" value="terminada" id="filterTerminada" checked>
                                <label class="form-check-label" for="filterTerminada">
                                    <span class="badge" style="background: #27ae60;"><i class="fas fa-check-circle me-1"></i>Terminada</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Referencia Visual -->
                    <div class="card shadow-sm">
                        <div class="card-header" style="background: linear-gradient(135deg, #17a2b8 0%, #138496 100%);">
                            <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>Referencia Visual</h6>
                        </div>
                        <div class="card-body p-3">
                            <h6 class="mb-3 mt-2" style="color: var(--accent-blue); font-size: 0.9rem;">Tipos:</h6>
                            <div class="legend-item d-flex align-items-center mb-2">
                                <div class="legend-box me-2" style="background: linear-gradient(135deg, #ffc107 0%, #ffb300 100%);"></div>
                                <span style="font-size: 0.9rem;">Preventivo</span>
                            </div>
                            <div class="legend-item d-flex align-items-center mb-2">
                                <div class="legend-box me-2" style="background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);"></div>
                                <span style="font-size: 0.9rem;">Correctivo</span>
                            </div>
                            <div class="legend-item d-flex align-items-center mb-3">
                                <div class="legend-box me-2" style="background: linear-gradient(135deg, #28a745 0%, #218838 100%);"></div>
                                <span style="font-size: 0.9rem;">Predictivo</span>
                            </div>
                            
                            <h6 class="mb-3 mt-4" style="color: var(--accent-blue); font-size: 0.9rem;">Estados:</h6>
                            <div class="legend-item d-flex align-items-center mb-2">
                                <div class="legend-box me-2" style="background: #3498db;"></div>
                                <span style="font-size: 0.9rem;">Por Hacer</span>
                            </div>
                            <div class="legend-item d-flex align-items-center mb-2">
                                <div class="legend-box me-2" style="background: #f1c40f;"></div>
                                <span style="font-size: 0.9rem;">En Espera</span>
                            </div>
                            <div class="legend-item d-flex align-items-center mb-2">
                                <div class="legend-box me-2" style="background: #9b59b6;"></div>
                                <span style="font-size: 0.9rem;">En Revisión</span>
                            </div>
                            <div class="legend-item d-flex align-items-center mb-2">
                                <div class="legend-box me-2" style="background: #27ae60;"></div>
                                <span style="font-size: 0.9rem;">Terminada</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para detalles del evento -->
    <div class="modal fade" id="eventModal" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="eventModalTitle"><i class="fas fa-info-circle me-2"></i>Detalles del Mantenimiento</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="eventModalContent">
                        <!-- Contenido dinámico -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="fas fa-times me-2"></i>Cerrar</button>
                    <a href="#" id="btnEditarEquipo" class="btn btn-primary"><i class="fas fa-edit me-2"></i>Editar Equipo</a>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/locales/es.js"></script>
    <script src="scripts/protect.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');
            var allEvents = [];
            var currentStats = {
                total: 0,
                preventivos: 0,
                correctivos: 0,
                predictivos: 0
            };

            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                locale: 'es',
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,listWeek'
                },
                buttonText: {
                    today: 'Hoy',
                    month: 'Mes',
                    week: 'Semana',
                    day: 'Día',
                    list: 'Lista'
                },
                height: 'auto',
                dayMaxEvents: 3,
                moreLinkClick: 'popover',
                moreLinkText: function(num) {
                    return '+' + num + ' más';
                },
                events: function(info, successCallback, failureCallback) {
                    var tiposActivos = [];
                    var estadosActivos = [];
                    
                    document.querySelectorAll('input[type="checkbox"][id^="filter"]').forEach(function(checkbox) {
                        if (checkbox.checked) {
                            if (checkbox.id.includes('Preventivo') || checkbox.id.includes('Correctivo') || checkbox.id.includes('Predictivo')) {
                                tiposActivos.push(checkbox.value);
                            } else {
                                estadosActivos.push(checkbox.value);
                            }
                        }
                    });
                    
                    fetch('get_calendar_events.php?tipos=' + tiposActivos.join(',') + '&estados=' + estadosActivos.join(','))
                        .then(response => response.json())
                        .then(data => {
                            allEvents = data;
                            updateStats(data);
                            successCallback(data);
                        })
                        .catch(error => {
                            console.error('Error al cargar eventos:', error);
                            failureCallback(error);
                        });
                },
                eventClick: function(info) {
                    var event = info.event;
                    var tipoClass = '';
                    var tipoText = '';
                    var tipoIcon = '';
                    var estadoClass = '';
                    var estadoText = '';
                    var estadoIcon = '';
                    
                    switch(event.extendedProps.tipo) {
                        case 'predictivo':
                            tipoClass = 'success';
                            tipoText = 'Predictivo';
                            tipoIcon = 'fa-chart-area';
                            break;
                        case 'preventivo':
                            tipoClass = 'warning text-dark';
                            tipoText = 'Preventivo';
                            tipoIcon = 'fa-wrench';
                            break;
                        case 'correctivo':
                            tipoClass = 'danger';
                            tipoText = 'Correctivo';
                            tipoIcon = 'fa-tools';
                            break;
                    }
                    
                    switch(event.extendedProps.estado) {
                        case 'por_hacer':
                            estadoClass = '#3498db';
                            estadoText = 'Por Hacer';
                            estadoIcon = 'fa-clock';
                            break;
                        case 'en_espera':
                            estadoClass = '#f1c40f';
                            estadoText = 'En Espera';
                            estadoIcon = 'fa-pause';
                            break;
                        case 'en_revision':
                            estadoClass = '#9b59b6';
                            estadoText = 'En Revisión';
                            estadoIcon = 'fa-search';
                            break;
                        case 'terminada':
                            estadoClass = '#27ae60';
                            estadoText = 'Terminada';
                            estadoIcon = 'fa-check-circle';
                            break;
                    }

                    var avance = event.extendedProps.avance || 0;
                    var progressColor = avance < 30 ? '#dc3545' : avance < 70 ? '#ffc107' : '#28a745';

                  var modalContent = `
    <div class="row g-3">
        <div class="col-md-6">
            <strong><i class="fas fa-server me-2"></i>Equipo</strong>
            <div class="fs-5 mt-1" style="color:  #0f0f0fff;">${event.title}</div>
        </div>
        <div class="col-md-6">
            <strong><i class="fas fa-hashtag me-2"></i>ID</strong>
            <div class="fs-5 mt-1" style="color:  #0f0f0fff;">#${event.extendedProps.id}</div>
        </div>
        <div class="col-md-6">
            <strong><i class="fas fa-tag me-2"></i>Marca</strong>
            <div class="mt-1" style="color:  #0f0f0fff;">${event.extendedProps.marca || 'No especificada'}</div>
        </div>
        <div class="col-md-6">
            <strong><i class="fas fa-barcode me-2"></i>Serie</strong>
            <div class="mt-1" style="color:  #0f0f0fff;">${event.extendedProps.serie || 'No especificada'}</div>
        </div>
        <div class="col-md-6">
            <strong><i class="fas fa-folder me-2"></i>Categoría</strong>
            <div class="mt-1" style="color:  #0f0f0fff;">${event.extendedProps.categoria ? event.extendedProps.categoria.charAt(0).toUpperCase() + event.extendedProps.categoria.slice(1) : 'No especificada'}</div>
        </div>
        <div class="col-md-6">
            <strong style="color: var(--accent-blue);"><i class="fas ${tipoIcon} me-2"></i>Tipo de Servicio</strong>
            <div class="mt-1"><span class="badge bg-${tipoClass}">${tipoText}</span></div>
        </div>
        <div class="col-md-6">
            <strong style="color: var(--accent-blue);"><i class="fas ${estadoIcon} me-2"></i>Estado</strong>
            <div class="mt-1"><span class="badge" style="background: ${estadoClass}; color: white;">${estadoText}</span></div>
        </div>
        <div class="col-md-6">
            <strong style="color: var(--accent-blue);"><i class="fas fa-chart-line me-2"></i>Avance</strong>
            <div class="progress mt-2" style="background-color: var(--bg-secondary);">
                <div class="progress-bar" role="progressbar" 
                     style="width: ${avance}%; background: ${progressColor};">
                    ${avance}%
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <strong style="color: var(--accent-blue);"><i class="fas fa-calendar-check me-2"></i>Fecha Programada</strong>
            <div class="mt-1" style="color:  #0f0f0fff;">${event.start ? event.start.toLocaleDateString('es-ES', {year: 'numeric', month: 'long', day: 'numeric'}) : 'No especificada'}</div>
        </div>
        <div class="col-md-6">
            <strong style="color: var(--accent-blue);"><i class="fas fa-calendar-times me-2"></i>Fecha de Salida</strong>
            <div class="mt-1" style="color:  #0f0f0fff;;">${event.extendedProps.fecha_salida || 'No especificada'}</div>
        </div>
        <div class="col-md-6">
            <strong style="color: var(--accent-blue);"><i class="fas fa-dollar-sign me-2"></i>Costo Inicial</strong>
            <div class="mt-1 fs-5" style="color: #ffc107;">$${parseFloat(event.extendedProps.costo_inicial || 0).toFixed(2)}</div>
        </div>
        <div class="col-md-6">
            <strong style="color: var(--accent-blue);"><i class="fas fa-dollar-sign me-2"></i>Costo Final</strong>
            <div class="mt-1 fs-5" style="color: #28a745;">$${parseFloat(event.extendedProps.costo_final || 0).toFixed(2)}</div>
        </div>
        <div class="col-12">
            <strong style="color: var(--accent-blue);"><i class="fas fa-comment-alt me-2"></i>Observación</strong>
            <div class="mt-2 p-3" style="background: #1a1a1a; border-radius: 8px; border-left: 4px solid var(--accent-blue); color: var(--text-primary);">
                ${event.extendedProps.observacion || 'Sin observaciones'}
            </div>
        </div>
    </div>
`;

                    document.getElementById('eventModalTitle').innerHTML = '<i class="fas fa-wrench me-2"></i>Mantenimiento: ' + event.title;
                    document.getElementById('eventModalContent').innerHTML = modalContent;
                    document.getElementById('btnEditarEquipo').href = 'equipos.php?editar=' + event.extendedProps.id;
                    
                    var modal = new bootstrap.Modal(document.getElementById('eventModal'));
                    modal.show();
                },
                eventDidMount: function(info) {
                    if (info.event.extendedProps.tipo === 'predictivo') {
                        info.el.classList.add('event-predictivo');
                    } else if (info.event.extendedProps.tipo === 'preventivo') {
                        info.el.classList.add('event-preventivo');
                    } else if (info.event.extendedProps.tipo === 'correctivo') {
                        info.el.classList.add('event-correctivo');
                    }
                    
                    if (info.event.extendedProps.estado) {
                        info.el.classList.add('event-estado-' + info.event.extendedProps.estado);
                    }

                    info.el.title = info.event.title + ' - ' + 
                                   (info.event.extendedProps.tipo ? info.event.extendedProps.tipo.charAt(0).toUpperCase() + info.event.extendedProps.tipo.slice(1) : '') + 
                                   '\nEstado: ' + (info.event.extendedProps.estado ? info.event.extendedProps.estado.replace('_', ' ').charAt(0).toUpperCase() + info.event.extendedProps.estado.replace('_', ' ').slice(1) : '') +
                                   '\nAvance: ' + (info.event.extendedProps.avance || 0) + '%';
                },
                eventMouseEnter: function(info) {
                    info.el.style.zIndex = '100';
                },
                eventMouseLeave: function(info) {
                    info.el.style.zIndex = '';
                }
            });

            calendar.render();

            // Función mejorada para actualizar estadísticas SIN animación cuando los valores disminuyen
            function updateStats(events) {
                var total = events.length;
                var preventivos = events.filter(e => e.extendedProps && e.extendedProps.tipo === 'preventivo').length;
                var correctivos = events.filter(e => e.extendedProps && e.extendedProps.tipo === 'correctivo').length;
                var predictivos = events.filter(e => e.extendedProps && e.extendedProps.tipo === 'predictivo').length;

                // Solo animar si los números aumentan
                if (total >= currentStats.total) {
                    animateValue('totalEventos', currentStats.total, total, 600);
                } else {
                    document.getElementById('totalEventos').textContent = total;
                }

                if (preventivos >= currentStats.preventivos) {
                    animateValue('totalPreventivos', currentStats.preventivos, preventivos, 600);
                } else {
                    document.getElementById('totalPreventivos').textContent = preventivos;
                }

                if (correctivos >= currentStats.correctivos) {
                    animateValue('totalCorrectivos', currentStats.correctivos, correctivos, 600);
                } else {
                    document.getElementById('totalCorrectivos').textContent = correctivos;
                }

                if (predictivos >= currentStats.predictivos) {
                    animateValue('totalPredictivos', currentStats.predictivos, predictivos, 600);
                } else {
                    document.getElementById('totalPredictivos').textContent = predictivos;
                }

                // Actualizar stats actuales
                currentStats = {
                    total: total,
                    preventivos: preventivos,
                    correctivos: correctivos,
                    predictivos: predictivos
                };
            }

            // Función para animar números solo cuando aumentan
            function animateValue(id, start, end, duration) {
                var obj = document.getElementById(id);
                if (!obj || start === end) {
                    if (obj) obj.textContent = end;
                    return;
                }
                
                var range = end - start;
                var current = start;
                var increment = range > 0 ? 1 : -1;
                var stepTime = Math.abs(Math.floor(duration / range));
                
                if (stepTime < 10) stepTime = 10; // Mínimo 10ms por paso
                
                var timer = setInterval(function() {
                    current += increment;
                    obj.textContent = current;
                    if (current == end) {
                        clearInterval(timer);
                    }
                }, stepTime);
            }

            // Filtros - recargar eventos cuando cambian los checkboxes
            const checkboxes = document.querySelectorAll('input[type="checkbox"]');
            checkboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    calendar.refetchEvents();
                });
            });
            // Mini calendario de navegación rápida
            const miniCalendar = document.getElementById('miniCalendar');
            const btnHoy = document.getElementById('btnHoy');

            // Establecer fecha actual en el input
            const today = new Date();
            miniCalendar.value = today.toISOString().split('T')[0];

            // Cuando se selecciona una fecha en el mini calendario
            miniCalendar.addEventListener('change', function() {
                if (this.value) {
                    calendar.gotoDate(this.value);
                }
            });

            // Botón "Ir a Hoy"
            btnHoy.addEventListener('click', function() {
                calendar.today();
                miniCalendar.value = new Date().toISOString().split('T')[0];
            });

            // Actualizar el mini calendario cuando se navega en el calendario principal
            calendar.on('datesSet', function(dateInfo) {
                // Actualizar el input date con el mes actual visible
                const currentDate = calendar.getDate();
                miniCalendar.value = currentDate.toISOString().split('T')[0];
            });
        });
    </script>
</body>
</html>