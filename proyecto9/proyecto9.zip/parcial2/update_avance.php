<?php
// update_avance.php
include 'conexion_dbs.php';
header('Content-Type: application/json');
$input = json_decode(file_get_contents('php://input'), true);
if (!$input || !isset($input['id']) || !isset($input['avance'])) {
    echo json_encode(['ok'=>false,'msg'=>'Datos incompletos']); exit;
}
$id = intval($input['id']);
$avance = intval($input['avance']);
if ($avance < 0) $avance = 0; if ($avance > 100) $avance = 100;

$sql = "UPDATE equipos SET avance=$avance WHERE id=$id";
$ok = replicar_consulta($sql);
echo json_encode(['ok'=>$ok]);
