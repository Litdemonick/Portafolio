<?php
require_once 'auth.php';
verificarStaff(); // Solo usuarios logueados (staff o admin) pueden acceder

$usuario_actual = obtenerUsuarioActual();

// Incluir tu header personalizado
include 'includes/header.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Mantenimiento</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

    <div class="container-fluid py-5 bg-light">
        <div class="container">
            <!-- Información del usuario actual -->
            <div class="user-info bg-primary text-white p-4 rounded mb-4">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h4 class="mb-1">
                            <i class="fas fa-user me-2"></i>
                            <?php echo htmlspecialchars($usuario_actual['nombre_completo']); ?>
                        </h4>
                        <p class="mb-0">
                            <span class="badge bg-light text-dark">
                                <i class="fas fa-shield-alt me-1"></i>
                                <?php echo ucfirst($usuario_actual['rol']); ?>
                            </span>
                            <span class="ms-2">
                                <i class="fas fa-clock me-1"></i>
                                <?php echo date('d/m/Y H:i'); ?>
                            </span>
                        </p>
                    </div>
                    <div class="col-md-4 text-end">
                        <a href="logout.php" class="btn btn-danger"
                           onclick="return confirm('¿Estás seguro de que deseas cerrar sesión?')">
                            <i class="fas fa-sign-out-alt me-1"></i>
                            Cerrar Sesión
                        </a>
                    </div>
                </div>
            </div>

            <!-- Contenido principal -->
            <div class="row align-items-center mt-4">
                <div class="col-md-6">
                    <h1 class="display-4 fw-bold text-primary">Sistema de Mantenimiento</h1>
                    <p class="lead">Gestión integral de mantenimientos predictivos, preventivos y correctivos</p>
                    <div class="mt-4">
                        <a href="calendario.php" class="btn btn-primary btn-lg me-3">
                            <i class="fas fa-calendar-alt me-2"></i>Ver Calendario
                        </a>
                        
                        <a href="mantenimiento.php" class="btn btn-outline-primary btn-lg">
                            <i class="fas fa-tools me-2"></i>Gestión de Mantenimientos
                        </a>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card shadow">
                        <div class="card-body text-center p-5">
                            <i class="fas fa-cogs display-1 text-primary mb-4"></i>
                            <h3>Control Total de Mantenimientos</h3>
                            <p class="text-muted">Monitorea el progreso y estado de todos tus equipos</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Sección de beneficios -->
    <div class="container my-5">
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center">
                        <i class="fas fa-calendar-check fa-3x text-success mb-3"></i>
                        <h4>Calendario Integrado</h4>
                        <p>Visualiza todos los mantenimientos programados en un calendario interactivo</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center">
                        <i class="fas fa-tasks fa-3x text-warning mb-3"></i>
                        <h4>Gestión por Estados</h4>
                        <p>Organiza los mantenimientos por: Por hacer, En espera, En revisión, Terminada</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center">
                        <i class="fas fa-chart-line fa-3x text-info mb-3"></i>
                        <h4>Seguimiento de Avance</h4>
                        <p>Monitorea el progreso con porcentajes de avance en tiempo real</p>
                    </div>
                </div>
            </div>
        </div>

    
    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5>Sistema de Mantenimiento</h5>
                    <p class="mb-0">Sistema integral para la gestión de mantenimientos de equipos</p>
                </div>
                <div class="col-md-6 text-end">
                    <p class="mb-0">
                        <i class="fas fa-user me-1"></i>
                        <?php echo htmlspecialchars($usuario_actual['nombre_completo']); ?> 
                        (<?php echo ucfirst($usuario_actual['rol']); ?>)
                    </p>
                    <small>
                        <i class="fas fa-clock me-1"></i>
                        Último acceso: <?php echo date('d/m/Y H:i'); ?>
                    </small>
                </div>
            </div>
        </div>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="scripts/protect.js"></script>
</body>
</html>
