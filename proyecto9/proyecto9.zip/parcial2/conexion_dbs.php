<?php
// ========================================
// ARCHIVO: conexion_dbs.php
// Descripción: Maneja conexiones a ambas bases de datos
// ========================================

// --------------------------
// Conexión a la DB principal (Ubuntu)
// --------------------------
$host_local = "localhost";
$user_local = "root";
$pass_local = "";  // Cambia según tu configuración
$db_local   = "nibarra_replica";
$port_local = 3307;

$conexion_local = new mysqli($host_local, $user_local, $pass_local, $db_local, $port_local);

if ($conexion_local->connect_error) {
    die("❌ Error al conectar con la base de datos principal (Ubuntu): " . $conexion_local->connect_error);
}

// --------------------------
// Conexión a la DB remota (Windows)
// --------------------------
$host_remoto = "192.168.50.189"; // ← IP de tu máquina Windows Ips: 192.168.50.189 / 10.175.23.17"
$user_remoto = "root";
$pass_remoto = ""; // Contraseña de MySQL en Windows
$db_remoto   = "nibarra_replica";
$port_remoto = 3307;

$conexion_remota = new mysqli($host_remoto, $user_remoto, $pass_remoto, $db_remoto, $port_remoto);

if ($conexion_remota->connect_error) {
    die("❌ Error al conectar con la base de datos remota (Windows): " . $conexion_remota->connect_error);
}

// --------------------------
// Función para replicar consultas
// --------------------------
function replicar_consulta($sql) {
    global $conexion_local, $conexion_remota;

    $resultado_local = $conexion_local->query($sql);
    $resultado_remoto = $conexion_remota->query($sql);

    if ($resultado_local && $resultado_remoto) {
        return true;
    } else {
        error_log("Error de replicación:\nLocal: " . $conexion_local->error . "\nRemota: " . $conexion_remota->error);
        return false;
    }
}
?>
