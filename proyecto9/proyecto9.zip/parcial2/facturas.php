<?php
// ========================================
// ARCHIVO: facturas.php
// Descripción: Gestión y generación de facturas con PDF
// ========================================

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'conexion_dbs.php';
require_once 'auth.php';
verificarStaff();

// Variables para mensajes
$mensaje = "";
$tipo_mensaje = "";

// Configuración de paginación
$items_por_pagina = 4;
$pagina_actual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;
$offset = ($pagina_actual - 1) * $items_por_pagina;

// Filtros
$filtro_estado = isset($_GET['estado']) ? $_GET['estado'] : '';
$buscar = isset($_GET['buscar']) ? trim($_GET['buscar']) : '';

// ========================================
// GENERAR NÚMERO DE FACTURA
// ========================================
function generarNumeroFactura($conexion) {
    $año = date('Y');
    $mes = date('m');
    $prefijo = "FAC-{$año}{$mes}-";
    
    // Obtener el último número
    $sql = "SELECT numero_factura FROM facturas WHERE numero_factura LIKE '{$prefijo}%' ORDER BY id DESC LIMIT 1";
    $resultado = $conexion->query($sql);
    
    if ($resultado && $resultado->num_rows > 0) {
        $ultima = $resultado->fetch_assoc()['numero_factura'];
        $numero = intval(substr($ultima, -4)) + 1;
    } else {
        $numero = 1;
    }
    
    return $prefijo . str_pad($numero, 4, '0', STR_PAD_LEFT);
}

// ========================================
// CREAR NUEVA FACTURA
// ========================================
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['crear_factura'])) {
    $id_equipo = intval($_POST['id_equipo']);
    $cliente_nombre = trim($_POST['cliente_nombre']);
    $cliente_cedula = trim($_POST['cliente_cedula']);
    $cliente_telefono = trim($_POST['cliente_telefono']);
    $cliente_correo = trim($_POST['cliente_correo']);
    $cliente_direccion = trim($_POST['cliente_direccion']);
    $observaciones = trim($_POST['observaciones']);
    $forma_pago = $_POST['forma_pago'];
    
    // Obtener datos del equipo
    $sql_equipo = "SELECT * FROM equipos WHERE id = {$id_equipo}";
    $resultado_equipo = $conexion_local->query($sql_equipo);
    
    if ($resultado_equipo && $resultado_equipo->num_rows > 0) {
        $equipo = $resultado_equipo->fetch_assoc();
        
        // Verificar que el equipo esté terminado
        if ($equipo['estado'] != 'terminada') {
            $mensaje = "❌ Solo se pueden facturar equipos con estado 'Terminada'";
            $tipo_mensaje = "error";
        } else {
            // Calcular costos
            $subtotal = floatval($equipo['costo_final']);
            $itbms = $subtotal * 0.07; // 7% ITBMS
            $total = $subtotal + $itbms;
            
            $numero_factura = generarNumeroFactura($conexion_local);
            $usuario = $_SESSION['usuario'] ?? 'Desconocido';
            
            // Insertar factura
            $sql = "INSERT INTO facturas 
                (numero_factura, id_equipo, cliente_nombre, cliente_cedula, cliente_telefono, 
                 cliente_correo, cliente_direccion, equipo_nombre, equipo_marca, equipo_serie, 
                 tipo_servicio, subtotal, itbms, total, observaciones, forma_pago, generada_por)
                VALUES (
                    '".$conexion_local->real_escape_string($numero_factura)."',
                    {$id_equipo},
                    '".$conexion_local->real_escape_string($cliente_nombre)."',
                    '".$conexion_local->real_escape_string($cliente_cedula)."',
                    '".$conexion_local->real_escape_string($cliente_telefono)."',
                    '".$conexion_local->real_escape_string($cliente_correo)."',
                    '".$conexion_local->real_escape_string($cliente_direccion)."',
                    '".$conexion_local->real_escape_string($equipo['equipo'])."',
                    '".$conexion_local->real_escape_string($equipo['marca'])."',
                    '".$conexion_local->real_escape_string($equipo['serie'])."',
                    '".$conexion_local->real_escape_string($equipo['tipo_servicio'])."',
                    {$subtotal},
                    {$itbms},
                    {$total},
                    '".$conexion_local->real_escape_string($observaciones)."',
                    '".$conexion_local->real_escape_string($forma_pago)."',
                    '".$conexion_local->real_escape_string($usuario)."'
                )";
            
            if (replicar_consulta($sql)) {
                $mensaje = "✅ Factura {$numero_factura} creada exitosamente";
                $tipo_mensaje = "success";
                
                // Redirigir a la generación del PDF
                $id_factura = $conexion_local->insert_id;
                header("Location: generar_pdf_factura.php?id={$id_factura}");
                exit;
            } else {
                $mensaje = "❌ Error al crear la factura";
                $tipo_mensaje = "error";
            }
        }
    } else {
        $mensaje = "❌ Equipo no encontrado";
        $tipo_mensaje = "error";
    }
}

// ========================================
// ANULAR FACTURA
// ========================================
if (isset($_GET['anular'])) {
    $id = intval($_GET['anular']);
    
    // Obtener el ID del equipo de la factura
    $sql_factura = "SELECT id_equipo FROM facturas WHERE id = {$id}";
    $resultado_factura = $conexion_local->query($sql_factura);
    
    if ($resultado_factura && $resultado_factura->num_rows > 0) {
        $factura = $resultado_factura->fetch_assoc();
        $id_equipo = $factura['id_equipo'];
        
        // Iniciar transacción para evitar inconsistencias
        $conexion_local->begin_transaction();
        
        try {
            // Actualizar el estado de la factura a anulada y la fecha de anulación
            $sql_anulacion_factura = "UPDATE facturas 
                                      SET estado = 'anulada', fecha_anulacion = NOW(), fecha_pago = 'anulada'
                                      WHERE id = {$id}";
            
            // Ejecutar en la base de datos principal
            if (!$conexion_local->query($sql_anulacion_factura)) {
                throw new Exception('Error al anular la factura en la base de datos principal');
            }

            // También replicar la actualización en la base de datos replicada
            if (!replicar_consulta($sql_anulacion_factura)) {
                throw new Exception('Error al replicar la anulación de la factura en la base de datos replicada');
            }

            // Actualizar el estado del equipo a "en espera"
            $sql_actualizar_estado_equipo = "UPDATE equipos 
                                             SET estado = 'en espera' 
                                             WHERE id = {$id_equipo}";
            
            // Ejecutar en la base de datos principal
            if (!$conexion_local->query($sql_actualizar_estado_equipo)) {
                throw new Exception('Error al actualizar el estado del equipo en la base de datos principal');
            }
            
            // También replicar la actualización en la base de datos replicada
            if (!replicar_consulta($sql_actualizar_estado_equipo)) {
                throw new Exception('Error al replicar la actualización del estado del equipo en la base de datos replicada');
            }
            
            // Confirmar la transacción si todo está bien
            $conexion_local->commit();
            
            $mensaje = "✅ Factura anulada correctamente y equipo actualizado";
            $tipo_mensaje = "success";
        } catch (Exception $e) {
            // Revertir la transacción si algo falla
            $conexion_local->rollback();
            
            $mensaje = "❌ Error al anular la factura: " . $e->getMessage();
            $tipo_mensaje = "error";
        }
    } else {
        $mensaje = "❌ Factura no encontrada";
        $tipo_mensaje = "error";
    }
}




// ========================================
// MARCAR COMO PAGADA
// ========================================
if (isset($_GET['marcar_pagada'])) {
    $id = intval($_GET['marcar_pagada']);
    $sql = "UPDATE facturas SET estado='pagada', fecha_pago=NOW() WHERE id={$id}";
    
    if (replicar_consulta($sql)) {
        $mensaje = "✅ Factura marcada como pagada";
        $tipo_mensaje = "success";
    } else {
        $mensaje = "❌ Error al actualizar la factura";
        $tipo_mensaje = "error";
    }
}

// ========================================
// OBTENER FACTURAS CON FILTROS
// ========================================
$where_conditions = [];
$params = [];
$types = "";

// Filtro por número de factura
$numero_factura = isset($_GET['numero_factura']) ? trim($_GET['numero_factura']) : '';
if (!empty($numero_factura)) {
    $where_conditions[] = "numero_factura LIKE ?";
    $params[] = "%$numero_factura%";
    $types .= "s";
}

if (!empty($filtro_estado) && $filtro_estado != 'todos') {
    $where_conditions[] = "estado = ?";
    $params[] = $filtro_estado;
    $types .= "s";
}

if (!empty($buscar)) {
    $where_conditions[] = "(numero_factura LIKE ? OR cliente_nombre LIKE ? OR cliente_cedula LIKE ?)";
    $search_param = "%$buscar%";
    $params = array_merge($params, [$search_param, $search_param, $search_param]);
    $types .= "sss";
}

$where_clause = "";
if (count($where_conditions) > 0) {
    $where_clause = "WHERE " . implode(" AND ", $where_conditions);
}

// Contar total
$sql_count = "SELECT COUNT(*) as total FROM facturas " . $where_clause;
if (!empty($params)) {
    $stmt_count = $conexion_local->prepare($sql_count);
    if (!empty($types)) {
        $stmt_count->bind_param($types, ...$params);
    }
    $stmt_count->execute();
    $result_count = $stmt_count->get_result();
    $total_facturas = $result_count->fetch_assoc()['total'];
} else {
    $resultado_count = $conexion_local->query($sql_count);
    $total_facturas = $resultado_count->fetch_assoc()['total'];
}
$total_paginas = ceil($total_facturas / $items_por_pagina);

// Obtener facturas
$sql_facturas = "SELECT * FROM facturas " . $where_clause . " ORDER BY fecha_emision DESC LIMIT {$items_por_pagina} OFFSET {$offset}";
if (!empty($params)) {
    $stmt_facturas = $conexion_local->prepare($sql_facturas);
    if (!empty($types)) {
        $stmt_facturas->bind_param($types, ...$params);
    }
    $stmt_facturas->execute();
    $resultado_facturas = $stmt_facturas->get_result();
} else {
    $resultado_facturas = $conexion_local->query($sql_facturas);
}

// Obtener equipos terminados para facturar (que NO tengan factura aún)
$sql_equipos_terminados = "SELECT e.* FROM equipos e 
                           LEFT JOIN facturas f ON e.id = f.id_equipo AND f.estado != 'anulada'
                           WHERE e.estado = 'terminada' AND f.id IS NULL 
                           ORDER BY e.fecha_ingreso DESC";
$equipos_terminados = $conexion_local->query($sql_equipos_terminados);

include 'includes/header.php';
?>

<style>
.content {
    max-width: 1600px;
    margin: 20px auto;
    padding: 0 20px;
}

.form-section, .list-section {
    background: #1e1e1e;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    margin-bottom: 25px;
}

.section-title {
    color: #00b4d8;
    margin-bottom: 20px;
    font-size: 24px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 15px;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    color: #ddd;
    font-weight: 500;
    margin-bottom: 5px;
}

.form-group input, .form-group select, .form-group textarea {
    width: 100%;
    padding: 10px;
    border-radius: 8px;
    border: 2px solid #333;
    background: #2a2a2a;
    color: white;
    font-size: 14px;
    transition: all 0.3s;
}

.form-group input:focus, .form-group select:focus, .form-group textarea:focus {
    border-color: #667eea;
    outline: none;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.btn {
    padding: 12px 24px;
    border-radius: 8px;
    border: none;
    cursor: pointer;
    font-weight: 500;
    text-decoration: none;
    display: inline-block;
    transition: all 0.3s;
    font-size: 14px;
}

.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
}

.btn-success {
    background: #27ae60;
    color: white;
}

.btn-success:hover {
    background: #229954;
}

.btn-danger {
    background: #e74c3c;
    color: white;
}

.btn-danger:hover {
    background: #c0392b;
}

.btn-warning {
    background: #f39c12;
    color: white;
}

.btn-warning:hover {
    background: #e67e22;
}

.btn-info {
    background: #3498db;
    color: white;
}

.btn-info:hover {
    background: #2980b9;
}

.table-container {
    overflow-x: auto;
    background: #1e1e1e;
    border-radius: 8px;
    padding: 0;
    margin: 0;
}

table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    color: #ddd;
    background: #1e1e1e;
    table-layout: auto;
}

th, td {
    padding: 15px 12px;
    text-align: left;
    border-bottom: 1px solid #333;
    background-color: #1e1e1e;
    vertical-align: middle;
}

th {
    background-color: #2a2a2a !important;
    font-weight: 600;
    position: sticky;
    top: 0;
    z-index: 10;
    border-bottom: 2px solid #667eea;
}

tbody tr {
    background-color: #1e1e1e;
    transition: background-color 0.2s;
}

tbody tr:hover {
    background-color: #252525;
}

tbody tr:hover td {
    background-color: #252525 !important;
}

tbody tr td {
    background-color: #1e1e1e !important;
}

.estado-badge {
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
    display: inline-block;
    white-space: nowrap;
}

.estado-emitida {
    background: #3498db;
    color: white;
}

.estado-pagada {
    background: #27ae60;
    color: white;
}

.estado-anulada {
    background: #95a5a6;
    color: white;
}

.message {
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    font-weight: 500;
}

.message.success {
    background: #27ae60;
    color: white;
}

.message.error {
    background: #e74c3c;
    color: white;
}

.filter-section {
    background: #252525;
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 20px;
}

.filter-group {
    display: flex;
    gap: 15px;
    align-items: flex-end;
    flex-wrap: wrap;
}

.pagination {
    display: flex;
    justify-content: center;
    gap: 10px;
    margin-top: 20px;
    padding: 20px 0;
    flex-wrap: wrap;
    background: #1e1e1e;
}

.pagination a, .pagination span {
    padding: 10px 16px;
    background: #2a2a2a;
    color: #ddd;
    text-decoration: none;
    border-radius: 6px;
    transition: all 0.3s;
    font-weight: 500;
    min-width: 40px;
    text-align: center;
}

.pagination a:hover {
    background: #667eea;
    color: white;
    transform: translateY(-2px);
}

.pagination .active {
    background: #667eea;
    color: white;
    font-weight: bold;
    box-shadow: 0 4px 10px rgba(102, 126, 234, 0.3);
}

.pagination .disabled {
    opacity: 0.5;
    cursor: not-allowed;
    pointer-events: none;
}

.actions {
    display: flex;
    gap: 8px;
    flex-wrap: nowrap;
    background-color: transparent !important;
    align-items: center;
}

.actions .btn {
    padding: 8px 14px;
    font-size: 13px;
    white-space: nowrap;
    flex-shrink: 0;
}

tbody tr td:last-child {
    background-color: #1e1e1e !important;
}

tbody tr:hover td:last-child {
    background-color: #252525 !important;
}

.costo-resumen {
    background: #252525;
    padding: 20px;
    border-radius: 8px;
    margin-top: 15px;
}

.costo-resumen h3 {
    color: #00b4d8;
    margin-bottom: 15px;
    font-size: 18px;
}

.costo-item {
    display: flex;
    justify-content: space-between;
    padding: 8px 0;
    color: #ddd;
}

.costo-item.total {
    border-top: 2px solid #333;
    margin-top: 10px;
    padding-top: 15px;
    font-size: 20px;
    font-weight: bold;
}

.costo-item.total span {
    color: #00b4d8;
}

.pagination-info {
    text-align: center;
    color: #999;
    margin-top: 10px;
    font-size: 14px;
}
</style>

<div class="content">
    
    <?php if ($mensaje): ?>
        <div class="message <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></div>
    <?php endif; ?>

    <!-- Formulario para crear factura -->
    <div class="form-section">
        <h2 class="section-title">
            <span>🧾</span> Nueva Factura
        </h2>
        
        <?php if ($equipos_terminados && $equipos_terminados->num_rows > 0): ?>
            <form method="POST" action="">
                <div class="form-grid">
                    <!-- Selección de equipo -->
                    <div class="form-group" style="grid-column: 1 / -1;">
                        <label>🔧 Seleccionar Equipo Terminado *</label>
                        <select name="id_equipo" id="equipo-select" required>
                            <option value="">-- Seleccione un equipo --</option>
                            <?php while ($eq = $equipos_terminados->fetch_assoc()): ?>
                                <option value="<?php echo $eq['id']; ?>" 
                                        data-costo="<?php echo number_format((float)$eq['costo_final'], 2, '.', ''); ?>"
                                        data-equipo="<?php echo htmlspecialchars($eq['equipo']); ?>"
                                        data-marca="<?php echo htmlspecialchars($eq['marca']); ?>"
                                        data-serie="<?php echo htmlspecialchars($eq['serie']); ?>">
                                    #<?php echo $eq['id']; ?> - <?php echo htmlspecialchars($eq['equipo']); ?> 
                                    (<?php echo htmlspecialchars($eq['marca']); ?>) - 
                                    $<?php echo number_format((float)$eq['costo_final'], 2); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <!-- Datos del Cliente -->
                    <div class="form-group">
                        <label>👤 Nombre del Cliente *</label>
                        <input type="text" name="cliente_nombre" required maxlength="100">
                    </div>

                    <div class="form-group">
                        <label>🆔 Cédula/RUC</label>
                        <input type="text" name="cliente_cedula" maxlength="20">
                    </div>

                    <div class="form-group">
                        <label>📱 Teléfono</label>
                        <input type="text" name="cliente_telefono" maxlength="20">
                    </div>

                    <div class="form-group">
                        <label>📧 Correo Electrónico</label>
                        <input type="email" name="cliente_correo" maxlength="100">
                    </div>

                    <div class="form-group" style="grid-column: 1 / -1;">
                        <label>📍 Dirección</label>
                        <textarea name="cliente_direccion" rows="2" maxlength="200"></textarea>
                    </div>

                    <!-- Información de pago -->
                    <div class="form-group">
                        <label>💳 Forma de Pago *</label>
                        <select name="forma_pago" required>
                            <option value="efectivo">Efectivo</option>
                            <option value="transferencia">Transferencia</option>
                            <option value="tarjeta">Tarjeta</option>
                            <option value="yappy">Yappy</option>
                        </select>
                    </div>

                    <div class="form-group" style="grid-column: 1 / -1;">
                        <label>📝 Observaciones</label>
                        <textarea name="observaciones" rows="3" maxlength="500"></textarea>
                    </div>
                </div>

                <!-- Resumen de costos -->
                <div class="costo-resumen" id="resumen-costos" style="display: none;">
                    <h3>💰 Resumen de Costos</h3>
                    <div class="costo-item">
                        <span>Subtotal:</span>
                        <strong id="subtotal-display">$0.00</strong>
                    </div>
                    <div class="costo-item">
                        <span>ITBMS (7%):</span>
                        <strong id="itbms-display">$0.00</strong>
                    </div>
                    <div class="costo-item total">
                        <span>Total:</span>
                        <strong id="total-display">$0.00</strong>
                    </div>
                </div>

                <div style="margin-top: 20px; text-align: center;">
                    <button type="submit" name="crear_factura" class="btn btn-primary">
                        🧾 Generar Factura y PDF
                    </button>
                </div>
            </form>

            <script>
            document.getElementById('equipo-select').addEventListener('change', function() {
                const option = this.options[this.selectedIndex];
                const costo = parseFloat(option.dataset.costo) || 0;
                
                if (costo > 0) {
                    const subtotal = costo;
                    const itbms = subtotal * 0.07;
                    const total = subtotal + itbms;
                    
                    document.getElementById('subtotal-display').textContent = '$' + subtotal.toFixed(2);
                    document.getElementById('itbms-display').textContent = '$' + itbms.toFixed(2);
                    document.getElementById('total-display').textContent = '$' + total.toFixed(2);
                    document.getElementById('resumen-costos').style.display = 'block';
                } else {
                    document.getElementById('resumen-costos').style.display = 'none';
                }
            });
            </script>
        <?php else: ?>
            <div style="text-align: center; padding: 40px; color: #999;">
                <h3 style="font-size: 20px; margin-bottom: 10px;">📭 No hay equipos terminados para facturar</h3>
                <p>Completa un servicio y márcalo como "Terminada" para poder generar su factura.</p>
                <a href="equipos.php" class="btn btn-primary" style="margin-top: 15px;">Ver Equipos</a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Lista de facturas -->
    <div class="list-section">
        <h2 class="section-title">
            <span>📋</span> Facturas Generadas
        </h2>

        <!-- Filtros -->
        <div class="filter-section">
            <form method="GET" action="" class="filter-group">
                <div class="form-group" style="margin-bottom: 0; min-width: 200px;">
                        <label>🧾 Número de Factura</label>
                        <input type="text" name="numero_factura" placeholder="Ej: FAC-202511-0001" 
                            value="<?php echo htmlspecialchars($_GET['numero_factura'] ?? ''); ?>">
                    </div>

                    <div class="form-group" style="margin-bottom: 0; flex: 1; min-width: 250px;">
                        <label>🔍 Cliente / Cédula</label>
                        <input type="text" name="buscar" placeholder="Cliente, cédula..." 
                            value="<?php echo htmlspecialchars($buscar); ?>">
                    </div>

                <div class="form-group" style="margin-bottom: 0; min-width: 200px;">
                    <label>📊 Estado</label>
                    <select name="estado">
                        <option value="todos" <?php echo $filtro_estado == 'todos' ? 'selected' : ''; ?>>Todos</option>
                        <option value="emitida" <?php echo $filtro_estado == 'emitida' ? 'selected' : ''; ?>>Emitidas</option>
                        <option value="pagada" <?php echo $filtro_estado == 'pagada' ? 'selected' : ''; ?>>Pagadas</option>
                        <option value="anulada" <?php echo $filtro_estado == 'anulada' ? 'selected' : ''; ?>>Anuladas</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">🔍 Buscar</button>
                
                <?php if (!empty($buscar) || (!empty($filtro_estado) && $filtro_estado != 'todos')): ?>
                    <a href="facturas.php" class="btn btn-danger">❌ Limpiar</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="table-container">
            <?php if ($resultado_facturas && $resultado_facturas->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Número</th>
                            <th>Fecha</th>
                            <th>Cliente</th>
                            <th>Equipo</th>
                            <th>Subtotal</th>
                            <th>ITBMS</th>
                            <th>Total</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($f = $resultado_facturas->fetch_assoc()): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($f['numero_factura']); ?></strong></td>
                                <td><?php echo date('d/m/Y H:i', strtotime($f['fecha_emision'])); ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($f['cliente_nombre']); ?></strong><br>
                                    <small style="color: #999;"><?php echo htmlspecialchars($f['cliente_cedula']); ?></small>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($f['equipo_nombre']); ?><br>
                                    <small style="color: #999;"><?php echo htmlspecialchars($f['equipo_marca']); ?></small>
                                </td>
                                <td>$<?php echo number_format((float)$f['subtotal'], 2); ?></td>
                                <td>$<?php echo number_format((float)$f['itbms'], 2); ?></td>
                                <td><strong>$<?php echo number_format((float)$f['total'], 2); ?></strong></td>
                                <td>
                                    <span class="estado-badge estado-<?php echo $f['estado']; ?>">
                                        <?php echo ucfirst($f['estado']); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <a href="generar_pdf_factura.php?id=<?php echo $f['id']; ?>" 
                                           class="btn btn-info" target="_blank" title="Ver PDF">
                                            📄 PDF
                                        </a>
                                        
                                        <?php if ($f['estado'] == 'emitida'): ?>
                                            <a href="?marcar_pagada=<?php echo $f['id']; ?>" 
                                               class="btn btn-success" 
                                               onclick="return confirm('¿Marcar esta factura como pagada?')"
                                               title="Marcar como pagada">
                                                ✅ Pagar
                                            </a>
                                            <a href="?anular=<?php echo $f['id']; ?>" 
                                               class="btn btn-danger" 
                                               onclick="return confirm('¿Anular esta factura?')"
                                               title="Anular factura">
                                                ❌ Anular
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="text-align: center; padding: 40px; color: #999;">
                    <h3 style="font-size: 20px; margin-bottom: 10px;">📭 No se encontraron facturas</h3>
                    <p>Genera tu primera factura desde el formulario de arriba.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Paginación -->
        <?php if ($total_paginas > 1): ?>
            <div class="pagination">
                <?php
                $params_url = [];
                if (!empty($buscar)) $params_url[] = "buscar=" . urlencode($buscar);
                if (!empty($numero_factura)) $params_url[] = "numero_factura=" . urlencode($numero_factura);
                if (!empty($filtro_estado) && $filtro_estado != 'todos') $params_url[] = "estado=" . urlencode($filtro_estado);
                $params_string = !empty($params_url) ? '&' . implode('&', $params_url) : '';
                
                // Botón anterior
                if ($pagina_actual > 1): ?>
                    <a href="?pagina=<?php echo ($pagina_actual - 1) . $params_string; ?>" title="Página anterior">
                        « Anterior
                    </a>
                <?php else: ?>
                    <span class="disabled">« Anterior</span>
                <?php endif; ?>
                
                <?php
                // Mostrar páginas
                $rango = 2; // Cuántas páginas mostrar antes y después de la actual
                $inicio = max(1, $pagina_actual - $rango);
                $fin = min($total_paginas, $pagina_actual + $rango);
                
                // Primera página
                if ($inicio > 1): ?>
                    <a href="?pagina=1<?php echo $params_string; ?>">1</a>
                    <?php if ($inicio > 2): ?>
                        <span class="disabled">...</span>
                    <?php endif; ?>
                <?php endif;
                
                // Páginas del rango
                for ($i = $inicio; $i <= $fin; $i++): ?>
                    <a href="?pagina=<?php echo $i . $params_string; ?>" 
                       class="<?php echo ($i == $pagina_actual) ? 'active' : ''; ?>">
                        <?php echo $i; ?>
                    </a>
                <?php endfor;
                
                // Última página
                if ($fin < $total_paginas): ?>
                    <?php if ($fin < $total_paginas - 1): ?>
                        <span class="disabled">...</span>
                    <?php endif; ?>
                    <a href="?pagina=<?php echo $total_paginas . $params_string; ?>"><?php echo $total_paginas; ?></a>
                <?php endif;
                
                // Botón siguiente
                if ($pagina_actual < $total_paginas): ?>
                    <a href="?pagina=<?php echo ($pagina_actual + 1) . $params_string; ?>" title="Página siguiente">
                        Siguiente »
                    </a>
                <?php else: ?>
                    <span class="disabled">Siguiente »</span>
                <?php endif; ?>
            </div>
            
            <div class="pagination-info">
                Mostrando página <?php echo $pagina_actual; ?> de <?php echo $total_paginas; ?> 
                (<?php echo $total_facturas; ?> factura<?php echo $total_facturas != 1 ? 's' : ''; ?> en total)
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>