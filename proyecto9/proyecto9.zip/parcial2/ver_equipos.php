<?php
require_once 'auth.php';
verificarStaff(); // Staff y admin pueden ver

require_once 'conexion_dbs.php';

// Obtener equipos para mostrar
$sql_equipos = "SELECT * FROM equipos ORDER BY fecha_creacion DESC";
$resultado_equipos = $conexion_local->query($sql_equipos);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Equipos - Sistema</title>
    <!-- Mismo estilo que equipos.php pero sin opciones de edición -->
</head>
<body>
    <!-- Similar a equipos.php pero solo con visualización -->
    <h1>👁️ Visualización de Equipos</h1>
    <p>Solo lectura - Modo staff</p>
    <!-- Tabla de equipos sin botones de editar/eliminar -->
</body>
</html>