<?php
// update_status.php
include 'conexion_dbs.php';
header('Content-Type: application/json');
$input = json_decode(file_get_contents('php://input'), true);
if (!$input || !isset($input['id']) || !isset($input['estado'])) {
    echo json_encode(['ok'=>false,'msg'=>'Datos incompletos']); exit;
}
$id = intval($input['id']);
$estado = $conexion_local->real_escape_string($input['estado']);

$sql = "UPDATE equipos SET estado='$estado' WHERE id=$id";
$ok = replicar_consulta($sql);
echo json_encode(['ok'=>$ok]);
