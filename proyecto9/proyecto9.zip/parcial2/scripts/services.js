// scripts/services.js
document.addEventListener('DOMContentLoaded', function () {
  // Tabs
  document.querySelectorAll('.tablink').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      document.querySelectorAll('.tablink').forEach(x=>x.classList.remove('active'));
      document.querySelectorAll('.tabcontent').forEach(x=>x.classList.remove('active'));
      btn.classList.add('active');
      document.querySelector(btn.dataset.target).classList.add('active');
    });
  });

  // Kanban drop handling
  window.drag = function(e) {
    e.dataTransfer.setData('text/plain', e.target.dataset.id);
  };

  document.querySelectorAll('.kanban-column').forEach(col=>{
    const list = col.querySelector('.kanban-list');
    list.addEventListener('drop', async (ev)=>{
      ev.preventDefault();
      const id = ev.dataTransfer.getData('text/plain');
      const nuevoEstado = col.dataset.estado;
      // mover visualmente
      const card = document.querySelector('.kanban-card[data-id="'+id+'"]');
      if (card) col.querySelector('.kanban-list').appendChild(card);

      // enviar cambio a backend
      try {
        const res = await fetch('update_status.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: id, estado: nuevoEstado })
        });
        const j = await res.json();
        if (!j.ok) alert('Error actualizando estado');
      } catch(err) {
        console.error(err);
        alert('Error de red al actualizar estado');
      }
    });
  });
});

// cambiar avance desde slider
window.cambiarAvance = async function(input, id) {
  const val = input.value;
  // actualizar texto del card
  const card = document.querySelector('.kanban-card[data-id="'+id+'"]');
  if (card) card.querySelector('.card-avance').textContent = val + '%';

  // request
  try {
    const res = await fetch('update_avance.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: id, avance: val })
    });
    const j = await res.json();
    if (!j.ok) alert('Error al actualizar avance');
  } catch (err) {
    console.error(err);
    alert('Error de red al actualizar avance');
  }
};

// calendario simple: construye vista mensual (client-side) con eventos tomados del DOM via dataset (para simplicidad hacemos fetch)
// solicitamos eventos al backend
async function cargarEventosMes(year, month) {
  try {
    const res = await fetch(`get_events.php?year=${year}&month=${month}`);
    const data = await res.json();
    return data.events || [];
  } catch(e) {
    console.error(e);
    return [];
  }
}

// implementa vista calendario simple
(function buildCalendar(){
  const cal = document.getElementById('calendar');
  if (!cal) return;
  let cur = new Date();
  let year = cur.getFullYear(), month = cur.getMonth();

  const mesLabel = document.getElementById('mesActual');
  document.getElementById('prevMonth').addEventListener('click', ()=>{ month--; if(month<0){ month=11; year-- } render(); });
  document.getElementById('nextMonth').addEventListener('click', ()=>{ month++; if(month>11){ month=0; year++ } render(); });

  async function render() {
    mesLabel.textContent = new Date(year, month).toLocaleString('es-ES', { month: 'long', year: 'numeric' });
    const events = await cargarEventosMes(year, month+1); // month 1-12
    // construir calendario básico
    cal.innerHTML = '';
    const first = new Date(year, month, 1);
    const startDay = first.getDay(); // 0-dom .. 6-sab
    const dias = new Date(year, month+1, 0).getDate();

    const grid = document.createElement('div');
    grid.className = 'calendar-grid';
    // headers dias
    ['Dom','Lun','Mar','Mié','Jue','Vie','Sáb'].forEach(d=>{ const h=document.createElement('div'); h.className='cal-head'; h.innerText=d; grid.appendChild(h); });
    // celdas vacías
    for(let i=0;i<startDay;i++){ const c=document.createElement('div'); c.className='cal-cell empty'; grid.appendChild(c); }
    // dias
    for(let d=1; d<=dias; d++){
      const c = document.createElement('div'); c.className='cal-cell day';
      const label = document.createElement('div'); label.className='cal-daynum'; label.innerText = d;
      c.appendChild(label);
      // eventos del dia
      const evForDay = events.filter(ev => ev.fecha_programada === `${year}-${String(month+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`);
      evForDay.forEach(ev=>{
        const eDiv = document.createElement('div'); eDiv.className='cal-event'; eDiv.innerText = ev.equipo + ' ('+ ev.tipo_mantenimiento +')';
        c.appendChild(eDiv);
      });
      grid.appendChild(c);
    }
    cal.appendChild(grid);
  }

  render();
})();
