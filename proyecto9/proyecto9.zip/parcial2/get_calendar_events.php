<?php
// ========================================
// ARCHIVO: get_calendar_events.php
// Descripción: Obtener eventos para el calendario
// ========================================

require_once 'conexion_dbs.php';
require_once 'auth.php';
verificarStaff();

header('Content-Type: application/json');

// Obtener filtros
$tipos = isset($_GET['tipos']) ? explode(',', $_GET['tipos']) : ['preventivo', 'correctivo', 'predictivo'];
$estados = isset($_GET['estados']) ? explode(',', $_GET['estados']) : ['por_hacer', 'en_espera', 'en_revision', 'terminada'];

// Construir consulta con filtros
$where_conditions = [];

if (!empty($tipos)) {
    $tipos_escaped = array_map(function($tipo) use ($conexion_local) {
        return "'".$conexion_local->real_escape_string($tipo)."'";
    }, $tipos);
    $where_conditions[] = "tipo_servicio IN (" . implode(',', $tipos_escaped) . ")";
}

if (!empty($estados)) {
    $estados_escaped = array_map(function($estado) use ($conexion_local) {
        return "'".$conexion_local->real_escape_string($estado)."'";
    }, $estados);
    $where_conditions[] = "estado IN (" . implode(',', $estados_escaped) . ")";
}

$where_clause = !empty($where_conditions) ? "WHERE " . implode(' AND ', $where_conditions) : "";

// Consultar equipos con fecha programada
$sql = "SELECT id, equipo, marca, serie, tipo_servicio, fecha_programada, fecha_salida, 
        costo_inicial, costo_final, observacion, categoria_equipo, estado, avance 
        FROM equipos 
        $where_clause
        AND fecha_programada IS NOT NULL 
        ORDER BY fecha_programada ASC";

$resultado = $conexion_local->query($sql);

$events = [];

if ($resultado && $resultado->num_rows > 0) {
    while ($row = $resultado->fetch_assoc()) {
        $events[] = [
            'id' => $row['id'],
            'title' => $row['equipo'],
            'start' => $row['fecha_programada'],
            'end' => $row['fecha_salida'],
            'extendedProps' => [
                'id' => $row['id'],
                'tipo' => $row['tipo_servicio'],
                'marca' => $row['marca'],
                'serie' => $row['serie'],
                'categoria' => $row['categoria_equipo'],
                'estado' => $row['estado'],
                'avance' => $row['avance'],
                'observacion' => $row['observacion'],
                'costo_inicial' => $row['costo_inicial'],
                'costo_final' => $row['costo_final'],
                'fecha_salida' => $row['fecha_salida'] ? date('d/m/Y', strtotime($row['fecha_salida'])) : null
            ]
        ];
    }
}

echo json_encode($events);
?>