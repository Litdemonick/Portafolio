<?php
// ========================================
// ARCHIVO: generar_pdf_factura.php
// Descripción: Generación de PDF para facturas
// ========================================

require_once 'conexion_dbs.php';
require_once 'auth.php';
verificarStaff();

// Verificar ID
if (!isset($_GET['id'])) {
    die("Error: ID de factura no especificado");
}

$id_factura = intval($_GET['id']);

// Obtener datos de la factura
$sql = "SELECT * FROM facturas WHERE id = {$id_factura}";
$resultado = $conexion_local->query($sql);

if (!$resultado || $resultado->num_rows == 0) {
    die("Error: Factura no encontrada");
}

$factura = $resultado->fetch_assoc();

// Datos de la empresa (personaliza estos datos)
$empresa = [
    'nombre' => 'NIBARRA',
    'ruc' => '1558942-1-789456',
    'direccion' => 'Calle 50, Plaza Comercial Vista Alegre, Local 23, Ciudad de Panamá',
    'telefono' => '(507) 395-8274',
    'email' => 'contacto@nibarra.com.pa',
    'web' => 'www.nibarra.com.pa'
];


?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Factura <?php echo $factura['numero_factura']; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Arial', sans-serif;
            background: #f5f5f5;
            padding: 20px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        
        .factura {
            padding: 40px;
        }
        
        /* Encabezado */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 3px solid #667eea;
        }
        
        .empresa-info {
            flex: 1;
        }
        
        .empresa-info h1 {
            color: #667eea;
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .empresa-info p {
            color: #666;
            font-size: 13px;
            line-height: 1.6;
        }
        
        .factura-info {
            text-align: right;
        }
        
        .factura-numero {
            background: #667eea;
            color: white;
            padding: 15px 25px;
            border-radius: 8px;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        .factura-fecha {
            color: #666;
            font-size: 13px;
        }
        
        .factura-estado {
            display: inline-block;
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            margin-top: 10px;
        }
        
        .estado-emitida {
            background: #3498db;
            color: white;
        }
        
        .estado-pagada {
            background: #27ae60;
            color: white;
        }
        
        .estado-anulada {
            background: #95a5a6;
            color: white;
        }
        
        /* Cliente */
        .cliente-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
        }
        
        .cliente-section h3 {
            color: #667eea;
            margin-bottom: 15px;
            font-size: 16px;
        }
        
        .cliente-info {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
        }
        
        .cliente-info .item {
            font-size: 14px;
        }
        
        .cliente-info .label {
            color: #666;
            font-weight: 600;
            margin-right: 5px;
        }
        
        .cliente-info .value {
            color: #333;
        }
        
        /* Detalles del servicio */
        .servicio-section {
            margin-bottom: 30px;
        }
        
        .servicio-section h3 {
            color: #667eea;
            margin-bottom: 15px;
            font-size: 16px;
        }
        
        .detalle-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        
        .detalle-table th {
            background: #667eea;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            font-size: 13px;
        }
        
        .detalle-table td {
            padding: 12px;
            border-bottom: 1px solid #e0e0e0;
            font-size: 13px;
        }
        
        .detalle-table tr:last-child td {
            border-bottom: none;
        }
        
        /* Totales */
        .totales {
            margin-left: auto;
            width: 350px;
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
        }
        
        .totales-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            font-size: 14px;
        }
        
        .totales-row.total {
            border-top: 2px solid #667eea;
            margin-top: 10px;
            padding-top: 15px;
            font-size: 18px;
            font-weight: bold;
            color: #667eea;
        }
        
        /* Observaciones */
        .observaciones {
            background: #fff9e6;
            border-left: 4px solid #f39c12;
            padding: 15px;
            margin: 20px 0;
            border-radius: 4px;
        }
        
        .observaciones h4 {
            color: #f39c12;
            margin-bottom: 8px;
            font-size: 14px;
        }
        
        .observaciones p {
            color: #666;
            font-size: 13px;
            line-height: 1.6;
        }
        
        /* Footer */
        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #e0e0e0;
            text-align: center;
            color: #666;
            font-size: 12px;
        }
        
        .footer p {
            margin: 5px 0;
        }
        
        /* Botones de acción */
        .actions {
            text-align: center;
            margin: 20px 0;
            padding: 20px;
            background: #f8f9fa;
        }
        
        .btn {
            display: inline-block;
            padding: 12px 30px;
            margin: 0 10px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: #667eea;
            color: white;
        }
        
        .btn-primary:hover {
            background: #5568d3;
            transform: translateY(-2px);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        /* Print styles */
        @media print {
            body {
                background: white;
                padding: 0;
            }
            
            .container {
                box-shadow: none;
                max-width: 100%;
            }
            
            .actions {
                display: none;
            }
            
            .factura {
                padding: 20px;
            }
        }
    </style>
</head>
<body>

<div class="actions">
    <button onclick="window.print()" class="btn btn-primary">🖨️ Imprimir / Guardar PDF</button>
    <a href="facturas.php" class="btn btn-secondary">← Volver a Facturas</a>
</div>

<div class="container">
    <div class="factura">
        <!-- Encabezado -->
        <div class="header">
            <div class="empresa-info">
                <h1><?php echo $empresa['nombre']; ?></h1>
                <p>
                    <strong>RUC:</strong> <?php echo $empresa['ruc']; ?><br>
                    <strong>Dirección:</strong> <?php echo $empresa['direccion']; ?><br>
                    <strong>Teléfono:</strong> <?php echo $empresa['telefono']; ?><br>
                    <strong>Email:</strong> <?php echo $empresa['email']; ?>
                </p>
            </div>
            <div class="factura-info">
                <div class="factura-numero">
                    FACTURA<br><?php echo $factura['numero_factura']; ?>
                </div>
                <div class="factura-fecha">
                    <strong>Fecha de Emisión:</strong><br>
                    <?php echo date('d/m/Y H:i', strtotime($factura['fecha_emision'])); ?>
                </div>
                <div>
                    <span class="factura-estado estado-<?php echo $factura['estado']; ?>">
                        <?php echo strtoupper($factura['estado']); ?>
                    </span>
                </div>
            </div>
        </div>

        <!-- Información del Cliente -->
        <div class="cliente-section">
            <h3>📋 INFORMACIÓN DEL CLIENTE</h3>
            <div class="cliente-info">
                <div class="item">
                    <span class="label">Nombre:</span>
                    <span class="value"><?php echo htmlspecialchars($factura['cliente_nombre']); ?></span>
                </div>
                <?php if (!empty($factura['cliente_cedula'])): ?>
                <div class="item">
                    <span class="label">Cédula/RUC:</span>
                    <span class="value"><?php echo htmlspecialchars($factura['cliente_cedula']); ?></span>
                </div>
                <?php endif; ?>
                <?php if (!empty($factura['cliente_telefono'])): ?>
                <div class="item">
                    <span class="label">Teléfono:</span>
                    <span class="value"><?php echo htmlspecialchars($factura['cliente_telefono']); ?></span>
                </div>
                <?php endif; ?>
                <?php if (!empty($factura['cliente_correo'])): ?>
                <div class="item">
                    <span class="label">Email:</span>
                    <span class="value"><?php echo htmlspecialchars($factura['cliente_correo']); ?></span>
                </div>
                <?php endif; ?>
                <?php if (!empty($factura['cliente_direccion'])): ?>
                <div class="item" style="grid-column: 1 / -1;">
                    <span class="label">Dirección:</span>
                    <span class="value"><?php echo htmlspecialchars($factura['cliente_direccion']); ?></span>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Detalles del Servicio -->
        <div class="servicio-section">
            <h3>🔧 DETALLE DEL SERVICIO</h3>
            <table class="detalle-table">
                <thead>
                    <tr>
                        <th>Descripción</th>
                        <th>Tipo de Servicio</th>
                        <th style="text-align: right;">Monto</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <strong><?php echo htmlspecialchars($factura['equipo_nombre']); ?></strong><br>
                            <small style="color: #666;">
                                Marca: <?php echo htmlspecialchars($factura['equipo_marca']); ?>
                                <?php if (!empty($factura['equipo_serie'])): ?>
                                    | Serie: <?php echo htmlspecialchars($factura['equipo_serie']); ?>
                                <?php endif; ?>
                            </small>
                        </td>
                        <td><?php echo htmlspecialchars($factura['tipo_servicio']); ?></td>
                        <td style="text-align: right;">$<?php echo number_format((float)$factura['subtotal'], 2); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Totales -->
        <div class="totales">
            <div class="totales-row">
                <span>Subtotal:</span>
                <strong>$<?php echo number_format((float)$factura['subtotal'], 2); ?></strong>
            </div>
            <div class="totales-row">
                <span>ITBMS (7%):</span>
                <strong>$<?php echo number_format((float)$factura['itbms'], 2); ?></strong>
            </div>
            <div class="totales-row total">
                <span>TOTAL A PAGAR:</span>
                <strong>$<?php echo number_format((float)$factura['total'], 2); ?></strong>
            </div>
        </div>

        <!-- Forma de Pago -->
        <div style="margin: 20px 0; padding: 15px; background: #e3f2fd; border-radius: 8px;">
            <strong style="color: #1976d2;">💳 Forma de Pago:</strong> 
            <span style="color: #333;"><?php echo ucfirst($factura['forma_pago']); ?></span>
        </div>

        <!-- Observaciones -->
        <?php if (!empty($factura['observaciones'])): ?>
        <div class="observaciones">
            <h4>📝 Observaciones:</h4>
            <p><?php echo nl2br(htmlspecialchars($factura['observaciones'])); ?></p>
        </div>
        <?php endif; ?>

        <!-- Footer -->
        <div class="footer">
            <p><strong>¡Gracias por su preferencia!</strong></p>
            <p>Este documento fue generado por: <?php echo htmlspecialchars($factura['generada_por']); ?></p>
            <p style="margin-top: 20px; font-size: 11px; color: #999;">
                Este es un documento electrónico generado por el sistema de facturación.
            </p>
        </div>
    </div>
</div>

</body>
</html>