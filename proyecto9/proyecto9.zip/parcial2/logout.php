<?php
require_once 'auth.php';
logout();
?>