<?php
session_start();
require_once "conexion_dbs.php";

// --- 1. SEGURIDAD Y OBTENCIÓN DE DATOS ---
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

$id_usuario_a_ver = filter_input(INPUT_GET, 'id_usuario', FILTER_VALIDATE_INT);

if (!$id_usuario_a_ver) {
    header("Location: jovenes_profesionales.php");
    exit();
}

// --- 2. OBTENER DATOS COMPLETOS DEL PERFIL PÚBLICO ---
$sql_perfil = "
    SELECT 
        u.nombres, u.apellidos, u.correo, u.telefono, u.foto_perfil,
        h.nacionalidad, 
        h.fecha_nacimiento, 
        h.genero, 
        h.estado_civil, 
        h.titulo_profesional, 
        h.resumen_profesional, 
        h.experiencia_laboral, 
        h.educacion, 
        h.habilidades, 
        h.idiomas, 
        h.enlace_linkedin, h.enlace_github, h.enlace_portfolio, 
        h.archivo_adjunto
    FROM usuarios u
    JOIN hvs h ON u.id = h.usuario_id
    WHERE u.id = ? AND u.rol = 'publico'
";
$stmt = $conexion_local->prepare($sql_perfil);
$stmt->bind_param("i", $id_usuario_a_ver);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    include 'includes/header.php';
    echo "<main class='container py-5 text-center'><div class='alert alert-warning'>El perfil de este profesional no está disponible o no existe.</div> <a href='jovenes_profesionales.php' class='btn btn-primary'>Volver a la lista</a></main>";
    include 'includes/footer.php';
    exit();
}
$perfil = $resultado->fetch_assoc();

include 'includes/header.php';
?>

<style>
    .hv-container { max-width: 960px; }
    .hv-card {
        background-color: var(--surface-color);
        border: 1px solid var(--border-color);
        border-radius: 0.75rem;
        margin-bottom: 1.5rem;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    }
    .hv-card-header {
        padding: 1rem 1.5rem;
        background-color: rgba(var(--primary-color-rgb), 0.05);
        border-bottom: 1px solid var(--border-color);
    }
    .hv-card-header h5 { 
        margin: 0; 
        font-weight: 600; 
        color: var(--text-color); 
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }
    .hv-card-header h5 i { color: var(--primary-color); }
    .hv-card-body { padding: 1.5rem; }
    .data-label { 
        font-weight: 500; 
        color: var(--text-color-muted); 
        font-size: 0.85rem; 
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 0.25rem;
    }
    .data-value { color: var(--text-color); line-height: 1.7; }
    .profile-header { 
        text-align: center; 
        padding: 2.5rem; 
        background: linear-gradient(135deg, var(--surface-color) 0%, var(--surface-color-secondary, #2a2a2a) 100%);
        border-radius: 1rem; 
    }
    .profile-avatar { width: 120px; height: 120px; object-fit: cover; border-radius: 50%; border: 5px solid var(--primary-color); box-shadow: 0 0 20px rgba(var(--primary-color-rgb), 0.4); }
    .profile-avatar-default { width: 120px; height: 120px; border-radius: 50%; background-color: var(--border-color); color: var(--text-color-muted); display: flex; align-items: center; justify-content: center; font-size: 5rem; }
</style>

<main class="container py-5 hv-container">
    <div class="profile-header mb-4">
        <?php
            $foto_perfil = (!empty($perfil['foto_perfil']) && $perfil['foto_perfil'] !== 'foto_default' && file_exists('uploads/avatars/' . $perfil['foto_perfil']))
                ? 'uploads/avatars/' . htmlspecialchars($perfil['foto_perfil'])
                : null;
        ?>
        <?php if ($foto_perfil): ?>
            <img src="<?= $foto_perfil ?>" alt="Foto de perfil" class="profile-avatar mx-auto mb-3">
        <?php else: ?>
            <div class="profile-avatar-default mx-auto mb-3"><i class="bi bi-person-fill"></i></div>
        <?php endif; ?>
        <h2 class="mb-1"><?= htmlspecialchars($perfil['nombres'] . ' ' . $perfil['apellidos']) ?></h2>
        <p class="lead text-muted"><?= htmlspecialchars($perfil['titulo_profesional']) ?></p>
    </div>

    <!-- Datos Personales -->
    <div class="hv-card">
        <div class="hv-card-header"><h5><i class="bi bi-person-badge"></i>Datos Personales</h5></div>
        <div class="hv-card-body row">
            <div class="col-md-6 mb-3"><div class="data-label">Nacionalidad</div><p class="data-value"><?= htmlspecialchars($perfil['nacionalidad']) ?></p></div>
            <div class="col-md-6 mb-3"><div class="data-label">Fecha de Nacimiento</div><p class="data-value"><?= !empty($perfil['fecha_nacimiento']) ? date("d/m/Y", strtotime($perfil['fecha_nacimiento'])) : 'No especificado' ?></p></div>
            <div class="col-md-6 mb-3"><div class="data-label">Género</div><p class="data-value"><?= ucfirst($perfil['genero']) ?></p></div>
            <div class="col-md-6 mb-3"><div class="data-label">Estado Civil</div><p class="data-value"><?= ucfirst(str_replace('_', ' ', $perfil['estado_civil'])) ?></p></div>
        </div>
    </div>

    <!-- Contacto -->
    <div class="hv-card">
        <div class="hv-card-header"><h5><i class="bi bi-telephone-fill"></i>Contacto</h5></div>
        <div class="hv-card-body row">
            <div class="col-md-6 mb-3"><div class="data-label">Email</div><p class="data-value"><?= htmlspecialchars($perfil['correo']) ?></p></div>
            <div class="col-md-6 mb-3"><div class="data-label">Teléfono</div><p class="data-value"><?= htmlspecialchars($perfil['telefono'] !== 'agregar_numero' ? $perfil['telefono'] : 'No especificado') ?></p></div>
        </div>
    </div>

    <!-- Resumen Profesional -->
    <div class="hv-card">
        <div class="hv-card-header"><h5><i class="bi bi-person-lines-fill"></i>Resumen Profesional</h5></div>
        <div class="hv-card-body"><p class="data-value"><?= nl2br(htmlspecialchars($perfil['resumen_profesional'])) ?></p></div>
    </div>

    <!-- Experiencia y Educación -->
    <div class="row">
        <div class="col-md-6">
            <div class="hv-card">
                <div class="hv-card-header"><h5><i class="bi bi-briefcase-fill"></i>Experiencia Laboral</h5></div>
                <div class="hv-card-body"><p class="data-value"><?= nl2br(htmlspecialchars($perfil['experiencia_laboral'])) ?></p></div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="hv-card">
                <div class="hv-card-header"><h5><i class="bi bi-mortarboard-fill"></i>Educación</h5></div>
                <div class="hv-card-body"><p class="data-value"><?= nl2br(htmlspecialchars($perfil['educacion'])) ?></p></div>
            </div>
        </div>
    </div>

    <!-- Habilidades e Idiomas -->
    <div class="hv-card">
        <div class="hv-card-header"><h5><i class="bi bi-gear-wide-connected"></i>Habilidades e Idiomas</h5></div>
        <div class="hv-card-body">
            <div class="mb-3"><div class="data-label">Habilidades Clave</div><p class="data-value"><?= htmlspecialchars($perfil['habilidades']) ?></p></div>
            <div><div class="data-label">Idiomas</div><p class="data-value"><?= htmlspecialchars($perfil['idiomas']) ?></p></div>
        </div>
    </div>

    <!-- Enlaces y Archivo Adjunto -->
    <div class="hv-card">
        <div class="hv-card-header"><h5><i class="bi bi-cloud-arrow-up-fill"></i>Presencia Online y Archivos</h5></div>
        <div class="hv-card-body">
            <div class="row">
                <div class="col-md-4 mb-3"><div class="data-label">LinkedIn</div><p class="data-value"><?= ($perfil['enlace_linkedin'] !== 'no especificado' && !empty($perfil['enlace_linkedin'])) ? '<a href="'.htmlspecialchars($perfil['enlace_linkedin']).'" target="_blank" class="btn btn-sm btn-outline-custom">Ver Perfil</a>' : 'No especificado' ?></p></div>
                <div class="col-md-4 mb-3"><div class="data-label">GitHub</div><p class="data-value"><?= ($perfil['enlace_github'] !== 'no especificado' && !empty($perfil['enlace_github'])) ? '<a href="'.htmlspecialchars($perfil['enlace_github']).'" target="_blank" class="btn btn-sm btn-outline-custom">Ver Perfil</a>' : 'No especificado' ?></p></div>
                <div class="col-md-4 mb-3"><div class="data-label">Portfolio</div><p class="data-value"><?= ($perfil['enlace_portfolio'] !== 'no especificado' && !empty($perfil['enlace_portfolio'])) ? '<a href="'.htmlspecialchars($perfil['enlace_portfolio']).'" target="_blank" class="btn btn-sm btn-outline-custom">Ver Sitio</a>' : 'No especificado' ?></p></div>
            </div>
            <hr>
            <div class="data-label">CV Adjunto</div>
            <div class="data-value">
                <?php if (!empty($perfil['archivo_adjunto']) && $perfil['archivo_adjunto'] !== 'no especificado' && file_exists('uploads/cvs/' . $perfil['archivo_adjunto'])): ?>
                    <a href="uploads/cvs/<?= htmlspecialchars($perfil['archivo_adjunto']) ?>" target="_blank" class="btn btn-sm btn-gradient"><i class="bi bi-download me-2"></i>Descargar CV</a>
                <?php else: ?>
                    <p>No se adjuntó archivo.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="text-center mt-5">
        <a href="jovenes_profesionales.php" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-2"></i>Volver a la lista de profesionales
        </a>
    </div>
</main>

<?php include 'includes/footer.php'; ?>


<!--
[PROMPT_SUGGESTION]En la página de `ver_hv_publico.php`, ¿podemos añadir un botón para que una empresa pueda "Invitar a Postular" a un candidato a una de sus vacantes activas?[/PROMPT_SUGGESTION]
[PROMPT_SUGGESTION]Mejora la página de `dashboard.php` para que muestre estadísticas relevantes, como el número de vacantes publicadas (para empresas) o el número de postulaciones enviadas (para candidatos).[/PROMPT_SUGGESTION]
-->
