<?php
session_start();
require_once "conexion_dbs.php";
include 'includes/header.php';

$id_empresa = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$usuario_id = $_SESSION['usuario_id'] ?? null;
$usuario_rol = $_SESSION['usuario_rol'] ?? null;

if (!$id_empresa) {
    header("Location: buscar_empresas.php");
    exit();
}

// --- OBTENER DATOS DE LA EMPRESA ---
$sql_empresa = "
    SELECT 
        u.id, e.nombre_empresa, u.foto_perfil,
        e.industria, e.cantidad_empleados,
        (SELECT AVG(calificacion) FROM calificaciones_empresas WHERE id_empresa = u.id) as avg_rating
    FROM usuarios u
    JOIN empresas e ON u.id = e.usuario_id
    WHERE u.id = ? AND u.rol = 'empresa'
";
$stmt = $conexion_local->prepare($sql_empresa);
$stmt->bind_param("i", $id_empresa);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    echo "<main class='container py-5 text-center'><div class='alert alert-warning'>Esta empresa no existe o no está disponible.</div> <a href='buscar_empresas.php' class='btn btn-primary'>Volver</a></main>";
    include 'includes/footer.php';
    exit();
}
$empresa = $resultado->fetch_assoc();

// --- OBTENER VACANTES ACTIVAS DE LA EMPRESA ---
$sql_vacantes = "SELECT id, titulo, ubicacion, modalidad, estado FROM vacantes WHERE id_empresa = ? ORDER BY estado ASC, fecha_publicacion DESC";
$stmt_vacantes = $conexion_local->prepare($sql_vacantes);
$stmt_vacantes->bind_param("i", $id_empresa);
$stmt_vacantes->execute();
$vacantes = $stmt_vacantes->get_result()->fetch_all(MYSQLI_ASSOC);

// --- CORRECCIÓN: Contar solo las vacantes activas ---
$vacantes_activas_count = 0;
foreach ($vacantes as $vacante) {
    if ($vacante['estado'] === 'activa') $vacantes_activas_count++;
}
// --- OBTENER CALIFICACIÓN DEL USUARIO ACTUAL (SI APLICA) ---
$calificacion_usuario = 0;
if ($usuario_id && $usuario_rol === 'publico') {
    $stmt_rating = $conexion_local->prepare("SELECT calificacion FROM calificaciones_empresas WHERE id_empresa = ? AND id_usuario = ?");
    $stmt_rating->bind_param("ii", $id_empresa, $usuario_id);
    $stmt_rating->execute();
    $res_rating = $stmt_rating->get_result()->fetch_assoc();
    if ($res_rating) {
        $calificacion_usuario = $res_rating['calificacion'];
    }
}
?>

<style>
    .company-header {
        background: linear-gradient(135deg, var(--surface-color) 0%, var(--surface-color-secondary) 100%);
        border-bottom: 2px solid var(--primary-color);
    }
    .company-logo-detail {
        width: 120px;
        height: 120px;
        object-fit: contain;
        border-radius: 1rem;
        background-color: #fff;
        padding: 10px;
        border: 2px solid var(--border-color);
    }
    .company-logo-default-detail {
        width: 120px; height: 120px; display: flex; align-items: center; justify-content: center;
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        border-radius: 1rem; font-size: 4rem; color: white;
    }
    .vacante-item {
        border: 1px solid var(--border-color);
        border-radius: 0.75rem;
        transition: all 0.3s ease;
    }
    .vacante-item:hover {
        border-color: var(--primary-color);
        box-shadow: 0 4px 15px rgba(0,198,255,0.15);
        transform: translateY(-3px);
    }
    .vacante-item.cerrada {
        opacity: 0.6;
        background-color: var(--surface-color-secondary);
    }
</style>

<header class="company-header py-5">
    <div class="container">
        <div class="d-flex align-items-center">
            <?php
                $foto_empresa = (!empty($empresa['foto_perfil']) && $empresa['foto_perfil'] !== 'foto_default' && file_exists('uploads/avatars/' . $empresa['foto_perfil']))
                    ? 'uploads/avatars/' . htmlspecialchars($empresa['foto_perfil'])
                    : null;
            ?>
            <?php if ($foto_empresa): ?>
                <img src="<?= $foto_empresa ?>" alt="Logo <?= htmlspecialchars($empresa['nombre_empresa']) ?>" class="company-logo-detail me-4">
            <?php else: ?>
                <div class="company-logo-default-detail me-4"><i class="bi bi-building"></i></div>
            <?php endif; ?>
            <div>
                <h1 class="display-5 mb-2 fw-bold"><?= htmlspecialchars($empresa['nombre_empresa']) ?></h1>
                <div class="d-flex align-items-center gap-4">
                    <span class="text-muted"><i class="bi bi-briefcase-fill me-2 text-primary"></i><?= htmlspecialchars($empresa['industria'] ?: 'No especificada') ?></span>
                    <span class="text-muted"><i class="bi bi-people-fill me-2 text-primary"></i><?= htmlspecialchars($empresa['cantidad_empleados'] ?: 'No especificado') ?></span>
                    <span class="text-muted"><i class="bi bi-star-fill me-2 text-warning"></i><?= number_format($empresa['avg_rating'] ?? 0, 1) ?> / 5.0</span>
                </div>
            </div>
        </div>
    </div>
</header>

<main class="container py-5">
    <div class="row g-5">
        <!-- Columna de Vacantes -->
        <div class="col-lg-8">
            <h2 class="mb-4"><i class="bi bi-list-task me-2"></i>Vacantes de la Empresa (<?= $vacantes_activas_count ?> activas)</h2>
            <?php if (empty($vacantes)): ?>
                <div class="alert alert-light text-center">
                    <p class="lead mb-0">Esta empresa no tiene vacantes activas en este momento.</p>
                </div>
            <?php else: ?>
                <div class="list-group">
                    <?php foreach ($vacantes as $vacante): ?>
                        <a href="ver_vacante_detalle.php?id=<?= $vacante['id'] ?>" class="list-group-item list-group-item-action vacante-item p-3 mb-3 <?= $vacante['estado'] === 'cerrada' ? 'cerrada' : '' ?>">
                            <div class="d-flex w-100 justify-content-between">
                                <h5 class="mb-1 text-primary"><?= htmlspecialchars($vacante['titulo']) ?></h5>
                                <?php if ($vacante['estado'] === 'cerrada'): ?>
                                    <span class="badge bg-secondary">Cerrada</span>
                                <?php endif; ?>
                            </div>
                            <div class="d-flex gap-3">
                                <small class="text-muted"><i class="bi bi-geo-alt-fill me-1"></i><?= htmlspecialchars($vacante['ubicacion']) ?></small>
                                <small class="text-muted"><i class="bi bi-laptop me-1"></i><?= htmlspecialchars($vacante['modalidad']) ?></small>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Columna de Calificación -->
        <div class="col-lg-4">
            <div class="sidebar-sticky-wrapper">
                <div class="sidebar-card">
                    <h5><i class="bi bi-star-half me-2"></i>Califica esta Empresa</h5>
                    <?php if ($usuario_rol === 'publico'): ?>
                        <p class="small text-muted mb-3">Tu opinión ayuda a otros profesionales a tomar mejores decisiones.</p>
                        <a href="calificacion_empresa.php?id_empresa=<?= $empresa['id'] ?>" class="btn btn-gradient w-100">
                            <i class="bi bi-star-fill me-2"></i>
                            <?= $calificacion_usuario > 0 ? 'Ver o Editar Mi Calificación' : 'Escribir una Reseña' ?>
                        </a>
                        <?php if ($calificacion_usuario > 0): ?>
                            <div class="alert alert-info mt-3 mb-0 small">
                                <i class="bi bi-info-circle me-1"></i>Ya has calificado esta empresa con <strong><?= $calificacion_usuario ?> estrellas</strong>.
                            </div>
                        <?php endif; ?>
                    <?php elseif ($usuario_id): ?>
                        <div class="alert alert-secondary small">
                            La calificación está disponible solo para candidatos.
                        </div>
                    <?php else: ?>
                        <p class="small text-muted mb-3">Inicia sesión como candidato para poder calificar esta empresa.</p>
                        <a href="login.php" class="btn btn-outline-custom w-100">Iniciar Sesión</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?>
