<?php
session_start();
require_once "conexion_dbs.php";

// --- SEGURIDAD ---
// Proteger la página: solo para administradores (o el rol que designes)
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] !== 'admin') {
    // Si no es admin, podría ser una empresa viendo su propia facturación
    if ($_SESSION['usuario_rol'] !== 'empresa') {
        header("Location: login.php");
        exit();
    }
}

include 'includes/header.php';

// --- LÓGICA DE NEGOCIO: CÁLCULO DE COSTOS ---
const COSTO_POR_VISTA = 0.15; // Costo de "peaje" por cada vista (ej: $0.15)

$id_empresa_a_consultar = null;
$es_admin = ($_SESSION['usuario_rol'] === 'admin');

if ($es_admin) {
    // Si es admin, puede ver la facturación de cualquier empresa vía GET
    $id_empresa_a_consultar = filter_input(INPUT_GET, 'id_empresa', FILTER_VALIDATE_INT);
} else {
    // Si es una empresa, solo puede ver su propia facturación
    $id_empresa_a_consultar = $_SESSION['usuario_id'];
}

// Obtener lista de empresas para el selector (solo si es admin)
$empresas = [];
if ($es_admin) {
    $resultado_empresas = $conexion_local->query("SELECT u.id, e.nombre_empresa FROM usuarios u JOIN empresas e ON u.id = e.usuario_id WHERE u.rol = 'empresa' ORDER BY e.nombre_empresa");
    if ($resultado_empresas) {
        $empresas = $resultado_empresas->fetch_all(MYSQLI_ASSOC);
    }
}

$datos_facturacion = [];
$total_factura = 0;
$nombre_empresa_actual = '';

if ($id_empresa_a_consultar) {
    // Obtener el nombre de la empresa
    $stmt_nombre = $conexion_local->prepare("SELECT nombre_empresa FROM empresas WHERE usuario_id = ?");
    $stmt_nombre->bind_param("i", $id_empresa_a_consultar);
    $stmt_nombre->execute();
    $res_nombre = $stmt_nombre->get_result()->fetch_assoc();
    $nombre_empresa_actual = $res_nombre['nombre_empresa'] ?? 'Empresa Desconocida';

    // Consulta para obtener las vistas por vacante
    $sql = "
        SELECT 
            v.id as id_vacante,
            v.titulo,
            COUNT(vv.id) as total_vistas
        FROM vacantes v
        LEFT JOIN vacante_vistas vv ON v.id = vv.id_vacante
        WHERE v.id_empresa = ?
        GROUP BY v.id, v.titulo
        ORDER BY total_vistas DESC
    ";
    $stmt = $conexion_local->prepare($sql);
    $stmt->bind_param("i", $id_empresa_a_consultar);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $datos_facturacion = $resultado->fetch_all(MYSQLI_ASSOC);

    // Calcular el total
    foreach ($datos_facturacion as $dato) {
        $total_factura += $dato['total_vistas'] * COSTO_POR_VISTA;
    }
}

?>

<main class="container py-5">
    <h1 class="display-6 mb-4">Gestión de Facturación por Interacción</h1>
    <p class="lead text-muted">Análisis de las interacciones (vistas) de las vacantes para la gestión de costos de peaje.</p>

    <?php if ($es_admin): ?>
    <div class="card bg-light border-0 p-3 mb-4">
        <form method="GET" class="row g-3 align-items-center">
            <div class="col-auto">
                <label for="id_empresa" class="col-form-label"><strong>Seleccionar Empresa:</strong></label>
            </div>
            <div class="col">
                <select name="id_empresa" id="id_empresa" class="form-select" onchange="this.form.submit()">
                    <option value="">-- Elige una empresa para ver sus estadísticas --</option>
                    <?php foreach ($empresas as $empresa): ?>
                        <option value="<?= $empresa['id'] ?>" <?= ($id_empresa_a_consultar == $empresa['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($empresa['nombre_empresa']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </form>
    </div>
    <?php endif; ?>

    <?php if ($id_empresa_a_consultar && !empty($datos_facturacion)): ?>
        <div class="card shadow-sm">
            <div class="card-header bg-gradient text-white" style="background: linear-gradient(to right, var(--primary-color), var(--secondary-color));">
                <h4 class="mb-0">Factura Simulada para: <?= htmlspecialchars($nombre_empresa_actual) ?></h4>
            </div>
            <form action="generar_factura_pdf.php" method="POST" target="_blank" id="form-facturacion">
                <input type="hidden" name="id_empresa" value="<?= $id_empresa_a_consultar ?>">
                <div class="card-body">
                    <p class="text-muted">Selecciona las vacantes que deseas incluir en la factura (Costo por vista: $<?= number_format(COSTO_POR_VISTA, 2) ?>).</p>
                    
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th class="text-center" style="width: 5%;"><input type="checkbox" class="form-check-input" id="seleccionar-todo"></th>
                                    <th>Vacante</th>
                                    <th class="text-center">Total de Vistas</th>
                                    <th class="text-end">Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($datos_facturacion as $item): ?>
                                    <tr>
                                        <td class="text-center"><input type="checkbox" class="form-check-input vacante-checkbox" name="vacantes_a_facturar[]" value="<?= $item['id_vacante'] ?>"></td>
                                        <td><?= htmlspecialchars($item['titulo']) ?></td>
                                        <td class="text-center"><?= $item['total_vistas'] ?></td>
                                        <td class="text-end">$<?= number_format($item['total_vistas'] * COSTO_POR_VISTA, 2) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-4 text-center">
                        <button type="submit" class="btn btn-success"><i class="bi bi-file-earmark-pdf-fill me-2"></i>Generar Factura PDF</button>
                    </div>
                </div>
            </form>
            <div class="card-footer text-muted small">
                Factura generada el <?= date('d/m/Y H:i:s') ?>. Este es un documento simulado con fines de demostración.
            </div>
        </div>
    <?php elseif ($id_empresa_a_consultar): ?>
        <div class="alert alert-info text-center">
            <p class="lead">La empresa "<?= htmlspecialchars($nombre_empresa_actual) ?>" no tiene vacantes o aún no han recibido ninguna visita.</p>
        </div>
    <?php endif; ?>
</main>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const seleccionarTodo = document.getElementById('seleccionar-todo');
    const checkboxes = document.querySelectorAll('.vacante-checkbox');
    const formFacturacion = document.getElementById('form-facturacion');

    if (seleccionarTodo) {
        seleccionarTodo.addEventListener('change', function() {
            checkboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
        });
    }

    // --- NUEVA VALIDACIÓN ---
    // Evita que se genere la factura si no hay vacantes seleccionadas.
    if (formFacturacion) {
        formFacturacion.addEventListener('submit', function(event) {
            const vacantesSeleccionadas = document.querySelectorAll('.vacante-checkbox:checked').length;
            if (vacantesSeleccionadas === 0) {
                event.preventDefault(); // Detiene el envío del formulario
                alert('⚠️ Por favor, selecciona al menos una vacante para generar la factura.');
            }
        });
    }
});
</script>

<?php include 'includes/footer.php'; ?>