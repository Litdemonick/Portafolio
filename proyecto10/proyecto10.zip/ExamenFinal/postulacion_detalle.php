<?php
session_start();
require_once "conexion_dbs.php";

// Proteger la página: solo para candidatos logueados
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] !== 'publico') {
    $_SESSION['mensaje'] = "❌ Debes iniciar sesión como candidato para postularte.";
    header("Location: login.php");
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$id_vacante = filter_input(INPUT_GET, 'id_vacante', FILTER_VALIDATE_INT);

if (!$id_vacante) {
    header("Location: buscar.php");
    exit();
}

// --- OBTENER DATOS DE LA VACANTE Y LA HV DEL USUARIO ---
// Obtener datos de la vacante
$stmt_vacante = $conexion_local->prepare("
    SELECT v.titulo, e.nombre_empresa 
    FROM vacantes v 
    JOIN empresas e ON v.id_empresa = e.usuario_id 
    WHERE v.id = ?");
$stmt_vacante->bind_param("i", $id_vacante);
$stmt_vacante->execute();
$vacante = $stmt_vacante->get_result()->fetch_assoc();

// Obtener datos de la HV
$stmt_hv = $conexion_local->prepare("SELECT id, titulo_profesional FROM hvs WHERE usuario_id = ?");
$stmt_hv->bind_param("i", $usuario_id);
$stmt_hv->execute();
$hv = $stmt_hv->get_result()->fetch_assoc();

if (!$vacante || !$hv) {
    // Si la vacante o la HV no existen, redirigir con error
    $_SESSION['mensaje_detalle_vacante'] = "❌ Error: La vacante no existe o no tienes una HV creada.";
    $_SESSION['mensaje_detalle_vacante_tipo'] = 'danger';
    header("Location: ver_vacante_detalle.php?id=" . $id_vacante);
    exit();
}

// --- LÓGICA DE POSTULACIÓN (POST) ---
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['confirmar_postulacion'])) {
    // Verificar si ya se postuló (doble chequeo)
    $stmt_check = $conexion_local->prepare("SELECT id FROM postulaciones WHERE id_vacante = ? AND id_usuario = ?");
    $stmt_check->bind_param("ii", $id_vacante, $usuario_id);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows > 0) {
        $_SESSION['mensaje_detalle_vacante'] = "ℹ️ Ya te has postulado a esta vacante.";
        $_SESSION['mensaje_detalle_vacante_tipo'] = 'info';
    } else {
        // Iniciar transacción para asegurar consistencia
        $conexion_local->begin_transaction();
        try {
            // 1. Insertar la postulación
            $id_hv = $hv['id'];
            $stmt_insert = $conexion_local->prepare("INSERT INTO postulaciones (id_vacante, id_usuario, id_hv, estado, fecha_postulacion) VALUES (?, ?, ?, 'recibido', NOW())");
            $stmt_insert->bind_param("iii", $id_vacante, $usuario_id, $id_hv);
            $stmt_insert->execute();
            $id_postulacion_nueva = $conexion_local->insert_id;

            // 2. Restar un puesto disponible
            $stmt_update = $conexion_local->prepare("UPDATE vacantes SET puestos_disponibles = puestos_disponibles - 1 WHERE id = ? AND puestos_disponibles > 0");
            $stmt_update->bind_param("i", $id_vacante);
            $stmt_update->execute();

            // 3. Replicar ambas consultas de forma segura
            $sql_replica_postulacion = "INSERT INTO postulaciones (id, id_vacante, id_usuario, id_hv, estado, fecha_postulacion) VALUES (?, ?, ?, ?, 'recibido', NOW())";
            $resultado_postulacion = replicar_consulta($sql_replica_postulacion, "iiii", [$id_postulacion_nueva, $id_vacante, $usuario_id, $id_hv]);
            
            $sql_replica_update = "UPDATE vacantes SET puestos_disponibles = puestos_disponibles - 1 WHERE id = ?";
            $resultado_update = replicar_consulta($sql_replica_update, "i", [$id_vacante]);

            // 4. Confirmar transacción
            $conexion_local->commit();

            $_SESSION['mensaje_detalle_vacante'] = "✅ ¡Te has postulado con éxito! La empresa revisará tu perfil.";
            $_SESSION['mensaje_detalle_vacante_tipo'] = 'success';

        } catch (Exception $e) {
            $conexion_local->rollback();
            $_SESSION['mensaje_detalle_vacante'] = "❌ Hubo un error al procesar tu postulación.";
            $_SESSION['mensaje_detalle_vacante_tipo'] = 'danger';
        }
    }
    header("Location: ver_vacante_detalle.php?id=" . $id_vacante);
    exit();
}

include 'includes/header.php';
?>

<style>
    .confirmation-card {
        background-color: var(--surface-color);
        border: 1px solid var(--border-color);
        border-radius: 1rem;
        padding: 2rem 3rem;
        box-shadow: 0 8px 30px rgba(0,0,0,0.1);
        max-width: 700px;
        margin: auto;
    }
    .summary-box {
        background-color: var(--bg-color);
        border: 1px solid var(--border-color);
        border-radius: 0.75rem;
        padding: 1.5rem;
        margin-bottom: 1.5rem;
    }
    .summary-box h5 {
        color: var(--primary-color);
        font-weight: 600;
    }
    .summary-box p {
        margin-bottom: 0.5rem;
    }
</style>

<main class="container py-5">
    <div class="confirmation-card">
        <h1 class="form-title text-center">Confirmar Postulación</h1>
        <p class="form-subtitle text-center">Estás a un paso de aplicar a esta oportunidad.</p>

        <div class="my-4">
            <!-- Resumen de la Vacante -->
            <div class="summary-box">
                <h5><i class="bi bi-briefcase-fill me-2"></i>Vacante</h5>
                <p><strong>Puesto:</strong> <?= htmlspecialchars($vacante['titulo']) ?></p>
                <p class="mb-0"><strong>Empresa:</strong> <?= htmlspecialchars($vacante['nombre_empresa']) ?></p>
            </div>

            <!-- Resumen de la HV -->
            <div class="summary-box">
                <h5><i class="bi bi-person-vcard-fill me-2"></i>Tu Hoja de Vida</h5>
                <p><strong>Perfil:</strong> <?= htmlspecialchars($hv['titulo_profesional']) ?></p>
                <p class="mb-0 text-muted small">
                    <i class="bi bi-info-circle-fill me-1"></i>Se enviará tu HV completa, incluyendo datos de contacto, experiencia, educación y archivo adjunto (si lo tienes).
                </p>
            </div>
        </div>

        <form method="POST" action="postulacion_detalle.php?id_vacante=<?= $id_vacante ?>">
            <div class="d-flex justify-content-between align-items-center">
                <a href="ver_vacante_detalle.php?id=<?= $id_vacante ?>" class="btn btn-outline-secondary">Cancelar</a>
                <button type="submit" name="confirmar_postulacion" class="btn btn-gradient btn-lg">
                    <i class="bi bi-check-circle-fill me-2"></i>Confirmar y Enviar
                </button>
            </div>
        </form>
    </div>
</main>

<?php include 'includes/footer.php'; ?>