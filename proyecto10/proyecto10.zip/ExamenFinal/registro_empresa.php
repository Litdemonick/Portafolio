<?php
session_start();
include 'includes/header.php';
require_once "conexion_dbs.php";

$mensaje = $_SESSION['mensaje'] ?? '';
$_SESSION['mensaje'] = ''; // Limpiar para no mostrar en otras páginas

// Variables para mantener los valores del formulario en caso de error
$nombre_empresa_val = '';
$razon_social_val = '';
$condicion_fiscal_val = '';
$documento_val = '';
$nombres_val = '';
$apellidos_val = '';
$correo_val = '';
$tipo_documento_val = '';
$numero_documento_val = '';
$provincia_val = '';
$calle_val = '';
$numero_direccion_val = '';
$codigo_postal_val = '';
$telefono_empresa_val = '';
$industria_val = '';
$cantidad_empleados_val = '';
$telefono_val = '';
$tipo_empresa_val = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Recolectar datos para repoblar el formulario
    $nombre_empresa_val = htmlspecialchars($_POST['nombre_empresa'] ?? '');
    $razon_social_val = htmlspecialchars($_POST['razon_social'] ?? '');
    $condicion_fiscal_val = htmlspecialchars($_POST['condicion_fiscal'] ?? '');
    $documento_val = htmlspecialchars($_POST['documento'] ?? '');
    $nombres_val = htmlspecialchars($_POST['nombres'] ?? '');
    $apellidos_val = htmlspecialchars($_POST['apellidos'] ?? '');
    $correo_val = htmlspecialchars($_POST['email'] ?? '');
    $tipo_documento_val = htmlspecialchars($_POST['tipo_documento'] ?? '');
    $numero_documento_val = htmlspecialchars($_POST['numero_documento'] ?? '');
    $provincia_val = htmlspecialchars($_POST['provincia'] ?? '');
    $calle_val = htmlspecialchars($_POST['calle'] ?? '');
    $numero_direccion_val = htmlspecialchars($_POST['numero_direccion'] ?? '');
    $codigo_postal_val = htmlspecialchars($_POST['codigo_postal'] ?? '');
    $telefono_empresa_val = htmlspecialchars($_POST['telefono_empresa'] ?? '');
    $industria_val = htmlspecialchars($_POST['industria'] ?? '');
    $cantidad_empleados_val = htmlspecialchars($_POST['cantidad_empleados'] ?? '');
    $telefono_val = htmlspecialchars($_POST['telefono'] ?? '');
    $tipo_empresa_val = htmlspecialchars($_POST['tipo_empresa'] ?? '');

    // --- 1. VALIDACIONES ---
    $required_fields = ['nombre_empresa', 'razon_social', 'documento', 'nombres', 'apellidos', 'email', 'password', 'password_repeat', 'condicion_fiscal', 'tipo_documento', 'numero_documento'];
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            $mensaje = "❌ Todos los campos con * son obligatorios.";
        }
    }

    if (empty($mensaje) && strlen($_POST['password']) < 6) {
        $mensaje = "❌ La contraseña debe tener al menos 6 caracteres.";
    } elseif (empty($mensaje) && $_POST['password'] !== $_POST['password_repeat']) {
        $mensaje = "❌ Las contraseñas no coinciden.";
    }

    // --- 2. SANEAMIENTO DE DATOS ---
    // Datos del usuario
    $nombres   = $conexion_local->real_escape_string($_POST["nombres"]);
    $apellidos = $conexion_local->real_escape_string($_POST["apellidos"]);
    $correo    = $conexion_local->real_escape_string($_POST["email"]);
    $tipo_documento = $conexion_local->real_escape_string($_POST["tipo_documento"]);
    $numero_documento = $conexion_local->real_escape_string($_POST["numero_documento"]);
    $password  = password_hash($_POST["password"], PASSWORD_DEFAULT);
    $telefono_input = $_POST["telefono"] ?? '';
    $telefono  = !empty($telefono_input) ? $conexion_local->real_escape_string($telefono_input) : 'agregar_numero';
    $rol       = 'empresa';
    $fecha     = date("Y-m-d H:i:s");

    // Datos de la empresa
    $nombre_empresa = $conexion_local->real_escape_string($_POST["nombre_empresa"]);
    $razon_social   = $conexion_local->real_escape_string($_POST["razon_social"]);
    $condicion_fiscal = $conexion_local->real_escape_string($_POST["condicion_fiscal"] ?? null);
    $documento      = $conexion_local->real_escape_string($_POST["documento"]);
    $provincia = $conexion_local->real_escape_string($_POST['provincia'] ?? null);
    $calle = $conexion_local->real_escape_string($_POST['calle'] ?? null);
    $numero_direccion = $conexion_local->real_escape_string($_POST['numero_direccion'] ?? null);
    $codigo_postal = $conexion_local->real_escape_string($_POST['codigo_postal'] ?? null);
    $telefono_empresa = $conexion_local->real_escape_string($_POST['telefono_empresa'] ?? null);
    $industria = $conexion_local->real_escape_string($_POST['industria'] ?? null);
    $cantidad_empleados = $conexion_local->real_escape_string($_POST['cantidad_empleados'] ?? null);

    $tipo_empresa = $conexion_local->real_escape_string($_POST['tipo_empresa'] ?? null);
    // --- 3. VERIFICACIÓN DE DUPLICADOS ---
    if (empty($mensaje)) {
        $stmt_check = $conexion_local->prepare("SELECT id FROM usuarios WHERE correo = ?");
        $stmt_check->bind_param("s", $correo);
        $stmt_check->execute();
        $email_exists = $stmt_check->get_result()->num_rows > 0;

        $stmt_check = $conexion_local->prepare("SELECT id FROM empresas WHERE documento = ?");
        $stmt_check->bind_param("s", $documento);
        $stmt_check->execute();
        $doc_empresa_exists = $stmt_check->get_result()->num_rows > 0;

        $stmt_check = $conexion_local->prepare("SELECT id FROM usuarios WHERE numero_documento = ?");
        $stmt_check->bind_param("s", $numero_documento);
        $stmt_check->execute();
        $doc_usuario_exists = $stmt_check->get_result()->num_rows > 0;

        $phone_exists = false;
        if (!empty($telefono_input)) {
            $stmt_check = $conexion_local->prepare("SELECT id FROM usuarios WHERE telefono = ?");
            $stmt_check->bind_param("s", $telefono);
            $stmt_check->execute();
            $phone_exists = $stmt_check->get_result()->num_rows > 0;
        }

        if ($email_exists) {
        $mensaje = "❌ Error: El correo electrónico '$correo_val' ya está registrado.";
        } elseif ($doc_empresa_exists) {
        $mensaje = "❌ Error: El documento (RUC) '$documento_val' ya pertenece a otra empresa.";
        } elseif ($doc_usuario_exists) {
            $mensaje = "❌ Error: El número de documento del contacto '$numero_documento_val' ya está registrado.";
        } elseif ($phone_exists) {
            $mensaje = "❌ Error: El número de teléfono del contacto '$telefono_val' ya está en uso.";
        } else {
        // --- 4. INSERCIÓN CON TRANSACCIONES ---
        // Usamos transacciones para asegurar que ambas inserciones (usuario y empresa) se completen.
        $conexion_local->begin_transaction();
        $conexion_remota->begin_transaction();

        try {
            // Insertar usuario
            $sql_usuario = "INSERT INTO usuarios (nombres, apellidos, correo, tipo_documento, numero_documento, telefono, password, rol, fecha_creacion, foto_perfil) VALUES ('$nombres', '$apellidos', '$correo', '$tipo_documento', '$numero_documento', '$telefono', '$password', '$rol', '$fecha', 'foto_default')";
            $res_usuario = replicar_consulta($sql_usuario);
            if (!$res_usuario['success']) {
                throw new Exception("Error al crear el usuario.");
            }

            // Obtener el ID del nuevo usuario (de la conexión local es suficiente)
            $nuevo_usuario_id = $conexion_local->insert_id;

            // Insertar empresa
            $sql_empresa = "INSERT INTO empresas (usuario_id, nombre_empresa, razon_social, condicion_fiscal, documento, provincia, calle, numero_direccion, codigo_postal, telefono_empresa, industria, cantidad_empleados, tipo_empresa, fecha_creacion) VALUES ('$nuevo_usuario_id', '$nombre_empresa', '$razon_social', '$condicion_fiscal', '$documento', '$provincia', '$calle', '$numero_direccion', '$codigo_postal', '$telefono_empresa', '$industria', '$cantidad_empleados', '$tipo_empresa', '$fecha')";
            $res_empresa = replicar_consulta($sql_empresa);
            if (!$res_empresa['success']) {
                throw new Exception("Error al registrar los datos de la empresa.");
            }

            // Si todo fue bien, confirmar los cambios
            $conexion_local->commit();
            $conexion_remota->commit();

            $_SESSION['mensaje'] = "✅ ¡Empresa registrada con éxito! Ahora puedes iniciar sesión.";
            header("Location: login.php");
            exit();

        } catch (Exception $e) {
            // Si algo falló, revertir todos los cambios
            $conexion_local->rollback();
            $conexion_remota->rollback();
            $mensaje = "❌ Error en el registro: " . $e->getMessage();
        }
    }
    }
}
?>

<style>
    /* Estilos para mejorar la legibilidad en modo oscuro en esta página específica */
    body[data-theme="dark"] .form-container .form-label,
    body[data-theme="dark"] .form-container .form-check-label,
    body[data-theme="dark"] .form-container .form-text,
    body[data-theme="dark"] .form-container .text-center a {
        color: #f8f9fa !important; /* Un color blanco/casi blanco */
    }
</style>

<main class="container py-5 d-flex align-items-center justify-content-center" style="min-height: calc(100vh - 150px);">
    <div class="form-container">
        <h1 class="form-title">Crear Cuenta de Empresa</h1>
        <p class="form-subtitle">Publica tus vacantes y encuentra al mejor talento.</p>

        <?php if (!empty($mensaje)) : ?>
            <div class="alert <?= str_contains($mensaje, '❌') ? 'alert-danger' : 'alert-success' ?> mt-3"><?= htmlspecialchars($mensaje) ?></div>
        <?php endif; ?>

        <form method="POST" class="mt-4">
            <h2 class="form-section-title">Datos de la empresa</h2>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="nombre_empresa" class="form-label">Nombre de la empresa*</label>
                    <input type="text" class="form-control" id="nombre_empresa" name="nombre_empresa" value="<?= $nombre_empresa_val ?>" required maxlength="255">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="razon_social" class="form-label">Razón social*</label>
                    <input type="text" class="form-control" id="razon_social" name="razon_social" value="<?= $razon_social_val ?>" required maxlength="255">
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="tipo_empresa" class="form-label">Tipo de empresa</label>
                    <select class="form-select" id="tipo_empresa" name="tipo_empresa">
                        <option value="" disabled <?= empty($tipo_empresa_val) ? 'selected' : '' ?>>Seleccione una opción</option>
                        <option value="privada" <?= $tipo_empresa_val == 'privada' ? 'selected' : '' ?>>Privada</option>
                        <option value="publica" <?= $tipo_empresa_val == 'publica' ? 'selected' : '' ?>>Pública</option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="condicion_fiscal" class="form-label">Condición fiscal*</label>
                    <select class="form-select" id="condicion_fiscal" name="condicion_fiscal" required>
                        <option value="" disabled <?= empty($condicion_fiscal_val) ? 'selected' : '' ?>>Seleccione una opción</option>
                        <option value="persona_natural" <?= $condicion_fiscal_val == 'persona_natural' ? 'selected' : '' ?>>Persona Natural</option>
                        <option value="sociedad_anonima" <?= $condicion_fiscal_val == 'sociedad_anonima' ? 'selected' : '' ?>>Sociedad Anónima</option>
                        <option value="otro" <?= $condicion_fiscal_val == 'otro' ? 'selected' : '' ?>>Otro</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="documento" class="form-label">Documento (RUC)*</label>
                    <input type="text" class="form-control" id="documento" name="documento" value="<?= $documento_val ?>" placeholder="Ej: 123456789" required pattern="[0-9]*" title="Ingresar solo números, sin guiones.">
                    <div class="form-text">Ingresar solo números, sin guiones.</div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="telefono_empresa" class="form-label">Teléfono de la empresa</label>
                    <input type="tel" class="form-control" id="telefono_empresa" name="telefono_empresa" value="<?= $telefono_empresa_val ?>" maxlength="20">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="industria" class="form-label">Industria</label>
                    <input type="text" class="form-control" id="industria" name="industria" value="<?= $industria_val ?>" placeholder="Ej: Tecnología, Retail, etc.">
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="cantidad_empleados" class="form-label">Cantidad de empleados</label>
                    <select class="form-select" id="cantidad_empleados" name="cantidad_empleados">
                        <option value="" disabled <?= empty($cantidad_empleados_val) ? 'selected' : '' ?>>Seleccione un rango</option>
                        <option value="1-10" <?= $cantidad_empleados_val == '1-10' ? 'selected' : '' ?>>1-10 empleados</option>
                        <option value="11-50" <?= $cantidad_empleados_val == '11-50' ? 'selected' : '' ?>>11-50 empleados</option>
                        <option value="51-200" <?= $cantidad_empleados_val == '51-200' ? 'selected' : '' ?>>51-200 empleados</option>
                        <option value="201-500" <?= $cantidad_empleados_val == '201-500' ? 'selected' : '' ?>>201-500 empleados</option>
                        <option value="501+" <?= $cantidad_empleados_val == '501+' ? 'selected' : '' ?>>Más de 500 empleados</option>
                    </select>
                </div>
            </div>

            <h2 class="form-section-title mt-4">Dirección de la empresa</h2>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="provincia" class="form-label">Provincia</label>
                    <input type="text" class="form-control" id="provincia" name="provincia" value="<?= $provincia_val ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="calle" class="form-label">Calle</label>
                    <input type="text" class="form-control" id="calle" name="calle" value="<?= $calle_val ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="numero_direccion" class="form-label">Número</label>
                    <input type="text" class="form-control" id="numero_direccion" name="numero_direccion" value="<?= $numero_direccion_val ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="codigo_postal" class="form-label">Código Postal</label>
                    <input type="text" class="form-control" id="codigo_postal" name="codigo_postal" value="<?= $codigo_postal_val ?>">
                </div>
            </div>

            <hr class="my-4">

            <h2 class="form-section-title">Información de tu usuario</h2>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="nombres" class="form-label">Nombre(s)*</label>
                    <input type="text" class="form-control" id="nombres" name="nombres" value="<?= $nombres_val ?>" required maxlength="100">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="apellidos" class="form-label">Apellido(s)*</label>
                    <input type="text" class="form-control" id="apellidos" name="apellidos" value="<?= $apellidos_val ?>" required maxlength="100">
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="tipo_documento" class="form-label">Tipo de Documento*</label>
                    <select class="form-select" id="tipo_documento" name="tipo_documento" required>
                        <option value="" disabled <?= empty($tipo_documento_val) ? 'selected' : '' ?>>Seleccione...</option>
                        <option value="cedula" <?= $tipo_documento_val == 'cedula' ? 'selected' : '' ?>>Cédula</option>
                        <option value="pasaporte" <?= $tipo_documento_val == 'pasaporte' ? 'selected' : '' ?>>Pasaporte</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="numero_documento" class="form-label">Número de Documento*</label>
                    <input type="text" class="form-control" id="numero_documento" name="numero_documento" value="<?= $numero_documento_val ?>" required>
                </div>
            </div>
            <div class="mb-3">
                <label for="telefono" class="form-label">Teléfono (Opcional)</label>
                <input type="tel" class="form-control" id="telefono" name="telefono" value="<?= $telefono_val ?>" maxlength="20">
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email*</label>
                <input type="email" class="form-control" id="email" name="email" value="<?= $correo_val ?>" placeholder="A este mail se enviarán las facturas" required>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="password" class="form-label">Contraseña*</label>
                    <input type="password" class="form-control" id="password" name="password" required minlength="6">
                    <div class="form-text">Debe tener al menos 6 caracteres.</div>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="password_repeat" class="form-label">Repetir contraseña*</label>
                    <input type="password" class="form-control" id="password_repeat" name="password_repeat" required minlength="6">
                </div>
            </div>

            <hr class="my-4">

            <div class="form-check mb-2">
                <input class="form-check-input" type="checkbox" value="" id="terminos" required>
                <label class="form-check-label" for="terminos">
                    Acepto los <a href="#">Términos y Condiciones</a> y la <a href="#">Política de Privacidad</a>.*
                </label>
            </div>
            <div class="form-check mb-2">
                <input class="form-check-input" type="checkbox" value="" id="newsletter">
                <label class="form-check-label" for="newsletter">
                    Quiero recibir newsletters con novedades y promociones.
                </label>
            </div>
            <div class="form-check mb-3">
                <input class="form-check-input" type="checkbox" value="" id="encuestas">
                <label class="form-check-label" for="encuestas">
                    Quiero participar en encuestas para ayudar a mejorar la plataforma.
                </label>
            </div>

            <button type="submit" class="btn btn-gradient w-100 btn-lg mt-3">Crear Cuenta Empresa</button>

            <p class="text-center mt-4">
                ¿Ya tienes cuenta? <a href="login.php">Ingresa a tu cuenta empresa</a>
            </p>
        </form>
    </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?>