<?php
session_start();

// Proteger la página: si no hay un ID de usuario para resetear, redirigir
if (!isset($_SESSION['reset_password_user_id'])) {
    header('Location: login.php');
    exit();
}

include 'includes/header.php';
require_once "conexion_dbs.php";

$mensaje = '';
$usuario_id = $_SESSION['reset_password_user_id'];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (empty($_POST['password']) || empty($_POST['password_repeat'])) {
        $mensaje = "❌ Ambos campos son obligatorios.";
    } elseif (strlen($_POST['password']) < 6) {
        $mensaje = "❌ La contraseña debe tener al menos 6 caracteres.";
    } elseif ($_POST['password'] !== $_POST['password_repeat']) {
        $mensaje = "❌ Las contraseñas no coinciden.";
    } else {
        $password_hash = password_hash($_POST['password'], PASSWORD_DEFAULT);

        // Usamos consultas preparadas para mayor seguridad
        $sql_template = "UPDATE usuarios SET password = ? WHERE id = ?";

        // Ejecutar en la conexión local
        $stmt_local = $conexion_local->prepare($sql_template);
        $stmt_local->bind_param("si", $password_hash, $usuario_id);
        $ok1 = $stmt_local->execute();

        // Ejecutar en la conexión remota
        $stmt_remoto = $conexion_remota->prepare($sql_template);
        $stmt_remoto->bind_param("si", $password_hash, $usuario_id);
        $ok2 = $stmt_remoto->execute();

        // Simulamos el resultado de replicar_consulta
        $resultado_replicacion = ['success' => ($ok1 && $ok2)];

        if ($resultado_replicacion['success']) {
            // Limpiar la sesión y redirigir al login con mensaje de éxito
            unset($_SESSION['reset_password_user_id']);
            $_SESSION['mensaje'] = "✅ ¡Contraseña actualizada con éxito! Ya puedes iniciar sesión.";
            header('Location: login.php');
            exit();
        } else {
            $mensaje = "❌ Error al actualizar la contraseña. Por favor, inténtalo de nuevo.";
        }
    }
}
?>

<main class="container d-flex align-items-center justify-content-center" style="min-height: 85vh;">
    <div class="form-container mx-auto" style="max-width: 450px;">
        <h1 class="form-title text-center">Establecer Nueva Contraseña</h1>
        <p class="form-subtitle text-center">Ingresa tu nueva contraseña a continuación.</p>

        <?php if (!empty($mensaje)) : ?>
            <div class="alert alert-danger mt-3"><?= htmlspecialchars($mensaje) ?></div>
        <?php endif; ?>

        <form method="POST" class="mt-4">
            <div class="mb-3">
                <label for="password" class="form-label">Nueva Contraseña</label>
                <input type="password" class="form-control" id="password" name="password" required minlength="6">
            </div>
            <div class="mb-3">
                <label for="password_repeat" class="form-label">Repetir Nueva Contraseña</label>
                <input type="password" class="form-control" id="password_repeat" name="password_repeat" required minlength="6">
            </div>
            <button type="submit" class="btn btn-gradient w-100 btn-lg mt-3">Cambiar Contraseña</button>
        </form>
    </div>
</main>

<?php include 'includes/footer.php'; ?>