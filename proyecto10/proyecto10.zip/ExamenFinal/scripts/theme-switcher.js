// scripts/theme-switcher.js
document.addEventListener('DOMContentLoaded', () => {
    const themeSwitcher = document.getElementById('theme-switcher');
    const themeIcon = document.getElementById('theme-icon'); // El icono a cambiar

    // Función para cambiar el tema y el icono al hacer clic
    const toggleTheme = () => {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme); // CORRECCIÓN: Usar la variable correcta 'newTheme'
        updateIcon(newTheme);
    };

    // Función para actualizar solo el icono
    const updateIcon = (theme) => {
        if (themeIcon) {
            themeIcon.className = theme === 'light' ? 'bi bi-moon-stars-fill' : 'bi bi-sun-fill';
        }
    };

    // Al cargar, solo actualizamos el icono para que coincida con el tema ya aplicado
    updateIcon(document.documentElement.getAttribute('data-theme'));

    // Añadimos el evento de clic al botón
    if (themeSwitcher) themeSwitcher.addEventListener('click', toggleTheme);
});