<?php
session_start();
require_once "conexion_dbs.php";

// --- 1. SEGURIDAD: SOLO PARA USUARIOS LOGUEADOS ---
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

include 'includes/header.php';

// --- 2. LÓGICA DE BÚSQUEDA, FILTROS Y PAGINACIÓN ---
$search_query = trim($_GET['q'] ?? '');
$status_filter = trim($_GET['status'] ?? 'todos');
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$items_per_page = 12; // 12 perfiles por página
$offset = ($page - 1) * $items_per_page;

// --- 3. CONSTRUCCIÓN DE LA CONSULTA DINÁMICA ---
$params = [];
$types = "";

$sql_base = "
    FROM usuarios u
    LEFT JOIN hvs h ON u.id = h.usuario_id
    LEFT JOIN (
        SELECT p.id_usuario, v.id_empresa
        FROM postulaciones p
        JOIN vacantes v ON p.id_vacante = v.id
        WHERE p.estado = 'aceptado'
        GROUP BY p.id_usuario
    ) AS postulacion_aceptada ON u.id = postulacion_aceptada.id_usuario
    LEFT JOIN empresas emp_contratante ON postulacion_aceptada.id_empresa = emp_contratante.usuario_id
    WHERE u.rol = 'publico'
";

if (!empty($search_query)) {
    $sql_base .= " AND (CONCAT(u.nombres, ' ', u.apellidos) LIKE ? OR h.titulo_profesional LIKE ?)";
    $search_param = "%" . $search_query . "%";
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= "ss";
}

if ($status_filter === 'disponible') {
    $sql_base .= " AND postulacion_aceptada.id_usuario IS NULL";
} elseif ($status_filter === 'contratado') {
    $sql_base .= " AND postulacion_aceptada.id_usuario IS NOT NULL";
}

// Contar total de resultados para la paginación
$sql_count = "SELECT COUNT(u.id) as total " . $sql_base;
$stmt_count = $conexion_local->prepare($sql_count);
if (!empty($types)) {
    $stmt_count->bind_param($types, ...$params);
}
$stmt_count->execute();
$total_items = $stmt_count->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_items / $items_per_page);

// Obtener profesionales para la página actual
$sql_select = "
    SELECT 
        u.id AS usuario_id,
        u.nombres,
        u.apellidos,
        u.foto_perfil,
        h.id AS id_hv,
        h.titulo_profesional,
        emp_contratante.nombre_empresa AS empresa_actual
" . $sql_base . " ORDER BY u.nombres, u.apellidos LIMIT ? OFFSET ?";
$params[] = $items_per_page;
$params[] = $offset;
$types .= "ii";

$stmt = $conexion_local->prepare($sql_select);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$resultado = $stmt->get_result();
$profesionales = $resultado->fetch_all(MYSQLI_ASSOC);

?>

<style>
    .professional-card {
        background-color: var(--surface-color);
        border: 1px solid var(--border-color);
        border-radius: 1rem;
        padding: 1.5rem;
        transition: all 0.3s ease;
        text-align: center;
        height: 100%;
        display: flex;
        flex-direction: column;
    }

    .professional-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        border-color: var(--primary-color);
    }

    .professional-avatar {
        width: 100px;
        height: 100px;
        object-fit: cover;
        border-radius: 50%;
        margin: 0 auto 1rem auto;
        border: 4px solid var(--primary-color);
    }

    .professional-avatar-default {
        width: 100px;
        height: 100px;
        border-radius: 50%;
        margin: 0 auto 1rem auto;
        background-color: var(--border-color);
        color: var(--text-color-muted);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 3.5rem;
        border: 4px solid var(--border-color);
    }

    .professional-name {
        font-weight: 600;
        color: var(--text-color);
        font-size: 1.2rem;
        margin-bottom: 0.25rem;
    }

    .professional-title {
        color: var(--text-color-muted);
        font-size: 0.9rem;
        min-height: 40px; /* Espacio para dos líneas de título */
    }

    .status-badge {
        display: inline-block;
        padding: 0.4rem 0.8rem;
        border-radius: 2rem;
        font-size: 0.8rem;
        font-weight: 500;
        margin-top: 1rem;
    }

    .status-badge.disponible {
        background-color: rgba(40, 167, 69, 0.15);
        color: #28a745;
    }

    [data-theme="dark"] .status-badge.disponible {
        color: #34d399; /* Un verde más brillante para modo oscuro */
    }

    .status-badge.contratado {
        background-color: rgba(255, 193, 7, 0.15);
        color: #ffc107;
    }

    [data-theme="dark"] .status-badge.contratado {
        color: #fbbf24; /* Un amarillo más brillante */
    }

    .card-footer-actions {
        margin-top: auto; /* Empuja el footer hacia abajo */
        padding-top: 1.5rem;
        border-top: 1px solid var(--border-color);
    }
</style>

<main class="container py-5">
    <div class="text-center mb-5">
        <h1 class="display-6">Jóvenes Profesionales</h1>
        <p class="lead text-muted">Descubre el talento disponible en nuestra comunidad. Se encontraron <?= $total_items ?> perfiles.</p>
    </div>

    <!-- Formulario de Filtros -->
    <div class="card mb-5" style="background-color: var(--surface-color); border-color: var(--border-color);">
        <div class="card-body">
            <form method="GET" action="jovenes_profesionales.php">
                <div class="row g-3 align-items-end">
                    <div class="col-md-6">
                        <label for="q" class="form-label">Buscar por nombre o título</label>
                        <input type="text" class="form-control" name="q" id="q" placeholder="Ej: Juan Perez, Desarrollador PHP..." value="<?= htmlspecialchars($search_query) ?>">
                    </div>
                    <div class="col-md-3">
                        <label for="status" class="form-label">Estado</label>
                        <select name="status" id="status" class="form-select">
                            <option value="todos" <?= $status_filter === 'todos' ? 'selected' : '' ?>>Todos</option>
                            <option value="disponible" <?= $status_filter === 'disponible' ? 'selected' : '' ?>>Disponibles</option>
                            <option value="contratado" <?= $status_filter === 'contratado' ? 'selected' : '' ?>>Contratados</option>
                        </select>
                    </div>
                    <div class="col-md-3 d-flex gap-2">
                        <button type="submit" class="btn btn-gradient w-100"><i class="bi bi-funnel-fill me-2"></i>Filtrar</button>
                        <a href="jovenes_profesionales.php" class="btn btn-outline-secondary w-100">Limpiar</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="row g-4 mb-5">
        <?php foreach ($profesionales as $perfil) : ?>
            <div class="col-xl-3 col-lg-4 col-md-6">
                <div class="professional-card">
                    <?php
                    $foto = (!empty($perfil['foto_perfil']) && $perfil['foto_perfil'] !== 'foto_default' && file_exists('uploads/avatars/' . $perfil['foto_perfil']))
                        ? 'uploads/avatars/' . htmlspecialchars($perfil['foto_perfil'])
                        : null;
                    ?>
                    <?php if ($foto) : ?>
                        <img src="<?= $foto ?>" alt="Foto de <?= htmlspecialchars($perfil['nombres']) ?>" class="professional-avatar">
                    <?php else : ?>
                        <div class="professional-avatar-default"><i class="bi bi-person-fill"></i></div>
                    <?php endif; ?>

                    <h5 class="professional-name"><?= htmlspecialchars($perfil['nombres'] . ' ' . $perfil['apellidos']) ?></h5>
                    <p class="professional-title"><?= htmlspecialchars($perfil['titulo_profesional'] ?: 'Perfil no completado') ?></p>

                    <?php if ($perfil['empresa_actual']) : ?>
                        <span class="status-badge contratado">
                            <i class="bi bi-briefcase-fill me-1"></i> Contratado por <?= htmlspecialchars($perfil['empresa_actual']) ?>
                        </span>
                    <?php else : ?>
                        <span class="status-badge disponible">
                            <i class="bi bi-check-circle-fill me-1"></i> Disponible para Contratación
                        </span>
                    <?php endif; ?>

                    <div class="card-footer-actions">
                        <?php if ($perfil['id_hv']) : ?>
                            <a href="ver_hv_publico.php?id_usuario=<?= $perfil['usuario_id'] ?>" class="btn btn-outline-custom w-100">
                                <i class="bi bi-person-vcard me-2"></i>Ver Perfil Completo
                            </a>
                        <?php else : ?>
                            <button class="btn btn-outline-secondary w-100" disabled>Perfil Incompleto</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>

        <?php if (empty($profesionales)) : ?>
            <div class="col-12">
                <div class="text-center p-5 border rounded" style="background-color: var(--surface-color);">
                    <i class="bi bi-people-fill display-1 text-muted mb-3"></i>
                    <p class="lead">No se encontraron profesionales que coincidan con tus criterios de búsqueda.</p>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Paginación -->
    <?php if ($total_pages > 1): ?>
        <nav aria-label="Paginación de profesionales">
            <ul class="pagination justify-content-center">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>&q=<?= urlencode($search_query) ?>&status=<?= urlencode($status_filter) ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    <?php endif; ?>
</main>

<?php include 'includes/footer.php'; ?>