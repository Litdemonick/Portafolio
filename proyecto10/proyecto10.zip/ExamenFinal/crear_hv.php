<?php
session_start();
require_once "conexion_dbs.php";

// 1. Proteger la página: si no hay sesión, redirigir al login
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$mensaje = '';
$mensaje_tipo = 'info';

// --- CORRECCIÓN DE SEGURIDAD IMPORTANTE ---
// Verificar que el usuario de la sesión REALMENTE exista en la tabla 'usuarios' local
// Esto evita el error de "Foreign Key Constraint Fails"
$sql_verify_user = "SELECT id FROM usuarios WHERE id = '$usuario_id' LIMIT 1";
$check_user = $conexion_local->query($sql_verify_user);

if (!$check_user || $check_user->num_rows === 0) {
    // Si el usuario tiene sesión pero no existe en la BD, destruimos la sesión y lo mandamos al login
    session_destroy();
    header('Location: login.php?error=usuario_no_encontrado');
    exit();
}
// -------------------------------------------

// 2. VERIFICAR SI LA HV YA EXISTE
$sql_check = "SELECT * FROM hvs WHERE usuario_id = '$usuario_id' LIMIT 1";
$resultado = $conexion_local->query($sql_check);
$hv_existente = ($resultado && $resultado->num_rows > 0) ? $resultado->fetch_assoc() : null;

// Si la HV ya existe, no debería estar en esta página. Redirigir a la página de edición.
if ($hv_existente !== null && $_SERVER["REQUEST_METHOD"] !== "POST") {
    header('Location: mi_hv.php');
    exit();
}

// 3. PROCESAR EL FORMULARIO (SOLO SI SE ENVÍA POR POST)
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Recolectar y sanear datos del formulario
    $titulo_profesional = $conexion_local->real_escape_string($_POST['titulo_profesional'] ?? 'no especificado');
    $resumen_profesional = !empty($_POST['resumen_profesional']) ? $conexion_local->real_escape_string($_POST['resumen_profesional']) : 'no especificado';
    $experiencia_laboral = !empty($_POST['experiencia_laboral']) ? $conexion_local->real_escape_string($_POST['experiencia_laboral']) : 'no especificado';
    $educacion = !empty($_POST['educacion']) ? $conexion_local->real_escape_string($_POST['educacion']) : 'no especificado';
    $habilidades = !empty($_POST['habilidades']) ? $conexion_local->real_escape_string($_POST['habilidades']) : 'no especificado';
    $idiomas = !empty($_POST['idiomas']) ? $conexion_local->real_escape_string($_POST['idiomas']) : 'no especificado';
    $enlace_linkedin = !empty($_POST['enlace_linkedin']) ? $conexion_local->real_escape_string($_POST['enlace_linkedin']) : 'no especificado';
    $enlace_github = !empty($_POST['enlace_github']) ? $conexion_local->real_escape_string($_POST['enlace_github']) : 'no especificado';
    $enlace_portfolio = !empty($_POST['enlace_portfolio']) ? $conexion_local->real_escape_string($_POST['enlace_portfolio']) : 'no especificado';
    $estado = 'completado';

    // Campos adicionales iniciales
    $nacionalidad = 'no especificado';
    $genero = 'no especificado';
    $estado_civil = 'no especificado';

    if ($hv_existente === null) {
        // INSERTAR
        $sql = "INSERT INTO hvs (usuario_id, nacionalidad, genero, estado_civil, fecha_nacimiento, archivo_adjunto, titulo_profesional, resumen_profesional, experiencia_laboral, educacion, habilidades, idiomas, enlace_linkedin, enlace_github, enlace_portfolio, estado) 
                VALUES ('$usuario_id', '$nacionalidad', '$genero', '$estado_civil', 'no especificado', 'no especificado', '$titulo_profesional', '$resumen_profesional', '$experiencia_laboral', '$educacion', '$habilidades', '$idiomas', '$enlace_linkedin', '$enlace_github', '$enlace_portfolio', '$estado')";

        $local_success = false;
        try {
            if ($conexion_local->query($sql)) {
                $local_success = true;
            } else {
                throw new Exception($conexion_local->error);
            }
        } catch (Exception $e) {
            $mensaje = "❌ Error al guardar en la base de datos principal: " . $e->getMessage();
            $mensaje_tipo = 'danger';
        }

        if ($local_success) {
            // Intentar replicar si la función existe, sino ignorar para no romper flujo
            if (function_exists('replicar_consulta')) {
                replicar_consulta($sql); 
            }
            
            $_SESSION['mensaje_hv'] = "✅ ¡HV creada! Continúa llenando la info de tu HV.";
            $_SESSION['mensaje_hv_tipo'] = 'success';
            header('Location: mi_hv.php');
            exit();
        }

    } else {
        // Si ya existe
        $mensaje = "ℹ️ Ya tienes una Hoja de Vida creada. Estás siendo redirigido...";
        $mensaje_tipo = 'info';
        echo "<script>setTimeout(function(){ window.location.href = 'mi_hv.php'; }, 2000);</script>";
    }
}

include 'includes/header.php';
?>

<style>
    .wizard-container {
        display: flex;
        background-color: var(--surface-color);
        border-radius: 1rem;
        box-shadow: 0 8px 30px rgba(0,0,0,0.1);
        overflow: hidden;
        border: 1px solid var(--border-color);
    }
    .wizard-nav {
        background: linear-gradient(180deg, rgba(var(--primary-color-rgb), 0.15), rgba(var(--secondary-color-rgb), 0.15));
        padding: 2rem 1.5rem;
        min-width: 250px;
    }
    .wizard-nav-list {
        list-style: none;
        padding: 0;
        margin: 0;
        position: sticky;
        top: 100px;
    }
    .wizard-nav-item {
        padding: 1rem;
        margin-bottom: 0.5rem;
        border-radius: 0.5rem;
        color: var(--text-color-muted);
        transition: all 0.3s ease;
        border-left: 4px solid transparent;
        cursor: pointer; /* Agregado para UX */
    }
    .wizard-nav-item.active {
        background-color: rgba(var(--primary-color-rgb), 0.1);
        color: var(--primary-color);
        font-weight: 600;
        border-left: 4px solid var(--primary-color);
    }
    .wizard-nav-item i {
        margin-right: 1rem;
        font-size: 1.2rem;
    }
    .wizard-content {
        padding: 2rem 3rem;
        width: 100%;
    }
    .wizard-step {
        display: none;
        animation: slide-in 0.5s forwards;
    }
    .wizard-step.active {
        display: block;
    }
    @keyframes slide-in {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    .progress { display: none; }

    body[data-theme="dark"] .wizard-content .form-label {
        color: #FFFFFF !important;
    }
</style>

<main class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-11 col-xl-10">
            <div class="wizard-container">
                <div class="wizard-nav">
                    <ul class="wizard-nav-list">
                        <li class="wizard-nav-item active" data-step="1">
                            <i class="bi bi-person-vcard"></i><span>Principal</span>
                        </li>
                        <li class="wizard-nav-item" data-step="2">
                            <i class="bi bi-briefcase"></i><span>Experiencia</span>
                        </li>
                        <li class="wizard-nav-item" data-step="3">
                            <i class="bi bi-lightbulb"></i><span>Habilidades</span>
                        </li>
                        <li class="wizard-nav-item" data-step="4">
                            <i class="bi bi-link-45deg"></i><span>Online</span>
                        </li>
                    </ul>
                </div>

                <div class="wizard-content">
                    <h1 class="form-title text-center mb-2">Completa tu Hoja de Vida</h1>
                    <p class="form-subtitle text-center mb-4">Un perfil completo atrae más y mejores oportunidades.</p>
                    <p class="text-center text-muted fst-italic" style="font-size: 0.9rem;">
                        <i class="bi bi-info-circle me-1"></i>Esta es una sección para llenar tu información inicial. Podrás añadir más detalles después.
                    </p>

                    <?php if (!empty($mensaje)) : ?>
                        <div class="alert alert-<?= $mensaje_tipo ?> mt-3"><?= nl2br($mensaje) ?></div>
                    <?php endif; ?>

                    <form id="hv-wizard-form" method="POST">
                    <div id="step-1" class="wizard-step active">
                        <h3 class="form-section-title mb-3">Información Principal</h3>
                        <div class="mb-3">
                            <label for="titulo_profesional" class="form-label">Título Profesional*</label>
                            <input type="text" class="form-control" id="titulo_profesional" name="titulo_profesional" placeholder="Ej: Desarrollador Full-Stack, Diseñador UX/UI" value="" required maxlength="255">
                        </div>
                        <div class="mb-3">
                            <label for="resumen_profesional" class="form-label">Resumen Profesional*</label>
                            <textarea class="form-control" id="resumen_profesional" name="resumen_profesional" rows="5" placeholder="Describe brevemente tu perfil, tus objetivos y lo que te apasiona." required maxlength="2000"></textarea>
                        </div>
                    </div>

                    <div id="step-2" class="wizard-step">
                        <h3 class="form-section-title mb-3">Experiencia y Educación</h3>
                        <div class="mb-3">
                            <label for="experiencia_laboral" class="form-label">Experiencia Laboral*</label>
                            <textarea class="form-control" id="experiencia_laboral" name="experiencia_laboral" rows="6" placeholder="Detalla tus trabajos anteriores, roles y logros. Uno por línea." required maxlength="4000"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="educacion" class="form-label">Educación*</label>
                            <textarea class="form-control" id="educacion" name="educacion" rows="4" placeholder="Tus títulos, instituciones y fechas." required maxlength="4000"></textarea>
                        </div>
                    </div>

                    <div id="step-3" class="wizard-step">
                        <h3 class="form-section-title mb-3">Habilidades e Idiomas</h3>
                        <div class="mb-3">
                            <label for="habilidades" class="form-label">Habilidades Clave*</label>
                            <textarea class="form-control" id="habilidades" name="habilidades" rows="4" placeholder="PHP, JavaScript, Liderazgo, Scrum, Figma..." required maxlength="1000"></textarea>
                            <div class="form-text">Separa tus habilidades con comas.</div>
                        </div>
                        <div class="mb-3">
                            <label for="idiomas" class="form-label">Idiomas*</label>
                            <input type="text" class="form-control" id="idiomas" name="idiomas" placeholder="Ej: Español (Nativo), Inglés (Avanzado)" value="" required maxlength="255">
                        </div>
                    </div>

                    <div id="step-4" class="wizard-step">
                        <h3 class="form-section-title mb-3">Presencia Online</h3>
                        <div class="mb-3">
                            <label for="enlace_linkedin" class="form-label">Perfil de LinkedIn (Opcional)</label>
                            <input type="url" class="form-control" id="enlace_linkedin" name="enlace_linkedin" placeholder="https://linkedin.com/in/tu-usuario" value="" maxlength="255">
                        </div>
                        <div class="mb-3">
                            <label for="enlace_github" class="form-label">Perfil de GitHub (Opcional)</label>
                            <input type="url" class="form-control" id="enlace_github" name="enlace_github" placeholder="https://github.com/tu-usuario" value="" maxlength="255">
                        </div>
                        <div class="mb-3">
                            <label for="enlace_portfolio" class="form-label">Portfolio Personal (Opcional)</label>
                            <input type="url" class="form-control" id="enlace_portfolio" name="enlace_portfolio" placeholder="https://tu-sitio-web.com" value="" maxlength="255">
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-5">
                            <a href="dashboard.php" class="btn btn-outline-secondary">Hacerlo más tarde</a>
                            <div>
                                <button type="button" id="prevBtn" class="btn btn-outline-custom" style="display: none;">Anterior</button>
                                <button type="button" id="nextBtn" class="btn btn-gradient">Siguiente</button>
                                <button type="submit" id="submitBtn" class="btn btn-gradient" style="display: none;">Guardar HV</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', () => {
    let currentStep = 1;
    const totalSteps = 4;
    const form = document.getElementById('hv-wizard-form');
    const nextBtn = document.getElementById('nextBtn');
    const prevBtn = document.getElementById('prevBtn');
    const submitBtn = document.getElementById('submitBtn');
    const navItems = document.querySelectorAll('.wizard-nav-item');

    const showStep = (step) => {
        // Ocultar todos los pasos
        document.querySelectorAll('.wizard-step').forEach(el => el.classList.remove('active'));
        // Mostrar el paso actual
        document.getElementById(`step-${step}`).classList.add('active');

        // Actualizar navegador lateral
        navItems.forEach(item => {
            item.classList.remove('active');
            if (parseInt(item.dataset.step) === step) item.classList.add('active');
        });
        // Actualizar visibilidad de botones
        prevBtn.style.display = step === 1 ? 'none' : 'inline-block';
        nextBtn.style.display = step === totalSteps ? 'none' : 'inline-block';
        submitBtn.style.display = step === totalSteps ? 'inline-block' : 'none';
    };

    nextBtn.addEventListener('click', () => {
        if (currentStep < totalSteps) {
            // Validación simple
            const currentStepFields = document.querySelectorAll(`#step-${currentStep} [required]`);
            let isValid = true;
            currentStepFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('is-invalid');
                    // Añadir listener para quitar invalidez al escribir
                    field.addEventListener('input', function() {
                        if(this.value.trim()) this.classList.remove('is-invalid');
                    }, {once: true});
                } else {
                    field.classList.remove('is-invalid');
                }
            });

            if (isValid) {
                currentStep++;
                showStep(currentStep);
            }
        }
    });

    prevBtn.addEventListener('click', () => {
        if (currentStep > 1) {
            currentStep--;
            showStep(currentStep);
        }
    });

    // Permitir clic en la navegación lateral si el paso anterior es válido (opcional)
    /* navItems.forEach(item => {
        item.addEventListener('click', () => {
            const step = parseInt(item.dataset.step);
            // Solo permitir ir hacia atrás o al paso inmediato si el actual es válido
            if(step < currentStep) {
                currentStep = step;
                showStep(currentStep);
            }
        });
    }); 
    */

    // Mostrar el primer paso al cargar
    showStep(currentStep);
});
</script>

<?php include 'includes/footer.php'; ?>