<?php
session_start();
require_once "conexion_dbs.php";

// Proteger la página: solo para empresas logueadas
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] !== 'empresa') {
    header("Location: login.php");
    exit();
}

$mensaje = '';
$id_empresa = $_SESSION['usuario_id'];

// Obtener la industria de la empresa para pre-rellenar el campo
$stmt_empresa = $conexion_local->prepare("SELECT industria FROM empresas WHERE usuario_id = ?");
$stmt_empresa->bind_param("i", $id_empresa);
$stmt_empresa->execute();
$resultado_empresa = $stmt_empresa->get_result();
$empresa = $resultado_empresa->fetch_assoc();
$industria_empresa = $empresa['industria'] ?? 'No especificada';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // 1. Validaciones básicas
    if (empty($_POST['titulo']) || empty($_POST['descripcion']) || empty($_POST['ubicacion']) || empty($_POST['modalidad'])) {
        $mensaje = "❌ Los campos Título, Descripción, Ubicación y Modalidad son obligatorios.";
    } elseif (isset($_POST['puestos_disponibles']) && intval($_POST['puestos_disponibles']) > 1500) {
        // --- NUEVA VALIDACIÓN: Límite de puestos disponibles ---
        $mensaje = "❌ El número de puestos disponibles no puede ser mayor a 1500.";
    } else {
        // 2. Recolección y saneamiento de datos
        $titulo_post = $_POST['titulo'];

        // --- NUEVA VALIDACIÓN: Comprobar si ya existe una vacante con el mismo título para esta empresa ---
        $stmt_check_titulo = $conexion_local->prepare("SELECT id FROM vacantes WHERE titulo = ? AND id_empresa = ?");
        $stmt_check_titulo->bind_param("si", $titulo_post, $id_empresa);
        $stmt_check_titulo->execute();
        $resultado_check = $stmt_check_titulo->get_result();

        if ($resultado_check->num_rows > 0) {
            $mensaje = "❌ Ya tienes una vacante publicada con el título '" . htmlspecialchars($titulo_post) . "'. Por favor, elige un título diferente.";
        } else {
            // Si no hay duplicados, proceder con la inserción
            $titulo = $conexion_local->real_escape_string($titulo_post);
            $descripcion = $conexion_local->real_escape_string($_POST['descripcion']);
            $ubicacion = $conexion_local->real_escape_string($_POST['ubicacion']);
            $modalidad = $conexion_local->real_escape_string($_POST['modalidad']);
            $industria = $conexion_local->real_escape_string($industria_empresa);
            $slogan = $conexion_local->real_escape_string($_POST['slogan_puesto']);
            $puestos_disponibles = intval($_POST['puestos_disponibles']) > 0 ? intval($_POST['puestos_disponibles']) : 1;
            $fecha = date("Y-m-d H:i:s");

            // 3. Construir y replicar la consulta SQL
            $sql = "INSERT INTO vacantes (id_empresa, titulo, descripcion, ubicacion, modalidad, industria, slogan_puesto, puestos_disponibles, fecha_publicacion)
                    VALUES ('$id_empresa', '$titulo', '$descripcion', '$ubicacion', '$modalidad', '$industria', '$slogan', '$puestos_disponibles', '$fecha')";

            // --- CORRECCIÓN: Ejecutar primero en la base de datos local (Windows) ---
            $local_success = false;
            try {
                if ($conexion_local->query($sql)) {
                    $local_success = true;
                } else {
                    throw new Exception($conexion_local->error);
                }
            } catch (Exception $e) {
                $mensaje = "❌ Error al guardar en la base de datos principal: " . $e->getMessage();
            }

            // Si la inserción local fue exitosa, replicar en la remota
            if ($local_success) {
                replicar_consulta($sql); // Esta función ya maneja la BD remota

                $_SESSION['mensaje_vacantes'] = "✅ ¡Vacante '$titulo' publicada con éxito!";
                header("Location: ver_vacantes.php");
                exit();
            } else {
                // Si la inserción local falló, el mensaje de error ya se estableció en el bloque catch.
            }
        }
        $stmt_check_titulo->close();
    }
}

include 'includes/header.php';
?>

<main class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="form-container">
                <h1 class="form-title text-center">Publicar una Nueva Vacante</h1>
                <p class="form-subtitle text-center">Completa los detalles de la oportunidad laboral.</p>

                <?php if (!empty($mensaje)) : ?>
                    <div class="alert <?= str_contains($mensaje, '❌') ? 'alert-danger' : 'alert-success' ?> mt-3"><?= htmlspecialchars($mensaje) ?></div>
                <?php endif; ?>

                <form method="POST" action="abrir_vacante.php" class="mt-4">
                    <div class="mb-3">
                        <label for="titulo" class="form-label">Título del Puesto*</label>
                        <input type="text" class="form-control" id="titulo" name="titulo" required maxlength="100">
                    </div>

                    <div class="mb-3">
                        <label for="descripcion" class="form-label">Descripción del Puesto*</label>
                        <textarea class="form-control" id="descripcion" name="descripcion" rows="6" required maxlength="4000"></textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="ubicacion" class="form-label">Ubicación*</label>
                            <input type="text" class="form-control" id="ubicacion" name="ubicacion" placeholder="Ej: Ciudad, País o 'Remoto'" required maxlength="100">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="modalidad" class="form-label">Modalidad de Trabajo*</label>
                            <select class="form-select" id="modalidad" name="modalidad" required>
                                <option value="" disabled selected>Seleccione...</option>
                                <option value="Presencial">Presencial</option>
                                <option value="Remoto">Remoto</option>
                                <option value="Híbrido">Híbrido</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="puestos_disponibles" class="form-label">Puestos Disponibles*</label>
                        <input type="number" class="form-control" id="puestos_disponibles" name="puestos_disponibles" value="1" min="1" max="1500" required>
                    </div>

                    <div class="mb-3">
                        <label for="industria" class="form-label">Industria</label>
                        <input type="text" class="form-control" id="industria" name="industria" value="<?= htmlspecialchars($industria_empresa) ?>" disabled readonly>
                        <div class="form-text">Este campo se toma del perfil de tu empresa.</div>
                    </div>

                    <div class="mb-3">
                        <label for="slogan_puesto" class="form-label">Slogan o Mensaje Motivacional (Opcional)</label>
                        <textarea class="form-control" id="slogan_puesto" name="slogan_puesto" rows="4" placeholder="Ej: En nuestra empresa, creemos en el poder de la colaboración... ¡Únete a nuestro equipo!" maxlength="1000"></textarea>
                    </div>

                    <button type="submit" class="btn btn-gradient w-100 btn-lg mt-3">Publicar Vacante</button>
                </form>
            </div>
        </div>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const puestosInput = document.getElementById('puestos_disponibles');

    if (puestosInput) {
        puestosInput.addEventListener('input', function() {
            const max = parseInt(this.getAttribute('max'), 10);
            let value = parseInt(this.value, 10);

            if (!isNaN(value) && value > max) {
                this.value = max;
            }
        });
    }
});
</script>

<?php include 'includes/footer.php'; ?>