<?php
session_start();
require_once "conexion_dbs.php";

// Proteger la página: si no hay sesión, redirigir al login
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$usuario_rol = $_SESSION['usuario_rol'];
$usuario_nombre = $_SESSION['usuario_nombre'];

// --- LÓGICA PARA OBTENER ESTADÍSTICAS SEGÚN EL ROL ---
$stats = [];
$quick_actions = [];
$recent_activity = [];

if ($usuario_rol === 'empresa') {
    // Estadísticas para la empresa
    $stmt_vacantes = $conexion_local->prepare("SELECT COUNT(*) as total FROM vacantes WHERE id_empresa = ? AND estado = 'activa'");
    $stmt_vacantes->bind_param("i", $usuario_id);
    $stmt_vacantes->execute();
    $stats['vacantes_activas'] = $stmt_vacantes->get_result()->fetch_assoc()['total'] ?? 0;

    $stmt_postulaciones = $conexion_local->prepare("SELECT COUNT(p.id) as total FROM postulaciones p JOIN vacantes v ON p.id_vacante = v.id WHERE v.id_empresa = ? AND p.estado = 'recibido'");
    $stmt_postulaciones->bind_param("i", $usuario_id);
    $stmt_postulaciones->execute();
    $stats['postulaciones_pendientes'] = $stmt_postulaciones->get_result()->fetch_assoc()['total'] ?? 0;

    // Actividad reciente: últimas postulaciones
    $sql_recent = "SELECT p.id, u.nombres, u.apellidos, v.titulo FROM postulaciones p JOIN usuarios u ON p.id_usuario = u.id JOIN vacantes v ON p.id_vacante = v.id WHERE v.id_empresa = ? ORDER BY p.fecha_postulacion DESC LIMIT 3";
    $stmt_recent = $conexion_local->prepare($sql_recent);
    $stmt_recent->bind_param("i", $usuario_id);
    $stmt_recent->execute();
    $recent_activity = $stmt_recent->get_result()->fetch_all(MYSQLI_ASSOC);

    // Acciones rápidas para la empresa
    $quick_actions = [
        ['url' => 'abrir_vacante.php', 'icon' => 'bi-plus-circle-fill', 'text' => 'Publicar Vacante'],
        ['url' => 'revision_postulacion.php', 'icon' => 'bi-people-fill', 'text' => 'Revisar Postulaciones'],
        ['url' => 'facturacion.php', 'icon' => 'bi-receipt-cutoff', 'text' => 'Facturación']
    ];

} elseif ($usuario_rol === 'publico') {
    // Estadísticas para el candidato
    $stmt_postulaciones = $conexion_local->prepare("SELECT estado, COUNT(*) as total FROM postulaciones WHERE id_usuario = ? GROUP BY estado");
    $stmt_postulaciones->bind_param("i", $usuario_id);
    $stmt_postulaciones->execute();
    $res_postulaciones = $stmt_postulaciones->get_result()->fetch_all(MYSQLI_ASSOC);
    
    $stats['total_postulaciones'] = 0;
    $stats['aceptadas'] = 0;
    $stats['recibidas'] = 0;
    foreach ($res_postulaciones as $row) {
        $stats['total_postulaciones'] += $row['total'];
        if ($row['estado'] === 'aceptado') $stats['aceptadas'] = $row['total'];
        if ($row['estado'] === 'recibido') $stats['recibidas'] = $row['total'];
    }

    // Acciones rápidas para el candidato
    $quick_actions = [
        ['url' => 'buscar.php', 'icon' => 'bi-search', 'text' => 'Buscar Empleos'],
        ['url' => 'mi_hv.php', 'icon' => 'bi-person-vcard-fill', 'text' => 'Mi Hoja de Vida'],
        ['url' => 'mis_postulaciones.php', 'icon' => 'bi-send-check-fill', 'text' => 'Mis Postulaciones']
    ];
}

include 'includes/header.php';
?>

<style>
    .stat-card {
        background-color: var(--surface-color);
        border: 1px solid var(--border-color);
        border-radius: 1rem;
        padding: 1.5rem;
        transition: all 0.3s ease;
        text-align: center;
    }
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        border-color: var(--primary-color);
    }
    .stat-card .icon {
        font-size: 3rem;
        background: -webkit-linear-gradient(45deg, var(--primary-color), var(--secondary-color));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 1rem;
    }
    .stat-card .stat-number {
        font-size: 2.5rem;
        font-weight: 700;
        color: var(--text-color);
    }
    .stat-card .stat-label {
        font-size: 1rem;
        color: var(--text-color-muted);
    }
    .quick-action-card {
        background-color: var(--surface-color);
        border: 1px solid var(--border-color);
        border-radius: 1rem;
        padding: 2rem;
    }
</style>

<main class="container py-5">
    <!-- Encabezado de Bienvenida -->
    <div class="row mb-5">
        <div class="col-12 text-center">
            <h1 class="display-5 fw-bold">Bienvenido, <?= htmlspecialchars(explode(' ', $usuario_nombre)[0]) ?>!</h1>
            <p class="lead text-muted">Aquí tienes un resumen de tu actividad en Jobs360.</p>
            <p class="small text-muted">ID de Usuario: <?= $usuario_id ?> | Rol: <?= ucfirst($usuario_rol) ?></p>
        </div>
    </div>

    <!-- Tarjetas de Estadísticas -->
    <div class="row g-4 mb-5">
        <?php if ($usuario_rol === 'empresa'): ?>
            <div class="col-md-6 col-lg-4">
                <div class="stat-card">
                    <div class="icon"><i class="bi bi-briefcase-fill"></i></div>
                    <div class="stat-number"><?= $stats['vacantes_activas'] ?></div>
                    <div class="stat-label">Vacantes Activas</div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="stat-card">
                    <div class="icon"><i class="bi bi-person-plus-fill"></i></div>
                    <div class="stat-number"><?= $stats['postulaciones_pendientes'] ?></div>
                    <div class="stat-label">Nuevos Candidatos</div>
                </div>
            </div>
        <?php elseif ($usuario_rol === 'publico'): ?>
            <div class="col-md-6 col-lg-4">
                <div class="stat-card">
                    <div class="icon"><i class="bi bi-send-fill"></i></div>
                    <div class="stat-number"><?= $stats['total_postulaciones'] ?></div>
                    <div class="stat-label">Postulaciones Totales</div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="stat-card">
                    <div class="icon"><i class="bi bi-check-circle-fill"></i></div>
                    <div class="stat-number"><?= $stats['aceptadas'] ?></div>
                    <div class="stat-label">Procesos Activos</div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Acciones Rápidas y Actividad Reciente -->
    <div class="row g-5">
        <div class="col-lg-4">
            <div class="quick-action-card">
                <h4 class="mb-4">Acciones Rápidas</h4>
                <div class="d-grid gap-3">
                    <?php foreach ($quick_actions as $action): ?>
                        <a href="<?= $action['url'] ?>" class="btn btn-outline-custom btn-lg text-start">
                            <i class="<?= $action['icon'] ?> me-3"></i><?= $action['text'] ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <?php if ($usuario_rol === 'empresa' && !empty($recent_activity)): ?>
            <div class="col-lg-8">
                <div class="quick-action-card">
                    <h4 class="mb-4">Actividad Reciente</h4>
                    <ul class="list-group list-group-flush">
                        <?php foreach ($recent_activity as $activity): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center" style="background: none; border-color: var(--border-color);">
                                <div>
                                    <strong><?= htmlspecialchars($activity['nombres'] . ' ' . $activity['apellidos']) ?></strong>
                                    <small class="d-block text-muted">se postuló a: <?= htmlspecialchars($activity['titulo']) ?></small>
                                </div>
                                <a href="ver_candidato.php?id_postulacion=<?= $activity['id'] ?>" class="btn btn-sm btn-gradient">Ver</a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        <?php endif; ?>
    </div>
</main>

<?php include 'includes/footer.php'; ?>