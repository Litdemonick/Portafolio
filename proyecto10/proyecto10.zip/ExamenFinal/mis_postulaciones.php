<?php
session_start();
require_once "conexion_dbs.php";

// Proteger la página: solo para candidatos logueados
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] !== 'publico') {
    header("Location: login.php");
    exit();
}

$usuario_id = $_SESSION['usuario_id'];

// --- OBTENER TODAS LAS POSTULACIONES DEL USUARIO ---
$sql_postulaciones = "
    SELECT 
        p.id as id_postulacion,
        p.fecha_postulacion,
        p.estado,
        p.fecha_decision,
        v.id as id_vacante,
        v.titulo as titulo_vacante,
        e.nombre_empresa,
        u_emp.foto_perfil as foto_empresa
    FROM postulaciones p
    JOIN vacantes v ON p.id_vacante = v.id
    JOIN empresas e ON v.id_empresa = e.usuario_id
    JOIN usuarios u_emp ON e.usuario_id = u_emp.id
    WHERE p.id_usuario = ?
    ORDER BY p.fecha_postulacion DESC
";
$stmt = $conexion_local->prepare($sql_postulaciones);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$resultado = $stmt->get_result();
$postulaciones = $resultado->fetch_all(MYSQLI_ASSOC);

// Función para obtener la clase y el icono del badge según el estado
function get_status_badge($estado) {
    switch ($estado) {
        case 'aceptado':
            return ['class' => 'bg-success', 'icon' => 'bi-check-circle-fill', 'text' => 'Aceptado'];
        case 'rechazado':
            return ['class' => 'bg-danger', 'icon' => 'bi-x-circle-fill', 'text' => 'Rechazado'];
        case 'recibido':
        default:
            return ['class' => 'bg-info text-dark', 'icon' => 'bi-hourglass-split', 'text' => 'Recibido'];
    }
}

include 'includes/header.php';
?>

<style>
    .postulacion-card {
        background-color: var(--surface-color);
        border: 1px solid var(--border-color);
        border-radius: 0.75rem;
        transition: all 0.3s ease;
        overflow: hidden; /* Para que el borde izquierdo funcione bien */
        position: relative;
    }
    .postulacion-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        border-color: var(--primary-color);
    }
    .company-logo-small {
        width: 60px;
        height: 60px;
        object-fit: contain;
        border-radius: 0.5rem;
        background-color: #fff;
        padding: 5px;
    }
    .company-logo-default-small {
        width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;
        background-color: var(--surface-color-secondary); border-radius: 0.5rem; font-size: 2rem;
    }
    .status-badge {
        font-size: 0.9rem;
        padding: 0.5em 0.9em;
    }
</style>

<main class="container py-5">
    <h1 class="display-6 mb-4">Mis Postulaciones</h1>

    <?php if (empty($postulaciones)): ?>
        <div class="text-center p-5 border rounded" style="background-color: var(--surface-color);">
            <i class="bi bi-folder-x display-1 text-muted mb-3"></i>
            <h3 class="fw-light">Aún no te has postulado a ninguna vacante.</h3>
            <p class="lead text-muted">¡Explora las ofertas y encuentra tu próximo empleo!</p>
            <a href="buscar.php" class="btn btn-gradient mt-3">Buscar Vacantes</a>
        </div>
    <?php else: ?>
        <div class="row g-4">
            <?php foreach ($postulaciones as $postulacion): ?>
                <div class="col-md-6">
                    <a href="ver_vacante_detalle.php?id=<?= $postulacion['id_vacante'] ?>" class="text-decoration-none">
                        <div class="postulacion-card p-3 h-100">
                            <div class="d-flex align-items-center">
                                <div class="flex-grow-1">
                                    <p class="text-muted small mb-1">Postulado el: <?= date("d/m/Y", strtotime($postulacion['fecha_postulacion'])) ?></p>
                                    <h5 class="mb-1 text-primary"><?= htmlspecialchars($postulacion['titulo_vacante']) ?></h5>
                                    <p class="mb-2 text-muted"><?= htmlspecialchars($postulacion['nombre_empresa']) ?></p>
                                    <?php $status = get_status_badge($postulacion['estado']); ?>
                                    <span class="badge <?= $status['class'] ?> status-badge">
                                        <i class="bi <?= $status['icon'] ?> me-1"></i><?= $status['text'] ?>
                                    </span>
                                    <?php if ($postulacion['estado'] !== 'recibido' && !empty($postulacion['fecha_decision'])): ?>
                                        <p class="text-muted small mt-2 mb-0">Decisión tomada el: <?= date("d/m/Y", strtotime($postulacion['fecha_decision'])) ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>

<?php include 'includes/footer.php'; ?>