document.addEventListener("DOMContentLoaded", () => {
    const chatInput = document.querySelector(".chat-input textarea");
    const sendChatBtn = document.querySelector(".chat-input #send-btn");
    const chatbox = document.querySelector(".chatbox");
    const suggestionButtons = document.querySelectorAll(".suggested-questions button");

    let userMessage = null;
    const API_URL = "chatbot_backend.php";

    const createChatLi = (message, className) => {
        const chatLi = document.createElement("li");
        chatLi.classList.add("chat", `${className}`);
        let chatContent = className === "outgoing" ? `<p></p>` : `<span class="bi bi-robot"></span><p></p>`;
        chatLi.innerHTML = chatContent;
        chatLi.querySelector("p").textContent = message;
        return chatLi;
    }

    const generateResponse = (chatElement) => {
        const messageElement = chatElement.querySelector("p");

        fetch(API_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ pregunta: userMessage }),
        })
        .then(res => res.json())
        .then(data => {
            // Reemplazar saltos de línea con <br> y procesar enlaces Markdown
            let formattedResponse = data.respuesta.replace(/\n/g, '<br>');
            
            // Regex para encontrar enlaces estilo Markdown: Texto del enlace
            const markdownLinkRegex = /\[([^\]]+)\]\(([^)]+)\)/g;
            formattedResponse = formattedResponse.replace(markdownLinkRegex, '<a href="$2" class="btn btn-sm btn-gradient mt-2">$1</a>');

            messageElement.innerHTML = formattedResponse;
        })
        .catch(() => {
            messageElement.classList.add("error");
            messageElement.textContent = "Oops! Algo salió mal. Por favor, inténtalo de nuevo.";
        })
        .finally(() => chatbox.scrollTo(0, chatbox.scrollHeight));
    }

    const handleChat = (messageToSend) => {
        userMessage = messageToSend.trim();
        if (!userMessage) return;

        chatInput.value = "";
        chatInput.style.height = "auto";

        const outgoingChatLi = createChatLi(userMessage, "outgoing");
        chatbox.appendChild(outgoingChatLi);
        chatbox.scrollTo(0, chatbox.scrollHeight);

        setTimeout(() => {
            const incomingChatLi = createChatLi("Pensando...", "incoming");
            chatbox.appendChild(incomingChatLi);
            chatbox.scrollTo(0, chatbox.scrollHeight);
            generateResponse(incomingChatLi);
        }, 600);
    }

    // Evento para los botones de sugerencia
    suggestionButtons.forEach(button => {
        button.addEventListener("click", () => {
            const question = button.getAttribute("data-question");
            handleChat(question);
        });
    });

    // Ajustar altura del textarea
    chatInput.addEventListener("input", () => {
        chatInput.style.height = "auto";
        chatInput.style.height = `${chatInput.scrollHeight}px`;
    });

    // Enviar mensaje con Enter
    chatInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey && window.innerWidth > 800) {
            e.preventDefault();
            handleChat(chatInput.value);
        }
    });

    // Enviar mensaje con el botón de enviar
    sendChatBtn.addEventListener("click", () => handleChat(chatInput.value));
});