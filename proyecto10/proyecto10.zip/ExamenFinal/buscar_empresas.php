<?php
include 'includes/header.php';
require_once "conexion_dbs.php";

// --- 1. OBTENER EMPRESAS POPULARES (MEJOR CALIFICADAS CON VACANTES ACTIVAS) ---
$sql_populares = "
    SELECT
        u.id,
        e.nombre_empresa,
        u.foto_perfil,
        e.industria,
        c.avg_rating,
        c.rating_count,
        (SELECT COUNT(*) FROM vacantes WHERE id_empresa = u.id AND estado = 'activa') as num_vacantes
    FROM usuarios u
    JOIN empresas e ON u.id = e.usuario_id
    LEFT JOIN (
        SELECT id_empresa, AVG(calificacion) as avg_rating, COUNT(calificacion) as rating_count
        FROM calificaciones_empresas
        GROUP BY id_empresa
    ) c ON u.id = c.id_empresa
    WHERE u.rol = 'empresa' AND c.rating_count > 0
    ORDER BY avg_rating DESC, num_vacantes DESC
    LIMIT 3
";
$resultado_populares = $conexion_local->query($sql_populares);
$empresas_populares = $resultado_populares->fetch_all(MYSQLI_ASSOC);

// --- 2. CONTAR EMPRESAS CON EMPLEO ---
$sql_total_empresas = "
    SELECT COUNT(DISTINCT id_empresa) as total_empresas
    FROM vacantes v
    WHERE v.estado = 'activa'
";
$total_empresas_activas = $conexion_local->query($sql_total_empresas)->fetch_assoc();

// --- 3. LÓGICA DE BÚSQUEDA Y PAGINACIÓN PARA TODAS LAS EMPRESAS ---
$search_query = trim($_GET['q'] ?? '');
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$items_per_page = 6;
$offset = ($page - 1) * $items_per_page;

$params = [];
$types = "";

$sql_base = "
    FROM usuarios u
    JOIN empresas e ON u.id = e.usuario_id
    LEFT JOIN (
        SELECT id_empresa, AVG(calificacion) as avg_rating, COUNT(calificacion) as rating_count
        FROM calificaciones_empresas
        GROUP BY id_empresa
    ) c ON u.id = c.id_empresa
    WHERE u.rol = 'empresa'
";

if (!empty($search_query)) {
    $sql_base .= " AND e.nombre_empresa LIKE ?";
    $params[] = "%" . $search_query . "%";
    $types .= "s";
}

// Contar total de empresas para la paginación
$sql_count = "SELECT COUNT(DISTINCT u.id) as total " . $sql_base;
$stmt_count = $conexion_local->prepare($sql_count);
if (!empty($types)) {
    $stmt_count->bind_param($types, ...$params);
}
$stmt_count->execute();
$total_items = $stmt_count->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_items / $items_per_page);

// Obtener empresas para la página actual
$sql_select = "
    SELECT DISTINCT
        u.id,
        e.nombre_empresa,
        u.foto_perfil,
        e.industria,
        c.avg_rating,
        c.rating_count,
        (SELECT COUNT(*) FROM vacantes WHERE id_empresa = u.id AND estado = 'activa') as num_vacantes
" . $sql_base . " ORDER BY e.nombre_empresa ASC LIMIT ? OFFSET ?";

$params[] = $items_per_page;
$params[] = $offset;
$types .= "ii";

$stmt = $conexion_local->prepare($sql_select);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$resultado_empresas = $stmt->get_result();
$empresas = $resultado_empresas->fetch_all(MYSQLI_ASSOC);

// --- 4. SEPARAR EMPRESAS EN ACTIVAS E INACTIVAS ---
$empresas_activas = [];
$empresas_inactivas = [];
foreach ($empresas as $empresa) {
    if ($empresa['num_vacantes'] > 0) {
        $empresas_activas[] = $empresa;
    } else {
        $empresas_inactivas[] = $empresa;
    }
}

function render_stars($rating) {
    $rating = floatval($rating);
    $full_stars = floor($rating);
    $half_star = ($rating - $full_stars) >= 0.5;
    $empty_stars = 5 - $full_stars - ($half_star ? 1 : 0);
    $stars_html = '';

    for ($i = 0; $i < $full_stars; $i++) $stars_html .= '<i class="bi bi-star-fill text-warning"></i>';
    if ($half_star) $stars_html .= '<i class="bi bi-star-half text-warning"></i>';
    for ($i = 0; $i < $empty_stars; $i++) $stars_html .= '<i class="bi bi-star text-warning"></i>';
    
    return $stars_html;
}
?>

<style>
    .company-card {
        transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
        border: 1px solid var(--border-color);
    }
    .company-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.1);
    }
    .company-logo {
        width: 70px;
        height: 70px;
        object-fit: contain;
        border-radius: 0.5rem;
        background-color: #f8f9fa;
        padding: 5px;
        border: 1px solid var(--border-color);
    }
    .company-logo-default {
        width: 70px;
        height: 70px;
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: var(--surface-color-secondary);
        border-radius: 0.5rem;
        font-size: 2rem;
        color: var(--text-color-muted);
    }
</style>

<main class="container py-5">
    <!-- Sección de Empresas Populares -->
    <div class="row mb-5">
        <div class="col-12 text-center">
            <h2 class="display-6">Empresas Populares</h2>
            <p class="lead text-muted">Las compañías mejor valoradas por nuestra comunidad.</p>
        </div>
    </div>
    <div class="row g-4 justify-content-center mb-5">
        <?php if (empty($empresas_populares)): ?>
            <div class="col-12">
                <div class="alert alert-light text-center">
                    <p class="lead mb-0">Aún no hay empresas populares destacadas.</p>
                </div>
            </div>
        <?php else: ?>
            <?php foreach ($empresas_populares as $empresa): ?>
                <div class="col-md-6 col-lg-4">
                    <a href="ver_empresa_detalle.php?id=<?= $empresa['id'] ?>" class="text-decoration-none">
                        <div class="card h-100 company-card text-center">
                            <div class="card-body">
                                <?php
                                    $foto_empresa = (!empty($empresa['foto_perfil']) && $empresa['foto_perfil'] !== 'foto_default' && file_exists('uploads/avatars/' . $empresa['foto_perfil']))
                                        ? 'uploads/avatars/' . htmlspecialchars($empresa['foto_perfil'])
                                        : null;
                                ?>
                                <?php if ($foto_empresa): ?>
                                    <img src="<?= $foto_empresa ?>" alt="Logo <?= htmlspecialchars($empresa['nombre_empresa']) ?>" class="company-logo mx-auto mb-3">
                                <?php else: ?>
                                    <div class="company-logo-default mx-auto mb-3"><i class="bi bi-building"></i></div>
                                <?php endif; ?>
                                <h5 class="card-title text-body"><?= htmlspecialchars($empresa['nombre_empresa']) ?></h5>
                                <p class="card-text text-muted small"><?= htmlspecialchars($empresa['industria'] ?: 'Industria no especificada') ?></p>
                                <div class="mb-3 small">
                                    <?= render_stars($empresa['avg_rating']) ?>
                                    <span class="text-muted ms-1">(<?= number_format($empresa['avg_rating'] ?? 0, 1) ?>)</span>
                                </div>
                                <span class="badge bg-primary bg-opacity-10 text-primary-emphasis rounded-pill">
                                    <?= $empresa['num_vacantes'] ?> <?= ($empresa['num_vacantes'] == 1) ? 'vacante abierta' : 'vacantes abiertas' ?>
                                </span>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <hr class="my-5">

    <!-- Sección de Búsqueda y Estadísticas -->
    <div class="row align-items-center mb-4">
        <div class="col-12 text-center">
            <a href="buscar.php" class="text-decoration-none">
                <div class="p-3 rounded" style="background-color: var(--surface-color); border: 1px solid var(--border-color); transition: all 0.2s ease;">
                    <h3 class="fw-bold text-gradient mb-0"><?= htmlspecialchars($total_empresas_activas['total_empresas']) ?></h3>
                    <p class="text-muted mb-0">Empresas con vacantes activas ahora</p>
                </div>
            </a>
        </div>
    </div>

    <!-- Listado de Todas las Empresas -->
    <?php if (empty($empresas)): ?>
        <div class="col-12 text-center p-5 border rounded bg-light">
            <i class="bi bi-search-heart display-1 text-muted mb-3"></i>
            <p class="lead">No se encontraron empresas para tu búsqueda.</p>
            <a href="buscar_empresas.php" class="btn btn-sm btn-outline-secondary">Limpiar búsqueda</a>
        </div>
    <?php else: ?>
        <!-- Sección Empresas con Vacantes Activas -->
        <?php if (!empty($empresas_activas)): ?>
            <div class="col-12">
                <h3 class="mb-4">Empresas con Vacantes Activas</h3>
            </div>
            <div class="row g-4">
                <?php foreach ($empresas_activas as $empresa): ?>
                    <div class="col-md-6 col-lg-4 col-xl-3">
                        <a href="ver_empresa_detalle.php?id=<?= $empresa['id'] ?>" class="text-decoration-none">
                            <div class="card h-100 company-card text-center">
                                <div class="card-body d-flex flex-column">
                                    <?php $foto_empresa = (!empty($empresa['foto_perfil']) && $empresa['foto_perfil'] !== 'foto_default' && file_exists('uploads/avatars/' . $empresa['foto_perfil'])) ? 'uploads/avatars/' . htmlspecialchars($empresa['foto_perfil']) : null; ?>
                                    <?php if ($foto_empresa): ?>
                                        <img src="<?= $foto_empresa ?>" alt="Logo <?= htmlspecialchars($empresa['nombre_empresa']) ?>" class="company-logo mx-auto mb-3">
                                    <?php else: ?>
                                        <div class="company-logo-default mx-auto mb-3"><i class="bi bi-building"></i></div>
                                    <?php endif; ?>
                                    <h5 class="card-title flex-grow-1 text-body"><?= htmlspecialchars($empresa['nombre_empresa']) ?></h5>
                                    <p class="card-text text-muted small mb-3"><?= htmlspecialchars($empresa['industria'] ?: 'Industria no especificada') ?></p>
                                    <div class="mb-3 small">
                                        <?= render_stars($empresa['avg_rating']) ?>
                                        <span class="text-muted ms-1">(<?= number_format($empresa['avg_rating'] ?? 0, 1) ?>)</span>
                                    </div>
                                    <span class="badge bg-primary bg-opacity-10 text-primary-emphasis rounded-pill mt-auto">
                                        <?= $empresa['num_vacantes'] ?> <?= ($empresa['num_vacantes'] == 1) ? 'vacante abierta' : 'vacantes abiertas' ?>
                                    </span>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- Sección Otras Empresas -->
        <?php if (!empty($empresas_inactivas)): ?>
            <div class="col-12 mt-5">
                <h3 class="mb-4">Otras Empresas Registradas</h3>
            </div>
            <div class="row g-4">
                <?php foreach ($empresas_inactivas as $empresa): ?>
                    <div class="col-md-6 col-lg-4 col-xl-3">
                        <a href="ver_empresa_detalle.php?id=<?= $empresa['id'] ?>" class="text-decoration-none">
                            <div class="card h-100 company-card text-center">
                                <div class="card-body d-flex flex-column">
                                    <?php $foto_empresa = (!empty($empresa['foto_perfil']) && $empresa['foto_perfil'] !== 'foto_default' && file_exists('uploads/avatars/' . $empresa['foto_perfil'])) ? 'uploads/avatars/' . htmlspecialchars($empresa['foto_perfil']) : null; ?>
                                    <?php if ($foto_empresa): ?>
                                        <img src="<?= $foto_empresa ?>" alt="Logo <?= htmlspecialchars($empresa['nombre_empresa']) ?>" class="company-logo mx-auto mb-3">
                                    <?php else: ?>
                                        <div class="company-logo-default mx-auto mb-3"><i class="bi bi-building"></i></div>
                                    <?php endif; ?>
                                    <h5 class="card-title flex-grow-1 text-body"><?= htmlspecialchars($empresa['nombre_empresa']) ?></h5>
                                    <p class="card-text text-muted small mb-3"><?= htmlspecialchars($empresa['industria'] ?: 'Industria no especificada') ?></p>
                                    <div class="mb-3 small">
                                        <?= render_stars($empresa['avg_rating']) ?>
                                        <span class="text-muted ms-1">(<?= number_format($empresa['avg_rating'] ?? 0, 1) ?>)</span>
                                    </div>
                                    <span class="badge bg-secondary bg-opacity-10 text-secondary-emphasis rounded-pill mt-auto">
                                        Sin vacantes activas
                                    </span>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <!-- Paginación -->
    <?php if ($total_pages > 1): ?>
        <nav aria-label="Paginación de empresas" class="mt-5">
            <ul class="pagination justify-content-center">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>&q=<?= urlencode($search_query) ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    <?php endif; ?>
</main>

<?php include 'includes/footer.php'; ?>