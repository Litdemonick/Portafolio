<?php
session_start();
require_once "conexion_dbs.php";

// --- SEGURIDAD ---
// Proteger la página: solo para usuarios logueados (idealmente, un admin)
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}
// Opcional: Restringir solo a un rol de administrador
// if ($_SESSION['usuario_rol'] !== 'admin') { die("Acceso denegado."); }

include 'includes/header.php';

function sincronizar_tabla($tabla, $pk_columna, $conexion_local, $conexion_remota) {
    echo "<h4>Sincronizando tabla: <code>$tabla</code></h4>";
    
    // 1. Obtener todos los registros de la base de datos de origen (Windows)
    $resultado_local = $conexion_local->query("SELECT * FROM `$tabla`");
    if (!$resultado_local) {
        echo "<p class='text-danger'>Error al leer de la tabla local '$tabla': " . $conexion_local->error . "</p>";
        return;
    }
    $registros_locales = $resultado_local->fetch_all(MYSQLI_ASSOC);
    $total_registros = count($registros_locales);
    echo "<p>Se encontraron $total_registros registros en el origen.</p>";

    if ($total_registros === 0) {
        echo "<p class='text-success'>No hay registros que sincronizar. ¡Completado!</p><hr>";
        return;
    }

    $actualizados = 0;
    $insertados = 0;
    $errores = 0;

    // 2. Preparar la consulta de "UPSERT" (INSERT ... ON DUPLICATE KEY UPDATE)
    $columnas = array_keys($registros_locales[0]);
    $columnas_sql = implode(', ', array_map(fn($c) => "`$c`", $columnas));
    $placeholders = implode(', ', array_fill(0, count($columnas), '?'));
    
    $update_parts = [];
    foreach ($columnas as $col) {
        if ($col !== $pk_columna) { // No actualizamos la clave primaria
            $update_parts[] = "`$col` = VALUES(`$col`)";
        }
    }
    $update_sql = implode(', ', $update_parts);

    $sql_upsert = "INSERT INTO `$tabla` ($columnas_sql) VALUES ($placeholders) ON DUPLICATE KEY UPDATE $update_sql";

    $stmt_remoto = $conexion_remota->prepare($sql_upsert);
    if (!$stmt_remoto) {
        echo "<p class='text-danger'>Error fatal al preparar la consulta para la tabla '$tabla': " . $conexion_remota->error . "</p>";
        return;
    }

    // 3. Iterar y ejecutar la consulta para cada registro
    foreach ($registros_locales as $registro) {
        $valores = array_values($registro);
        $tipos = str_repeat('s', count($valores)); // Tratar todos como string para simplicidad y robustez

        $stmt_remoto->bind_param($tipos, ...$valores);
        
        if ($stmt_remoto->execute()) {
            // affected_rows devuelve:
            // 1 si se insertó una nueva fila
            // 2 si se actualizó una fila existente
            // 0 si no se hizo nada (la fila ya era idéntica)
            if ($stmt_remoto->affected_rows === 1) {
                $insertados++;
            } elseif ($stmt_remoto->affected_rows === 2) {
                $actualizados++;
            }
        } else {
            echo "<p class='text-danger'>Error al sincronizar registro con $pk_columna " . $registro[$pk_columna] . ": " . $stmt_remoto->error . "</p>";
            $errores++;
        }
    }

    echo "<p class='text-success'>Sincronización completada para la tabla <code>$tabla</code>.</p>";
    echo "<ul>";
    echo "<li><strong>Registros insertados:</strong> $insertados</li>";
    echo "<li><strong>Registros actualizados:</strong> $actualizados</li>";
    echo "<li><strong>Errores:</strong> $errores</li>";
    echo "</ul><hr>";

    $stmt_remoto->close();
}
?>

<style>
    .sync-container {
        max-width: 800px;
        margin: auto;
    }
    .sync-log {
        background-color: var(--surface-color);
        border: 1px solid var(--border-color);
        border-radius: 0.5rem;
        padding: 1.5rem;
        margin-top: 2rem;
        max-height: 500px;
        overflow-y: auto;
        font-family: monospace;
        font-size: 0.9rem;
    }
</style>

<main class="container py-5">
    <div class="sync-container text-center">
        <h1 class="display-6">Sincronización de Bases de Datos</h1>
        <p class="lead text-muted">Esta herramienta forzará la sincronización de los datos desde la base de datos principal (Windows) a la de respaldo (Ubuntu).</p>
        <form method="POST">
            <button type="submit" name="iniciar_sincronizacion" class="btn btn-gradient btn-lg">
                <i class="bi bi-arrow-repeat me-2"></i>Iniciar Sincronización
            </button>
        </form>
    </div>

    <?php if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['iniciar_sincronizacion'])): ?>
        <div class="sync-log">
            <?php
            // Desactivar el límite de tiempo de ejecución para scripts largos
            set_time_limit(300); // 5 minutos

            // Definir las tablas a sincronizar y su clave primaria
            $tablas_a_sincronizar = [
                'usuarios' => 'id',
                'empresas' => 'id',
                'hvs' => 'id',
                'vacantes' => 'id',
                'postulaciones' => 'id',
                'calificaciones_empresas' => 'id'
            ];

            echo "<h3>Iniciando proceso de sincronización...</h3><hr>";

            foreach ($tablas_a_sincronizar as $nombre_tabla => $pk) {
                sincronizar_tabla($nombre_tabla, $pk, $conexion_local, $conexion_remota);
                ob_flush(); // Enviar salida al navegador
                flush();    // Forzar el envío
            }

            echo "<h3>¡Proceso de sincronización finalizado!</h3>";
            ?>
        </div>
    <?php endif; ?>
</main>

<?php include 'includes/footer.php'; ?>
```

### ¿Cómo Funciona?

1.  **Acceso:** Entra a `sincronizacion.php` desde tu navegador. Verás un botón para iniciar el proceso.
2.  **Ejecución:** Al hacer clic, el script:
   *   Define una lista de todas las tablas importantes (`usuarios`, `empresas`, `hvs`, etc.).
   *   Para cada tabla, lee **todos** los registros de tu base de datos de Windows.
   *   Luego, para cada registro, ejecuta una consulta `INSERT ... ON DUPLICATE KEY UPDATE` en la base de datos de Ubuntu. Este comando es muy eficiente:
       *   Si el registro (basado en su `id`) no existe en Ubuntu, lo **crea**.
       *   Si el registro ya existe, lo **actualiza** con los datos de Windows.
3.  **Feedback en Tiempo Real:** Verás en pantalla un log que te informa qué tabla se está sincronizando, cuántos registros se encontraron, y al final, cuántos se insertaron, actualizaron o dieron error.

Con esta herramienta, tienes una forma segura y fiable de forzar la consistencia de tus datos en cualquier momento, resolviendo cualquier problema de replicación que haya ocurrido en el pasado.
