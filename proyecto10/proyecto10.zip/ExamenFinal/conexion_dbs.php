<?php
// ========================================
// ARCHIVO: conexion_dbs.php
// Descripción: Conexiones MySQL principal + réplica Windows
// CORREGIDO: Función replicar_consulta ya no duplica en local
// ========================================


// ------------------------------------------------------
// 1) CONEXIÓN MYSQL PRINCIPAL (WINDOWS)
// ------------------------------------------------------
$host_local = "localhost";
$user_local = "root";
$pass_local = "";
$db_local   = "Jobs360_Windows";
$port_local = 3307;

$conexion_local = new mysqli($host_local, $user_local, $pass_local, $db_local, $port_local);

if ($conexion_local->connect_error) {
    die("❌ Error MySQL principal: " . $conexion_local->connect_error);
}


// ------------------------------------------------------
// 2) CONEXIÓN MYSQL RÉPLICA (UBUNTU)
// ------------------------------------------------------
// Asegúrate que esta IP sea accesible desde Windows
$host_remoto = "10.197.55.56"; 
$user_remoto = "root";
$pass_remoto = "";
$db_remoto   = "Jobs360_Ubuntu";
$port_remoto = 3306;

// Configuramos un timeout bajo por si la red falla, no cuelgue la web
$conexion_remota = new mysqli();
$conexion_remota->options(MYSQLI_OPT_CONNECT_TIMEOUT, 2); 

try {
    @$conexion_remota->connect($host_remoto, $user_remoto, $pass_remoto, $db_remoto, $port_remoto);
} catch (Exception $e) {
    error_log("⚠️ Advertencia: No se pudo conectar a la réplica Ubuntu: " . $e->getMessage());
}


// ------------------------------------------------------
// 3) FUNCIÓN PARA REPLICAR CONSULTAS (CORREGIDA)
// ------------------------------------------------------
function replicar_consulta($sql_query, $types = null, $params = null)
{
    global $conexion_local, $conexion_remota;
    $resultado = ['success' => false, 'local_ok' => true, 'remote_ok' => false, 'local_error' => '', 'remote_error' => ''];
    $params_json = json_encode($params);
    
    // --- CORRECCIÓN CRÍTICA ---
    // Hemos DESACTIVADO la ejecución Local dentro de esta función.
    // ¿Por qué? Porque tú ya ejecutas el INSERT local manualmente en tus archivos (ver_vacante_detalle.php).
    // Si lo dejamos activado aquí, se inserta DOS VECES (Duplicidad).
    
    /* // BLOQUE COMENTADO PARA EVITAR DUPLICADOS:
    try {
        $stmt_local = $conexion_local->prepare($sql_query);
        if ($stmt_local->execute()) { $resultado['local_ok'] = true; } 
        $stmt_local->close();
    } catch (Exception $e) { ... }
    */

    // --- Ejecutar en la conexión REMOTA (Ubuntu) ---
    // Solo procedemos si tenemos conexión remota viva
    if ($conexion_remota && !$conexion_remota->connect_error) { 
        try {
            $is_update = stripos(trim($sql_query), 'UPDATE') === 0;
            
            $stmt_remoto = $conexion_remota->prepare($sql_query);
            if ($stmt_remoto === false) {
                throw new Exception("Error prepare remoto: " . $conexion_remota->error);
            }
            
            if ($types && $params) {
                $stmt_remoto->bind_param($types, ...$params);
            }
            
            if ($stmt_remoto->execute()) {
                $affected_rows = $stmt_remoto->affected_rows;
                $stmt_remoto->close();

                // Lógica de contingencia: Si es UPDATE pero no afectó nada (porque en Ubuntu no existía),
                // lo transformamos mágicamente en un INSERT.
                if ($is_update && $affected_rows === 0) {
                    // error_log("LOG REPLICACIÓN: UPDATE sin efecto en remoto. Intentando INSERT de contingencia.");
                    
                    // Regex para extraer tabla, SET y WHERE
                    preg_match('/UPDATE\s+`?(\w+)`?\s+SET\s+(.*?)\s+WHERE/is', $sql_query, $matches);
                    preg_match('/WHERE\s+(.*)/is', $sql_query, $where_matches);
                    
                    if (count($matches) === 3 && count($where_matches) === 2) {
                        $table = $matches[1];
                        $set_part = $matches[2];
                        $where_part = $where_matches[1];
                        
                        // Extraer columnas y preparar INSERT
                        preg_match_all('/`?(\w+)`?\s*=\s*\?/', $set_part, $set_cols);
                        preg_match_all('/`?(\w+)`?\s*=\s*\?/', $where_part, $where_cols);
                        $columns = array_merge($set_cols[1], $where_cols[1]);
                        $columns = array_map('trim', $columns);

                        $placeholders = rtrim(str_repeat('?,', count($columns)), ',');
                        $sql_insert = "INSERT INTO `$table` (" . implode(', ', array_map(fn($c) => "`$c`", $columns)) . ") VALUES ($placeholders)";
                        
                        $stmt_insert = $conexion_remota->prepare($sql_insert);
                        if ($stmt_insert) {
                            if ($types && $params) $stmt_insert->bind_param($types, ...$params);
                            $stmt_insert->execute();
                            $stmt_insert->close();
                        }
                    }
                }
                $resultado['remote_ok'] = true;
            } else {
                throw new Exception("Error execute remoto: " . $stmt_remoto->error);
            }
        } catch (Exception $e) {
            $resultado['remote_error'] = $e->getMessage();
            error_log("LOG REPLICACIÓN FALLO: " . $e->getMessage());
        }
    } else {
        $resultado['remote_error'] = "Sin conexión a Ubuntu";
    }

    $resultado['success'] = $resultado['remote_ok'];
    return $resultado;
}
?>