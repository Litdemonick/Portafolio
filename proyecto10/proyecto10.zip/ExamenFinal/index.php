<?php
include 'includes/header.php';
?>
<?php if (!isset($_SESSION['usuario_id'])) : ?>
    <?php // --- VISTA MEJORADA PARA USUARIOS NO LOGUEADOS --- ?>
    <main class="hero-section">
        <div class="container">
            <div class="hero-content">
                <h1 class="display-4 fw-bold">El Futuro del Trabajo <br> Comienza Aquí</h1>
                <p class="lead">
                    Conectamos talento excepcional con oportunidades innovadoras.
                    Tu próximo gran paso profesional está a solo un clic.
                </p>
                <a href="registro.php" class="btn btn-gradient btn-lg">Explorar Oportunidades</a>
            </div>
        </div>
    </main>

    <section class="container py-5 my-5">
        <div class="row text-center">
            <div class="col-12">
                <h2 class="display-6">¿Por qué Jobs360?</h2>
                <p class="lead text-muted">Todo lo que necesitas para tu carrera en un solo lugar.</p>
            </div>
        </div>
        <div class="row mt-5 g-4 align-items-center">
            <div class="col-md-4 text-center">
                <div class="feature-icon-box">
                    <i class="bi bi-search-heart display-4 text-gradient"></i>
                </div>
                <h4 class="fw-bold mt-3">Búsqueda Inteligente</h4>
                <p class="text-muted">Encuentra ofertas que se ajustan a tu perfil, habilidades y expectativas salariales.</p>
            </div>
            <div class="col-md-4 text-center">
                <div class="feature-icon-box">
                    <i class="bi bi-building-check display-4 text-gradient"></i>
                </div>
                <h4 class="fw-bold mt-3">Empresas Verificadas</h4>
                <p class="text-muted">Conéctate con las mejores empresas del sector, desde startups hasta grandes corporaciones.</p>
            </div>
            <div class="col-md-4 text-center">
                <div class="feature-icon-box">
                    <i class="bi bi-person-vcard display-4 text-gradient"></i>
                </div>
                <h4 class="fw-bold mt-3">Perfil Profesional</h4>
                <p class="text-muted">Crea una Hoja de Vida atractiva y destaca tus logros para que los reclutadores te encuentren.</p>
            </div>
        </div>
    </section>

<?php else: ?>
    <?php // --- VISTA PARA USUARIOS LOGUEADOS (CON CONTENIDO MEJORADO) --- ?>
    <?php
        require_once "conexion_dbs.php";
        // Obtener 3 vacantes activas aleatorias
        $sql_destacados = "
            SELECT 
                v.id, v.titulo, v.descripcion, v.ubicacion,
                u.nombres as nombre_empresa, u.foto_perfil
            FROM vacantes v
            JOIN usuarios u ON v.id_empresa = u.id
            WHERE v.estado = 'activa'
            ORDER BY RAND()
            LIMIT 3
        ";
        $resultado_destacados = $conexion_local->query($sql_destacados);
    ?>
    <main class="container py-5 flex-grow-1">
        <div class="row">
            <div class="col-12 text-center mb-5">
                <h2 class="display-6">Empleos Destacados para ti</h2>
                <p class="lead text-muted">Basado en tu perfil e intereses.</p>
            </div>
        </div>

        <?php if ($resultado_destacados && $resultado_destacados->num_rows > 0): ?>
            <div class="row g-4">
                <?php while ($vacante = $resultado_destacados->fetch_assoc()): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 job-card">
                            <div class="card-body d-flex flex-column">
                                <div class="d-flex align-items-center mb-3">
                                    <?php
                                        $foto_empresa = (!empty($vacante['foto_perfil']) && $vacante['foto_perfil'] !== 'foto_default' && file_exists('uploads/avatars/' . $vacante['foto_perfil']))
                                            ? 'uploads/avatars/' . htmlspecialchars($vacante['foto_perfil'])
                                            : null;
                                    ?>
                                    <?php if ($foto_empresa): ?>
                                        <img src="<?= $foto_empresa ?>" alt="Logo <?= htmlspecialchars($vacante['nombre_empresa']) ?>" width="50" height="50" class="rounded-circle me-3" style="object-fit: cover;">
                                    <?php else: ?>
                                        <div class="job-icon-box me-3"><i class="bi bi-building"></i></div>
                                    <?php endif; ?>
                                    <div>
                                        <h5 class="card-title mb-0"><a href="ver_vacante_detalle.php?id=<?= $vacante['id'] ?>" class="stretched-link text-decoration-none" style="color: inherit;"><?= htmlspecialchars($vacante['titulo']) ?></a></h5>
                                        <small class="text-muted"><?= htmlspecialchars($vacante['nombre_empresa']) ?></small>
                                    </div>
                                </div>
                                <p class="card-text text-muted small flex-grow-1"><?= htmlspecialchars(substr($vacante['descripcion'], 0, 100)) ?>...</p>
                                <div class="d-flex justify-content-between align-items-center mt-auto">
                                    <span class="badge-custom"><i class="bi bi-geo-alt-fill me-1"></i><?= htmlspecialchars($vacante['ubicacion']) ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="text-center p-5 border rounded" style="background-color: var(--surface-color);">
                <i class="bi bi-inbox display-1 text-muted mb-3"></i>
                <h3 class="fw-light">No hay empleos destacados por el momento.</h3>
                <p class="lead text-muted">¡Vuelve a intentarlo más tarde o explora todas las vacantes!</p>
                <a href="buscar.php" class="btn btn-gradient mt-3">Buscar Todas las Vacantes</a>
            </div>
        <?php endif; ?>
    </main>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
