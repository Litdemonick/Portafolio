<?php
session_start();
header('Content-Type: application/json');

require_once "conexion_dbs.php";
require_once "chatbot_config.php";

$response_data = ['respuesta' => 'Lo siento, ocurrió un error inesperado.'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $json_data = file_get_contents('php://input');
    $data = json_decode($json_data, true);

    if (isset($data['pregunta'])) {
        $user_message = $data['pregunta'];

        // Recopilar información del usuario para personalizar las respuestas
        $user_info = [
            'id' => $_SESSION['usuario_id'] ?? null,
            'rol' => $_SESSION['usuario_rol'] ?? 'invitado', // 'invitado' si no está logueado
            'nombre' => $_SESSION['usuario_nombres'] ?? 'Visitante' // Usamos el nombre de pila
        ];

        // Obtener la respuesta del bot
        $bot_response = get_chatbot_response($user_message, $conexion_local, $user_info);

        // Guardar la interacción en la base de datos (en ambas)
        $sql_log = "INSERT INTO chatbot_interacciones (id_usuario, pregunta, respuesta, fecha) VALUES (?, ?, ?, NOW())";
        try {
            replicar_consulta($sql_log, "iss", [$user_info['id'], $user_message, $bot_response]);
        } catch (Exception $e) {
            // No detener la ejecución si el log falla, pero registrar el error
            error_log("Error al registrar interacción del chatbot: " . $e->getMessage());
        }

        $response_data['respuesta'] = $bot_response;
    }
}

echo json_encode($response_data);
?>