<?php
session_start();
require_once "conexion_dbs.php";

// Proteger la página: solo para candidatos logueados
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] !== 'publico') {
    $_SESSION['mensaje'] = "❌ Debes iniciar sesión como candidato para calificar.";
    header("Location: login.php");
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$id_empresa = filter_input(INPUT_GET, 'id_empresa', FILTER_VALIDATE_INT);

if (!$id_empresa) {
    header("Location: buscar_empresas.php");
    exit();
}

// --- OBTENER DATOS DE LA EMPRESA Y CALIFICACIÓN ACTUAL ---
$stmt_empresa = $conexion_local->prepare("SELECT nombres as nombre_empresa FROM usuarios WHERE id = ? AND rol = 'empresa'");
$stmt_empresa->bind_param("i", $id_empresa);
$stmt_empresa->execute();
$empresa = $stmt_empresa->get_result()->fetch_assoc();

if (!$empresa) {
    header("Location: buscar_empresas.php");
    exit();
}

$stmt_rating = $conexion_local->prepare("SELECT calificacion FROM calificaciones_empresas WHERE id_empresa = ? AND id_usuario = ?");
$stmt_rating->bind_param("ii", $id_empresa, $usuario_id);
$stmt_rating->execute();
$res_rating = $stmt_rating->get_result()->fetch_assoc();
$calificacion_usuario = $res_rating['calificacion'] ?? 0;

// --- LÓGICA DE CALIFICACIÓN (POST) ---
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['calificar'])) {
    $calificacion = filter_input(INPUT_POST, 'rating', FILTER_VALIDATE_INT);

    if ($calificacion >= 1 && $calificacion <= 5) {
        $sql_replica_query = '';
        $replica_params = [];
        $replica_types = '';

        if ($calificacion_usuario > 0) { // Si ya existe, es un UPDATE
            $stmt_calif = $conexion_local->prepare("UPDATE calificaciones_empresas SET calificacion = ? WHERE id_empresa = ? AND id_usuario = ?");
            $stmt_calif->bind_param("dii", $calificacion, $id_empresa, $usuario_id);
            $sql_replica_query = "UPDATE calificaciones_empresas SET calificacion = ? WHERE id_empresa = ? AND id_usuario = ?";
            $replica_params = [$calificacion, $id_empresa, $usuario_id];
            $replica_types = "dii";
        } else { // Si no existe, es un INSERT
            $stmt_calif = $conexion_local->prepare("INSERT INTO calificaciones_empresas (id_empresa, id_usuario, calificacion) VALUES (?, ?, ?)");
            $stmt_calif->bind_param("iid", $id_empresa, $usuario_id, $calificacion);
            $sql_replica_query = "INSERT INTO calificaciones_empresas (id_empresa, id_usuario, calificacion) VALUES (?, ?, ?)";
            $replica_params = [$id_empresa, $usuario_id, $calificacion];
            $replica_types = "iid";
        }

        if ($stmt_calif->execute()) {
            // Solo intentar replicar si la consulta local fue exitosa
            if (function_exists('replicar_consulta')) {
                $resultado_replicacion = replicar_consulta($sql_replica_query, $replica_types, $replica_params);
                if ($resultado_replicacion && $resultado_replicacion['success']) {
                    $_SESSION['mensaje_global'] = "✅ ¡Gracias por tu calificación para " . htmlspecialchars($empresa['nombre_empresa']) . "!";
                    $_SESSION['mensaje_global_tipo'] = 'success';
                } else {
                    // Si la replicación falla, el log del servidor ya tiene el detalle.
                    // Mostramos un mensaje de éxito al usuario porque la acción principal (local) funcionó.
                    $_SESSION['mensaje_global'] = "✅ ¡Gracias por tu calificación! (Hubo un problema de sincronización)";
                    $_SESSION['mensaje_global_tipo'] = 'warning';
                }
            }
        } else {
            $_SESSION['mensaje_global'] = "❌ Error al guardar tu calificación. Inténtalo de nuevo.";
            $_SESSION['mensaje_global_tipo'] = 'danger';
        }
        // Redirigir a una página neutral como el dashboard para mostrar el mensaje global
        header("Location: dashboard.php");
        exit();
    }
}

function render_stars_input($rating_value) {
    $html = '<div class="rating-stars">';
    for ($i = 5; $i >= 1; $i--) {
        $checked = ($i == $rating_value) ? 'checked' : '';
        $html .= "<input type='radio' id='star{$i}' name='rating' value='{$i}' {$checked} required><label for='star{$i}' title='{$i} estrellas'><i class='bi bi-star-fill'></i></label>";
    }
    $html .= '</div>';
    return $html;
}

include 'includes/header.php';
?>

<style>
    .rating-page-card {
        background-color: var(--surface-color);
        border: 1px solid var(--border-color);
        border-radius: 1rem;
        padding: 3rem;
        box-shadow: 0 10px 40px rgba(0,0,0,0.15);
        max-width: 600px;
        margin: auto;
        text-align: center;
    }
    .rating-stars { 
        display: inline-flex; flex-direction: row-reverse; justify-content: center; gap: 0.5rem;
    }
    .rating-stars input[type="radio"] { display: none; }
    .rating-stars label { 
        font-size: 3.5rem; color: #444; cursor: pointer; transition: all 0.2s ease-in-out;
        text-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    body[data-theme="dark"] .rating-stars label { color: #555; }
    .rating-stars input[type="radio"]:checked ~ label,
    .rating-stars:not(:hover) input[type="radio"]:checked ~ label {
        color: #FFD700 !important;
        text-shadow: 0 0 15px rgba(255, 215, 0, 0.6);
        transform: scale(1.1);
    }
    .rating-stars label:hover,
    .rating-stars label:hover ~ label {
        color: #FFA500 !important;
        transform: scale(1.15) rotate(5deg);
    }
    #btn-calificar:disabled {
        background: var(--text-color-muted);
        cursor: not-allowed;
    }
</style>

<main class="container py-5">
    <div class="rating-page-card">
        <h1 class="form-title">Calificar a la Empresa</h1>
        <p class="form-subtitle fs-5">"<?= htmlspecialchars($empresa['nombre_empresa']) ?>"</p>
        <p class="text-muted mb-4">Tu opinión ayuda a toda la comunidad a tomar mejores decisiones.</p>

        <form method="POST" action="calificacion_empresa.php?id_empresa=<?= $id_empresa ?>">
            <div class="my-5">
                <?= render_stars_input($calificacion_usuario) ?>
            </div>
            
            <div class="d-grid gap-2">
                <button type="submit" name="calificar" class="btn btn-gradient btn-lg" id="btn-calificar" <?= $calificacion_usuario == 0 ? 'disabled' : '' ?>>
                    <i class="bi bi-send-check-fill me-2"></i>
                    <span id="btn-text"><?= $calificacion_usuario > 0 ? 'Actualizar Calificación' : 'Enviar Calificación' ?></span>
                </button>
            </div>
        </form>
        <?php if ($calificacion_usuario > 0): ?>
            <div class="alert alert-info mt-4">
                <i class="bi bi-info-circle me-1"></i>Tu calificación anterior era de <strong><?= $calificacion_usuario ?> estrellas</strong>.
            </div>
        <?php endif; ?>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const ratingInputs = document.querySelectorAll('.rating-stars input[name="rating"]');
    const calificarBtn = document.getElementById('btn-calificar');
    const btnText = document.getElementById('btn-text');
    const tieneCalificacionPrevia = <?= $calificacion_usuario > 0 ? 'true' : 'false' ?>;

    ratingInputs.forEach(input => {
        input.addEventListener('change', () => {
            if (calificarBtn) {
                calificarBtn.disabled = false;
                if (tieneCalificacionPrevia) {
                    btnText.textContent = 'Actualizar Calificación';
                } else {
                    btnText.textContent = 'Enviar Calificación';
                }
            }
        });
    });
});
</script>

<?php include 'includes/footer.php'; ?>