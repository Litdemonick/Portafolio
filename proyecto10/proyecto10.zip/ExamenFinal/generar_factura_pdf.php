<?php
session_start();

// =============================================================================
// 1. CONFIGURACIÓN Y LIBRERÍAS
// =============================================================================

// Detección automática de FPDF
$posibles_rutas = [
    __DIR__ . '/fpdf/fpdf.php',
    __DIR__ . '/FPDF/fpdf.php',
    __DIR__ . '/fpdf186/fpdf.php',
    __DIR__ . '/../fpdf/fpdf.php',
    __DIR__ . '/lib/fpdf/fpdf.php'
];

$ruta_fpdf_encontrada = null;
foreach ($posibles_rutas as $ruta) {
    if (file_exists($ruta)) {
        $ruta_fpdf_encontrada = $ruta;
        break;
    }
}

if (!$ruta_fpdf_encontrada) {
    die("<div style='font-family: sans-serif; padding: 20px; background: #ffebee; border: 1px solid #f44336; color: #b71c1c; border-radius: 5px;'><h3>⚠️ Error: Falta FPDF</h3><p>No se encontró fpdf.php.</p></div>");
}

require_once "conexion_dbs.php";
require_once $ruta_fpdf_encontrada;

// =============================================================================
// 2. SEGURIDAD Y DATOS
// =============================================================================

if (!isset($_SESSION['usuario_id']) || !in_array($_SESSION['usuario_rol'], ['empresa', 'admin'])) {
    die("Acceso denegado.");
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['vacantes_a_facturar'])) {
    die("No se seleccionaron vacantes.");
}

$id_empresa = (int)$_POST['id_empresa'];
$vacantes_seleccionadas = (array)$_POST['vacantes_a_facturar'];

if ($_SESSION['usuario_rol'] === 'empresa' && $id_empresa !== $_SESSION['usuario_id']) {
    die("Error de seguridad.");
}

// Configuración de Precios
const COSTO_POR_VISTA = 0.15;
const IMPUESTO_PORCENTAJE = 0.07; // 7% ITBMS (Ajustar según país)

// Obtener datos de la empresa (Cliente)
$sql_empresa = "
    SELECT 
        e.nombre_empresa, e.razon_social, e.documento, e.provincia, e.calle, 
        e.numero_direccion, e.codigo_postal, e.telefono_empresa,
        u.correo -- Se obtiene el correo de la tabla usuarios
    FROM empresas e
    JOIN usuarios u ON e.usuario_id = u.id
    WHERE e.usuario_id = ?
";
$stmt_empresa = $conexion_local->prepare($sql_empresa);
$stmt_empresa->bind_param("i", $id_empresa);
$stmt_empresa->execute();
$datos_cliente = $stmt_empresa->get_result()->fetch_assoc();
$stmt_empresa->close();

// Obtener datos de las vacantes (Items)
$placeholders = implode(',', array_fill(0, count($vacantes_seleccionadas), '?'));
$types = str_repeat('i', count($vacantes_seleccionadas));

$sql = "SELECT v.titulo, COUNT(vv.id) as total_vistas FROM vacantes v LEFT JOIN vacante_vistas vv ON v.id = vv.id_vacante WHERE v.id_empresa = ? AND v.id IN ($placeholders) GROUP BY v.id, v.titulo";

$stmt_vacantes = $conexion_local->prepare($sql);
$stmt_vacantes->bind_param("i" . $types, $id_empresa, ...$vacantes_seleccionadas);
$stmt_vacantes->execute();
$items_factura = $stmt_vacantes->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt_vacantes->close();

// =============================================================================
// 3. GUARDAR REGISTRO DE FACTURA EN LA BASE DE DATOS
// =============================================================================

$subtotal_calculado = 0;
foreach ($items_factura as $item) {
    $subtotal_calculado += (int)$item['total_vistas'] * COSTO_POR_VISTA;
}

$impuesto_calculado = $subtotal_calculado * IMPUESTO_PORCENTAJE;
$total_calculado = $subtotal_calculado + $impuesto_calculado;
$numero_factura_generado = 'FAC-' . date('Y') . '-' . rand(1000, 9999);
$ids_vacantes_str = implode(',', $vacantes_seleccionadas);

// Preparar la consulta para la replicación
$sql_insert_factura = "
    INSERT INTO facturacion 
        (id_empresa, numero_factura, subtotal, impuestos, total_factura, vacantes_facturadas, estado)
    VALUES 
        (?, ?, ?, ?, ?, ?, 'generada')
";
$params_factura = [
    $id_empresa,
    $numero_factura_generado,
    $subtotal_calculado,
    $impuesto_calculado,
    $total_calculado,
    $ids_vacantes_str
];
$types_factura = "isddds";

// --- CORRECCIÓN: Ejecutar primero en la base de datos local (Windows) ---
try {
    $stmt_local_factura = $conexion_local->prepare($sql_insert_factura);
    $stmt_local_factura->bind_param($types_factura, ...$params_factura);
    $stmt_local_factura->execute();
    $stmt_local_factura->close();
} catch (Exception $e) {
    // Si la inserción local falla, detenemos todo para no generar una factura sin registro.
    die("Error crítico al guardar la factura en la base de datos principal: " . $e->getMessage());
}

// Luego, usar la función para replicar en la base de datos remota (Ubuntu)
replicar_consulta($sql_insert_factura, $types_factura, $params_factura);


// =============================================================================
// 3. CLASE PDF DISEÑO MODERNO
// =============================================================================

class PDF_Invoice extends FPDF {
    // Colores corporativos
    private $col_primary = [63, 81, 181];    // Azul Oscuro (Tipo Material Design)
    private $col_secondary = [100, 100, 100]; // Gris Texto
    private $col_accent = [255, 160, 0];      // Naranja (Para detalles)
    private $col_line = [200, 200, 200];      // Gris claro para líneas

    function Header() {
        global $numero_factura_generado; // Hacemos la variable global accesible aquí

        // --- LOGO Y EMPRESA EMISORA (JOBS360) ---
        $logo_path = __DIR__ . '/img/logo.png';
        if(file_exists($logo_path)) { 
            $this->Image($logo_path, 10, 10, 35); // Ajusta tamaño según tu logo
        } else {
            // Fallback si no hay logo: Texto grande
            $this->SetFont('Arial', 'B', 24);
            $this->SetTextColor($this->col_primary[0], $this->col_primary[1], $this->col_primary[2]);
            $this->Text(10, 20, 'JOBS360');
        }

        // Datos de la empresa emisora (Izquierda, debajo del logo)
        $this->SetXY(10, 30);
        $this->SetFont('Arial', '', 9);
        $this->SetTextColor($this->col_secondary[0], $this->col_secondary[1], $this->col_secondary[2]);
        
        $this->Cell(100, 4, utf8_decode("RUC: 8-123-456 DV 77"), 0, 1);
        $this->Cell(100, 4, utf8_decode("Dirección: Calle 50, Edificio Global, Piso 12"), 0, 1);
        $this->Cell(100, 4, utf8_decode("Teléfono: (507) 222-3333"), 0, 1);
        $this->Cell(100, 4, utf8_decode("Email: contabilidad@jobs360.com"), 0, 1);

        // --- DATOS DE FACTURA (Derecha Superior) ---
        $this->SetXY(120, 10);
        $this->SetFont('Arial', 'B', 20);
        $this->SetTextColor(200, 200, 200); // Gris muy claro para la palabra FACTURA
        $this->Cell(80, 10, 'FACTURA', 0, 1, 'R');
        
        $this->SetTextColor($this->col_secondary[0], $this->col_secondary[1], $this->col_secondary[2]);
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 6, utf8_decode('N° ' . $numero_factura_generado), 0, 1, 'R');
        
        $this->SetFont('Arial', '', 10);
        $this->Cell(0, 6, utf8_decode('Fecha de Emisión: ') . date('d/m/Y H:i'), 0, 1, 'R');
        
        // Estado "EMITIDA" pequeño
        $this->Ln(2);
        $this->SetFont('Arial', 'B', 8);
        $this->SetTextColor($this->col_primary[0], $this->col_primary[1], $this->col_primary[2]);
        $this->Cell(0, 4, 'EMITIDA', 0, 1, 'R');

        // --- LÍNEA SEPARADORA AZUL ---
        $this->Ln(8);
        $this->SetDrawColor($this->col_primary[0], $this->col_primary[1], $this->col_primary[2]);
        $this->SetLineWidth(1);
        $this->Line(10, $this->GetY(), 200, $this->GetY());
        $this->Ln(10);
    }

    function SectionTitle($title, $icon = '') {
        $this->SetFont('Arial', 'B', 11);
        $this->SetTextColor($this->col_primary[0], $this->col_primary[1], $this->col_primary[2]);
        // Simulamos icono con un pequeño cuadrado si no hay imagen
        $this->Rect($this->GetX(), $this->GetY()+1, 3, 3, 'F'); 
        $this->SetX($this->GetX() + 5);
        $this->Cell(0, 6, strtoupper(utf8_decode($title)), 0, 1, 'L');
        $this->Ln(2);
    }

    function ClientInfo($data) {
        $this->SectionTitle("INFORMACIÓN DEL CLIENTE");
        
        $this->SetFont('Arial', 'B', 9);
        $this->SetTextColor(80, 80, 80);
        
        $y_start = $this->GetY();
        
        // Columna 1
        $this->Text(10, $y_start + 4, utf8_decode("Nombre:"));
        $this->Text(10, $y_start + 10, utf8_decode("Teléfono:"));
        $this->Text(10, $y_start + 16, utf8_decode("Dirección:"));
        
        $this->SetFont('Arial', '', 9);
        $this->SetTextColor(100, 100, 100);
        
        $this->SetXY(30, $y_start);
        $this->Cell(60, 5, utf8_decode($data['nombre_empresa']), 0, 1); // Nombre
        $this->SetXY(30, $y_start + 6);
        $this->Cell(60, 5, utf8_decode($data['telefono_empresa']), 0, 1); // Telefono
        $this->SetXY(30, $y_start + 12);
        
        // Dirección (MultiCell por si es larga)
        $direccion_completa = $data['calle'] . ' ' . $data['numero_direccion'] . ', ' . $data['provincia'];
        $this->MultiCell(70, 5, utf8_decode($direccion_completa), 0, 'L');

        // Columna 2
        $this->SetXY(110, $y_start);
        $this->SetFont('Arial', 'B', 9);
        $this->SetTextColor(80, 80, 80);
        
        $this->Text(110, $y_start + 4, utf8_decode("Cédula/RUC:"));
        $this->Text(110, $y_start + 10, utf8_decode("Email:"));
        
        $this->SetFont('Arial', '', 9);
        $this->SetTextColor(100, 100, 100);
        
        $this->SetXY(135, $y_start);
        $this->Cell(60, 5, utf8_decode($data['documento']), 0, 1);
        $this->SetXY(135, $y_start + 6);
        $email = isset($data['correo']) ? $data['correo'] : 'No registrado';
        $this->Cell(60, 5, utf8_decode($email), 0, 1); // Corregido a 'correo'

        $this->Ln(15);
    }

    function InvoiceTable($data) {
        $this->SectionTitle("DETALLE DEL SERVICIO");

        // Encabezados
        $this->SetFont('Arial', 'B', 9);
        $this->SetTextColor(180, 180, 180); // Gris claro para headers
        $this->Cell(110, 8, utf8_decode("Descripción"), 'B', 0, 'L');
        $this->Cell(30, 8, utf8_decode("Cant. Vistas"), 'B', 0, 'C');
        $this->Cell(20, 8, utf8_decode("Precio U."), 'B', 0, 'R');
        $this->Cell(30, 8, utf8_decode("Monto"), 'B', 1, 'R');

        // Filas
        $this->SetFont('Arial', '', 9);
        $this->SetTextColor(50, 50, 50);
        
        $subtotal_general = 0;

        foreach ($data as $row) {
            $vistas = (int)$row['total_vistas'];
            $subtotal = $vistas * COSTO_POR_VISTA;
            $subtotal_general += $subtotal;

            $this->Cell(110, 10, utf8_decode($row['titulo']), 'B', 0, 'L');
            $this->Cell(30, 10, $vistas, 'B', 0, 'C');
            $this->Cell(20, 10, '$' . number_format(COSTO_POR_VISTA, 2), 'B', 0, 'R');
            $this->Cell(30, 10, '$' . number_format($subtotal, 2), 'B', 1, 'R');
        }

        return $subtotal_general;
    }

    function Totals($subtotal) {
        $impuesto = $subtotal * IMPUESTO_PORCENTAJE;
        $total = $subtotal + $impuesto;

        $this->Ln(5);
        
        // Alinear a la derecha
        $x_start = 130;
        $width_lbl = 30;
        $width_val = 30;

        // Subtotal
        $this->SetX($x_start);
        $this->SetFont('Arial', '', 10);
        $this->SetTextColor(50, 50, 50);
        $this->Cell($width_lbl, 6, 'Subtotal:', 0, 0, 'R');
        $this->SetFont('Arial', 'B', 10);
        $this->Cell($width_val, 6, '$' . number_format($subtotal, 2), 0, 1, 'R');

        // ITBMS
        $this->SetX($x_start);
        $this->SetFont('Arial', '', 10);
        $this->Cell($width_lbl, 6, 'ITBMS (7%):', 0, 0, 'R');
        $this->SetFont('Arial', 'B', 10);
        $this->Cell($width_val, 6, '$' . number_format($impuesto, 2), 0, 1, 'R');

        // Línea separadora del total
        $this->SetDrawColor($this->col_primary[0], $this->col_primary[1], $this->col_primary[2]);
        $this->SetLineWidth(0.5);
        $this->Line($x_start, $this->GetY()+2, 200, $this->GetY()+2);
        $this->Ln(4);

        // TOTAL
        $this->SetX($x_start);
        $this->SetFont('Arial', 'B', 12);
        $this->SetTextColor($this->col_primary[0], $this->col_primary[1], $this->col_primary[2]);
        $this->Cell($width_lbl, 8, 'TOTAL A PAGAR:', 0, 0, 'R');
        $this->SetFont('Arial', 'B', 14);
        $this->Cell($width_val, 8, '$' . number_format($total, 2), 0, 1, 'R');
        
        $this->Ln(10);
    }

    function PaymentInfo() {
        $this->SectionTitle("Forma de Pago", "card");
        $this->SetFont('Arial', '', 10);
        $this->SetTextColor(80, 80, 80);
        $this->Cell(0, 5, utf8_decode("Transferencia Bancaria / ACH / Yappy"), 0, 1);
        $this->Ln(5);
    }

    function Observations() {
        $this->Ln(5);
        // Barra naranja lateral
        $this->SetFillColor($this->col_accent[0], $this->col_accent[1], $this->col_accent[2]);
        $this->Rect(10, $this->GetY(), 1.5, 12, 'F');
        
        $this->SetX(13);
        $this->SetFont('Arial', 'B', 10);
        $this->SetTextColor($this->col_accent[0], $this->col_accent[1], $this->col_accent[2]);
        $this->Cell(0, 5, utf8_decode("Observaciones:"), 0, 1);
        
        $this->SetX(13);
        $this->SetFont('Arial', '', 9);
        $this->SetTextColor(100, 100, 100);
        $this->Cell(0, 5, utf8_decode("Gracias por utilizar los servicios de Jobs360."), 0, 1);
    }

    function Footer() {
        $this->SetY(-30);
        $this->SetDrawColor(200, 200, 200);
        $this->Line(10, $this->GetY(), 200, $this->GetY());
        
        $this->SetY(-25);
        $this->SetFont('Arial', 'B', 9);
        $this->SetTextColor(100, 100, 100);
        $this->Cell(0, 5, utf8_decode("¡Gracias por su preferencia!"), 0, 1, 'C');
        
        $this->SetFont('Arial', '', 8);
        $this->Cell(0, 5, utf8_decode("Este es un documento electrónico generado por el sistema de Jobs360."), 0, 1, 'C');
        
        $this->SetY(-15);
        $this->Cell(0, 10, utf8_decode('Página ') . $this->PageNo() . '/{nb}', 0, 0, 'R');
    }
}

// =============================================================================
// 4. GENERACIÓN DEL PDF
// =============================================================================

// Limpiar buffer de salida para evitar errores de PDF corrupto
if (ob_get_length()) ob_clean();

$pdf = new PDF_Invoice();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetMargins(10, 10, 10);
$pdf->SetAutoPageBreak(true, 20);

// Renderizar secciones
$pdf->ClientInfo($datos_cliente);
$subtotal = $pdf->InvoiceTable($items_factura ? $items_factura : []);
$pdf->Totals($subtotal);
$pdf->PaymentInfo();
$pdf->Observations();

// Salida
$pdf->Output('I', 'Factura_Jobs360_' . date('Y-m-d_Hi') . '.pdf');
?>