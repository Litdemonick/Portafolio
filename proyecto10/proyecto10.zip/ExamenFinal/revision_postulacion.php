<?php
session_start();
require_once "conexion_dbs.php";

// Proteger la página: solo para empresas logueadas
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] !== 'empresa') {
    header("Location: login.php");
    exit();
}

$id_empresa = $_SESSION['usuario_id'];

// --- LÓGICA PARA MARCAR POSTULACIONES COMO VISTAS ---
// Al cargar esta página, todas las postulaciones no vistas de esta empresa se marcan como vistas.
$sql_update_visto = "UPDATE postulaciones p JOIN vacantes v ON p.id_vacante = v.id SET p.visto = 1 WHERE v.id_empresa = ? AND p.visto = 0";

try {
    // Ejecutar en la base de datos local (Windows)
    $stmt_local = $conexion_local->prepare($sql_update_visto);
    $stmt_local->bind_param("i", $id_empresa);
    $stmt_local->execute();

    // Ejecutar en la base de datos remota (Ubuntu)
    $stmt_remoto = $conexion_remota->prepare($sql_update_visto);
    $stmt_remoto->bind_param("i", $id_empresa);
    $stmt_remoto->execute();

} catch (Exception $e) {
    // Si algo falla, se registra en el log del servidor.
    // No detenemos la carga de la página, pero la sincronización puede haber fallado.
    error_log("Error al marcar postulaciones como vistas: " . $e->getMessage());
}

// --- OBTENER TODAS LAS POSTULACIONES AGRUPADAS POR VACANTE ---
$sql_postulaciones = "
    SELECT 
        v.id as id_vacante,
        v.titulo as titulo_vacante,
        v.puestos_disponibles,
        p.id as id_postulacion,
        p.fecha_postulacion,
        p.estado,
        u.nombres,
        u.apellidos,
        u.foto_perfil,
        h.titulo_profesional
    FROM postulaciones p
    JOIN vacantes v ON p.id_vacante = v.id
    JOIN usuarios u ON p.id_usuario = u.id
    JOIN hvs h ON p.id_hv = h.id
    WHERE v.id_empresa = ? 
    ORDER BY v.titulo, p.fecha_postulacion DESC
";
$stmt = $conexion_local->prepare($sql_postulaciones);
$stmt->bind_param("i", $id_empresa);
$stmt->execute();
$resultado = $stmt->get_result();
$postulaciones_raw = $resultado->fetch_all(MYSQLI_ASSOC);

// Agrupar postulaciones por vacante
$postulaciones_agrupadas = [];
foreach ($postulaciones_raw as $postulacion) {
    // Usamos el ID de la vacante como clave para evitar problemas con títulos idénticos
    $id_vacante_actual = $postulacion['id_vacante'];
    $postulaciones_agrupadas[$id_vacante_actual]['postulaciones'][] = $postulacion;
    $postulaciones_agrupadas[$id_vacante_actual]['info_vacante'] = ['titulo' => $postulacion['titulo_vacante'], 'puestos' => $postulacion['puestos_disponibles']];
}

// Función para obtener la clase del badge según el estado
function get_status_badge_class($estado) {
    switch ($estado) {
        case 'aceptado':
            return 'bg-success';
        case 'rechazado':
            return 'bg-danger';
        case 'recibido':
        default:
            return 'bg-info text-dark';
    }
}

include 'includes/header.php';
?>

<style>
    .accordion-button:not(.collapsed) {
        background-color: rgba(var(--primary-color-rgb), 0.1);
        color: var(--primary-color);
    }
    .applicant-card {
        transition: all 0.2s ease-in-out;
    }
    .applicant-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    .applicant-avatar {
        width: 50px;
        height: 50px;
        object-fit: cover;
        border-radius: 50%;
    }
    .applicant-avatar-default {
        width: 50px; height: 50px; display: flex; align-items: center; justify-content: center;
        background-color: var(--surface-color-secondary); border-radius: 50%; font-size: 1.5rem;
    }
</style>

<main class="container py-5">
    <h1 class="display-6 mb-4">Revisión de Postulaciones</h1>

    <?php if (empty($postulaciones_agrupadas)): ?>
        <div class="text-center p-5 border rounded bg-light">
            <i class="bi bi-person-x-fill display-1 text-muted mb-3"></i>
            <p class="lead">Aún no has recibido ninguna postulación en tus vacantes.</p>
        </div>
    <?php else: ?>
        <div class="accordion" id="accordionPostulaciones">
            <?php foreach ($postulaciones_agrupadas as $id_vacante => $grupo): ?>
                <?php $info_vacante = $grupo['info_vacante']; ?>
                <?php $postulaciones = $grupo['postulaciones']; ?>
                <div class="accordion-item mb-3" style="background-color: var(--surface-color); border: 1px solid var(--border-color);">
                    <h2 class="accordion-header" id="heading-<?= $id_vacante ?>">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-<?= $id_vacante ?>" aria-expanded="false" aria-controls="collapse-<?= $id_vacante ?>">
                            <?= htmlspecialchars($info_vacante['titulo']) ?>
                            <span class="badge bg-primary rounded-pill ms-3"><?= count($postulaciones) ?> Postulantes</span>
                            <span class="badge bg-info text-dark rounded-pill ms-2"><?= htmlspecialchars($info_vacante['puestos']) ?> Puestos</span>
                        </button>
                    </h2>
                    <div id="collapse-<?= $id_vacante ?>" class="accordion-collapse collapse" aria-labelledby="heading-<?= $id_vacante ?>" data-bs-parent="#accordionPostulaciones">
                        <div class="accordion-body">
                            <div class="list-group">
                                <?php foreach ($postulaciones as $postulacion): ?>
                                    <a href="ver_candidato.php?id_postulacion=<?= $postulacion['id_postulacion'] ?>" class="list-group-item list-group-item-action applicant-card mb-2">
                                        <div class="d-flex align-items-center">
                                            <?php
                                                $foto_candidato = (!empty($postulacion['foto_perfil']) && $postulacion['foto_perfil'] !== 'foto_default' && file_exists('uploads/avatars/' . $postulacion['foto_perfil']))
                                                    ? 'uploads/avatars/' . htmlspecialchars($postulacion['foto_perfil'])
                                                    : null;
                                            ?>
                                            <?php if ($foto_candidato): ?>
                                                <img src="<?= $foto_candidato ?>" alt="Foto" class="applicant-avatar me-3">
                                            <?php else: ?>
                                                <div class="applicant-avatar-default me-3"><i class="bi bi-person-fill"></i></div>
                                            <?php endif; ?>
                                            <div class="flex-grow-1">
                                                <h5 class="mb-1"><?= htmlspecialchars($postulacion['nombres'] . ' ' . $postulacion['apellidos']) ?></h5>
                                                <p class="mb-1 text-muted"><?= htmlspecialchars($postulacion['titulo_profesional']) ?></p>
                                            </div>
                                            <div class="text-end">
                                                <small>Postuló: <?= date("d/m/Y", strtotime($postulacion['fecha_postulacion'])) ?></small>
                                                <br>
                                                <?php $badge_class = get_status_badge_class($postulacion['estado']); ?>
                                                <span class="badge <?= $badge_class ?>"><?= ucfirst($postulacion['estado']) ?></span>
                                            </div>
                                        </div>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>

<?php include 'includes/footer.php'; ?>
