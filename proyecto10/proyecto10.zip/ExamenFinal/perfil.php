<?php
session_start();
require_once "conexion_dbs.php"; // Asegúrate que este archivo no inicie la sesión de nuevo.

// Proteger la página: si no hay sesión, redirigir al login
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

$usuario_id = $_SESSION['usuario_id'];

// Recuperar mensajes de la sesión para mostrarlos después de la redirección
$mensaje = $_SESSION['mensaje_perfil'] ?? '';
$mensaje_tipo = $_SESSION['mensaje_perfil_tipo'] ?? 'info';
unset($_SESSION['mensaje_perfil']);
unset($_SESSION['mensaje_perfil_tipo']);

// Obtener los datos actuales del usuario para mostrarlos en el formulario
$sql_select = "SELECT nombres, apellidos, correo, telefono, foto_perfil, tipo_documento, numero_documento FROM usuarios WHERE id = $usuario_id LIMIT 1";
$resultado_usuario = $conexion_local->query($sql_select);
$usuario = $resultado_usuario->fetch_assoc();

// Si es una empresa, obtener también los datos de la empresa
$empresa = null;
if ($_SESSION['usuario_rol'] === 'empresa') {
    $sql_empresa_select = "SELECT * FROM empresas WHERE usuario_id = $usuario_id LIMIT 1";
    $resultado_empresa = $conexion_local->query($sql_empresa_select);
    if ($resultado_empresa && $resultado_empresa->num_rows > 0) {
        $empresa = $resultado_empresa->fetch_assoc();
    }
}

// Lógica para actualizar datos
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['update_profile'])) {
        // --- Lógica para actualizar perfil ---
        // Datos de usuario
        $nombres = $conexion_local->real_escape_string($_POST['nombres']);
        $apellidos = $conexion_local->real_escape_string($_POST['apellidos']);
        $tipo_documento = $conexion_local->real_escape_string($_POST['tipo_documento']);
        $numero_documento = $conexion_local->real_escape_string($_POST['numero_documento']);
        $telefono_input = $_POST['telefono'] ?? '';
        $telefono = !empty($telefono_input) ? $conexion_local->real_escape_string($telefono_input) : 'agregar_numero';

        $sql_updates_exitosos = true;
        $foto_perfil_nombre = null;

        // Manejo de la subida de la foto de perfil
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
            $directorio_subida = 'uploads/avatars/';
            if (!is_dir($directorio_subida)) mkdir($directorio_subida, 0755, true);

            $info_archivo = pathinfo($_FILES['foto']['name']);
            $extension = strtolower($info_archivo['extension']);
            $extensiones_permitidas = ['jpg', 'jpeg', 'png', 'gif'];

            if (in_array($extension, $extensiones_permitidas)) {
                // Eliminar foto anterior si existe
                if (!empty($usuario['foto_perfil']) && $usuario['foto_perfil'] !== 'foto_default' && file_exists($directorio_subida . $usuario['foto_perfil'])) {
                    @unlink($directorio_subida . $usuario['foto_perfil']);
                }
                
                $foto_perfil_nombre = uniqid('user_' . $usuario_id . '_', true) . '.' . $extension;
                $ruta_destino = $directorio_subida . $foto_perfil_nombre;

                if (move_uploaded_file($_FILES['foto']['tmp_name'], $ruta_destino)) {
                    $sql_foto = ", foto_perfil = '$foto_perfil_nombre'";
                } else {
                    $_SESSION['mensaje_perfil'] = "❌ Error al subir el archivo de imagen.";
                    $_SESSION['mensaje_perfil_tipo'] = 'danger';
                }
            } else {
                $_SESSION['mensaje_perfil'] = "❌ Formato de archivo no permitido. Sube solo JPG, JPEG, PNG o GIF.";
                $_SESSION['mensaje_perfil_tipo'] = 'danger';
            }
        }

        if (empty($_SESSION['mensaje_perfil'])) {
            // --- Validar duplicados antes de actualizar ---
            // Verificar número de documento
            $stmt_check = $conexion_local->prepare("SELECT id FROM usuarios WHERE numero_documento = ? AND id != ?");
            $stmt_check->bind_param("si", $numero_documento, $usuario_id);
            $stmt_check->execute();
            if ($stmt_check->get_result()->num_rows > 0) {
                $sql_updates_exitosos = false;
                $_SESSION['mensaje_perfil'] = "❌ El número de documento '$numero_documento' ya está en uso por otro usuario.";
                $_SESSION['mensaje_perfil_tipo'] = 'danger';
            }
            $stmt_check->close();

            // Verificar teléfono si no está vacío
            if ($sql_updates_exitosos && !empty($telefono_input)) {
                $stmt_check = $conexion_local->prepare("SELECT id FROM usuarios WHERE telefono = ? AND id != ?");
                $stmt_check->bind_param("si", $telefono, $usuario_id);
                $stmt_check->execute();
                if ($stmt_check->get_result()->num_rows > 0) {
                    $sql_updates_exitosos = false;
                    $_SESSION['mensaje_perfil'] = "❌ El número de teléfono '$telefono' ya está en uso por otro usuario.";
                    $_SESSION['mensaje_perfil_tipo'] = 'danger';
                }
                $stmt_check->close();
            }

            if ($sql_updates_exitosos) {
                // --- CORRECCIÓN: Ejecutar primero en la base de datos local (Windows) ---
                $sql_update_user_text = "UPDATE usuarios SET nombres = ?, apellidos = ?, tipo_documento = ?, numero_documento = ?, telefono = ? WHERE id = ?";
                $params_user_text = [$nombres, $apellidos, $tipo_documento, $numero_documento, $telefono, $usuario_id];
                $types_user_text = "sssssi";

                $stmt_local_user = $conexion_local->prepare($sql_update_user_text);
                $stmt_local_user->bind_param($types_user_text, ...$params_user_text);

                if ($stmt_local_user->execute()) {
                    // Si la ejecución local es exitosa, replicar en la remota
                    replicar_consulta($sql_update_user_text, $types_user_text, $params_user_text);
                    $_SESSION['usuario_nombre'] = $nombres . ' ' . $apellidos;
                } else {
                    $sql_updates_exitosos = false;
                    $_SESSION['mensaje_perfil'] = "❌ Error al actualizar los datos personales en la base de datos principal.";
                    $_SESSION['mensaje_perfil_tipo'] = 'danger';
                }
                $stmt_local_user->close();
            }

            // Actualizar foto de perfil si se subió una nueva
            if ($sql_updates_exitosos && $foto_perfil_nombre !== null) {
                // --- CORRECCIÓN: Ejecutar primero en la base de datos local (Windows) ---
                $sql_update_photo = "UPDATE usuarios SET foto_perfil = ? WHERE id = ?";
                $stmt_local_photo = $conexion_local->prepare($sql_update_photo);
                $stmt_local_photo->bind_param("si", $foto_perfil_nombre, $usuario_id);
                if ($stmt_local_photo->execute()) {
                    // Si la ejecución local es exitosa, replicar en la remota
                    replicar_consulta($sql_update_photo, "si", [$foto_perfil_nombre, $usuario_id]);
                    $_SESSION['usuario_foto'] = $foto_perfil_nombre;
                } else {
                    $sql_updates_exitosos = false;
                    $_SESSION['mensaje_perfil'] = "❌ Error al actualizar la foto de perfil.";
                    $_SESSION['mensaje_perfil_tipo'] = 'danger';
                }
            }

            // Si es empresa y no hubo errores, actualizar tabla empresas
            if ($sql_updates_exitosos && $_SESSION['usuario_rol'] === 'empresa' && isset($_POST['nombre_empresa'])) {
                $nombre_empresa = $conexion_local->real_escape_string($_POST['nombre_empresa']);
                $razon_social   = $conexion_local->real_escape_string($_POST['razon_social']);
                $condicion_fiscal = $conexion_local->real_escape_string($_POST['condicion_fiscal']);
                $provincia = $conexion_local->real_escape_string($_POST['provincia'] ?? '');
                $calle = $conexion_local->real_escape_string($_POST['calle'] ?? '');
                $numero_direccion = $conexion_local->real_escape_string($_POST['numero_direccion'] ?? '');
                $codigo_postal = $conexion_local->real_escape_string($_POST['codigo_postal'] ?? '');
                $telefono_empresa = $conexion_local->real_escape_string($_POST['telefono_empresa'] ?? '');
                $industria = $conexion_local->real_escape_string($_POST['industria'] ?? '');
                $cantidad_empleados = $conexion_local->real_escape_string($_POST['cantidad_empleados'] ?? '');
                $tipo_empresa = $conexion_local->real_escape_string($_POST['tipo_empresa'] ?? '');

                $sql_update_empresa = "UPDATE empresas SET nombre_empresa = '$nombre_empresa', razon_social = '$razon_social', condicion_fiscal = '$condicion_fiscal', provincia = '$provincia', calle = '$calle', numero_direccion = '$numero_direccion', codigo_postal = '$codigo_postal', telefono_empresa = '$telefono_empresa', industria = '$industria', cantidad_empleados = '$cantidad_empleados', tipo_empresa = '$tipo_empresa' WHERE usuario_id = $usuario_id";
                if (!replicar_consulta($sql_update_empresa)) {
                    $sql_updates_exitosos = false;
                    $_SESSION['mensaje_perfil'] = "❌ Error al actualizar los datos de la empresa.";
                    $_SESSION['mensaje_perfil_tipo'] = 'danger';
                }
            }

            if ($sql_updates_exitosos && empty($_SESSION['mensaje_perfil'])) {
                $_SESSION['mensaje_perfil'] = "✅ ¡Perfil actualizado con éxito!";
                $_SESSION['mensaje_perfil_tipo'] = 'success';
            }
        }
        header('Location: perfil.php');
        exit();

    } elseif (isset($_POST['delete_photo'])) {
        // --- Lógica para eliminar foto ---
        if (!empty($usuario['foto_perfil']) && $usuario['foto_perfil'] !== 'foto_default') {
            $ruta_foto_a_borrar = 'uploads/avatars/' . $usuario['foto_perfil'];
            $sql_delete_foto = "UPDATE usuarios SET foto_perfil = 'foto_default' WHERE id = $usuario_id";
            
            if (replicar_consulta($sql_delete_foto)) {
                if (file_exists($ruta_foto_a_borrar)) {
                    unlink($ruta_foto_a_borrar);
                }
                $_SESSION['usuario_foto'] = 'foto_default';
                $_SESSION['mensaje_perfil'] = "✅ Foto de perfil eliminada.";
                $_SESSION['mensaje_perfil_tipo'] = 'success';
            } else {
                $_SESSION['mensaje_perfil'] = "❌ Error al eliminar la foto.";
                $_SESSION['mensaje_perfil_tipo'] = 'danger';
            }
        } else {
            $_SESSION['mensaje_perfil'] = "ℹ️ No hay foto de perfil para eliminar.";
            $_SESSION['mensaje_perfil_tipo'] = 'info';
        }
        header('Location: perfil.php');
        exit();
    }
}

include 'includes/header.php';
?>

<main class="container py-5 d-flex align-items-center" style="min-height: calc(100vh - 120px);">
    <div class="row w-100 g-0">
        <div class="col-12">
            <div class="form-container mx-auto" style="max-width: 900px;">

                <form method="POST" class="mt-4" enctype="multipart/form-data">
                    <!-- Sección de Foto de Perfil (Movida y Centrada) -->
                    <div class="text-center mb-5">
                        <div id="avatar-container" class="mx-auto mb-3" style="width: 150px; height: 150px;">
                            <?php
                                $foto_perfil_path = !empty($usuario['foto_perfil']) && $usuario['foto_perfil'] !== 'foto_default' && file_exists('uploads/avatars/' . $usuario['foto_perfil'])
                                    ? 'uploads/avatars/' . htmlspecialchars($usuario['foto_perfil'])
                                    : null;
                            ?>
                            <img src="<?= $foto_perfil_path ? $foto_perfil_path . '?t=' . time() : '#' ?>" alt="Foto de perfil" class="profile-avatar" id="avatar-preview" style="<?= $foto_perfil_path ? '' : 'display:none;' ?>">
                            <div id="default-avatar" class="profile-avatar-default" style="<?= $foto_perfil_path ? 'display:none;' : '' ?>"><i class="bi bi-person-fill"></i></div>
                        </div>
                        <label for="foto" class="btn btn-outline-custom btn-sm">Cambiar Foto</label>
                        <input type="file" id="foto" name="foto" class="d-none" accept="image/png, image/jpeg, image/gif">
                        <?php if ($foto_perfil_path): ?>
                            <button type="submit" name="delete_photo" class="btn btn-outline-danger btn-sm" onclick="return confirm('¿Estás seguro de que quieres eliminar tu foto de perfil?');">Eliminar Foto</button>
                        <?php endif; ?>
                    </div>

                    <h1 class="form-title text-center">Mi Perfil</h1>
                    <p class="form-subtitle text-center">Actualiza tu información personal y de contacto.</p>

                    <?php if (!empty($mensaje)) : ?>
                        <div class="alert alert-<?= $mensaje_tipo ?> mt-3"><?= htmlspecialchars($mensaje) ?></div>
                    <?php endif; ?>

                    <!-- Campos del Formulario -->
                    <div class="mt-4 mx-auto" style="max-width: 800px;">
                        <div>
                            <h2 class="form-section-title">Datos Personales</h2>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="nombres" class="form-label">Nombre(s)*</label>
                                    <input type="text" class="form-control" id="nombres" name="nombres" value="<?= htmlspecialchars($usuario['nombres']) ?>" required maxlength="100">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="apellidos" class="form-label">Apellido(s)*</label>
                                    <input type="text" class="form-control" id="apellidos" name="apellidos" value="<?= htmlspecialchars($usuario['apellidos']) ?>" required maxlength="100">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="tipo_documento" class="form-label">Tipo de Documento*</label>
                                    <select class="form-select" id="tipo_documento" name="tipo_documento" required>
                                        <option value="cedula" <?= ($usuario['tipo_documento'] ?? '') == 'cedula' ? 'selected' : '' ?>>Cédula</option>
                                        <option value="pasaporte" <?= ($usuario['tipo_documento'] ?? '') == 'pasaporte' ? 'selected' : '' ?>>Pasaporte</option>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="numero_documento" class="form-label">Número de Documento*</label>
                                    <input type="text" class="form-control" id="numero_documento" name="numero_documento" value="<?= htmlspecialchars($usuario['numero_documento'] ?? '') ?>" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($usuario['correo']) ?>" disabled>
                                <div class="form-text">El correo electrónico no se puede cambiar.</div>
                            </div>
                            <div class="mb-3">
                                <label for="telefono" class="form-label">Teléfono</label>
                                <input type="tel" class="form-control" id="telefono" name="telefono" value="<?= ($usuario['telefono'] !== 'agregar_numero') ? htmlspecialchars($usuario['telefono']) : '' ?>" placeholder="Añade tu número de teléfono" maxlength="20">
                            </div>

                            <?php if ($_SESSION['usuario_rol'] === 'empresa' && $empresa): ?>
                                <hr class="my-4">
                                <h2 class="form-section-title">Datos de la Empresa</h2>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="nombre_empresa" class="form-label">Nombre de la empresa*</label>
                                        <input type="text" class="form-control" id="nombre_empresa" name="nombre_empresa" value="<?= htmlspecialchars($empresa['nombre_empresa']) ?>" required maxlength="255">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="razon_social" class="form-label">Razón social*</label>
                                        <input type="text" class="form-control" id="razon_social" name="razon_social" value="<?= htmlspecialchars($empresa['razon_social']) ?>" required maxlength="255">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="condicion_fiscal" class="form-label">Condición fiscal*</label>
                                        <select class="form-select" id="condicion_fiscal" name="condicion_fiscal" required>
                                            <option value="persona_natural" <?= $empresa['condicion_fiscal'] == 'persona_natural' ? 'selected' : '' ?>>Persona Natural</option>
                                            <option value="sociedad_anonima" <?= $empresa['condicion_fiscal'] == 'sociedad_anonima' ? 'selected' : '' ?>>Sociedad Anónima</option>
                                            <option value="otro" <?= $empresa['condicion_fiscal'] == 'otro' ? 'selected' : '' ?>>Otro</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="tipo_empresa" class="form-label">Tipo de empresa</label>
                                        <select class="form-select" id="tipo_empresa" name="tipo_empresa">
                                            <option value="" <?= empty($empresa['tipo_empresa']) ? 'selected' : '' ?>>Seleccione una opción</option>
                                            <option value="privada" <?= ($empresa['tipo_empresa'] ?? '') == 'privada' ? 'selected' : '' ?>>Privada</option>
                                            <option value="publica" <?= ($empresa['tipo_empresa'] ?? '') == 'publica' ? 'selected' : '' ?>>Pública</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="documento" class="form-label">Documento (RUC)</label>
                                        <input type="text" class="form-control" id="documento" name="documento" value="<?= htmlspecialchars($empresa['documento']) ?>" disabled>
                                        <div class="form-text">El documento no se puede cambiar.</div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="telefono_empresa" class="form-label">Teléfono de la empresa</label>
                                        <input type="tel" class="form-control" id="telefono_empresa" name="telefono_empresa" value="<?= htmlspecialchars($empresa['telefono_empresa']) ?>" maxlength="20">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="industria" class="form-label">Industria</label>
                                        <input type="text" class="form-control" id="industria" name="industria" value="<?= htmlspecialchars($empresa['industria']) ?>" placeholder="Ej: Tecnología, Retail, etc.">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="cantidad_empleados" class="form-label">Cantidad de empleados</label>
                                        <select class="form-select" id="cantidad_empleados" name="cantidad_empleados">
                                            <option value="" <?= empty($empresa['cantidad_empleados']) ? 'selected' : '' ?>>Seleccione un rango</option>
                                            <option value="1-10" <?= $empresa['cantidad_empleados'] == '1-10' ? 'selected' : '' ?>>1-10 empleados</option>
                                            <option value="11-50" <?= $empresa['cantidad_empleados'] == '11-50' ? 'selected' : '' ?>>11-50 empleados</option>
                                            <option value="51-200" <?= $empresa['cantidad_empleados'] == '51-200' ? 'selected' : '' ?>>51-200 empleados</option>
                                            <option value="201-500" <?= $empresa['cantidad_empleados'] == '201-500' ? 'selected' : '' ?>>201-500 empleados</option>
                                            <option value="501+" <?= $empresa['cantidad_empleados'] == '501+' ? 'selected' : '' ?>>Más de 500 empleados</option>
                                        </select>
                                    </div>
                                </div>
                                <h2 class="form-section-title mt-4">Dirección de la Empresa</h2>
                                <div class="row">
                                    <div class="col-md-6 mb-3"><label for="provincia" class="form-label">Provincia</label><input type="text" class="form-control" id="provincia" name="provincia" value="<?= htmlspecialchars($empresa['provincia']) ?>"></div>
                                    <div class="col-md-6 mb-3"><label for="calle" class="form-label">Calle</label><input type="text" class="form-control" id="calle" name="calle" value="<?= htmlspecialchars($empresa['calle']) ?>"></div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3"><label for="numero_direccion" class="form-label">Número</label><input type="text" class="form-control" id="numero_direccion" name="numero_direccion" value="<?= htmlspecialchars($empresa['numero_direccion']) ?>"></div>
                                    <div class="col-md-6 mb-3"><label for="codigo_postal" class="form-label">Código Postal</label><input type="text" class="form-control" id="codigo_postal" name="codigo_postal" value="<?= htmlspecialchars($empresa['codigo_postal']) ?>"></div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <hr class="my-4">

                    <div class="d-grid">
                        <button type="submit" name="update_profile" class="btn btn-gradient btn-lg">Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?>