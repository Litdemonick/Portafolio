<?php
session_start();
include 'includes/header.php';
require_once "conexion_dbs.php";

$mensaje = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (empty($_POST['email'])) {
        $mensaje = "❌ Por favor, ingresa tu correo electrónico.";
    } else {
        $correo = $conexion_local->real_escape_string($_POST['email']);

        $stmt = $conexion_local->prepare("SELECT id FROM usuarios WHERE correo = ? LIMIT 1");
        $stmt->bind_param("s", $correo);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado && $resultado->num_rows === 1) {
            $usuario = $resultado->fetch_assoc();
            $_SESSION['reset_password_user_id'] = $usuario['id'];
            header('Location: cambiar_password.php');
            exit();
        } else {
            $mensaje = "❌ No se encontró ninguna cuenta con ese correo electrónico.";
        }
        $stmt->close();
    }
}
?>

<main class="container d-flex align-items-center justify-content-center" style="min-height: 85vh;">
    <div class="form-container mx-auto" style="max-width: 450px;">
        <h1 class="form-title text-center">Recuperar Contraseña</h1>
        <p class="form-subtitle text-center">Ingresa tu correo para cambiar tu contraseña.</p>

        <?php if (!empty($mensaje)) : ?>
            <div class="alert alert-danger mt-3"><?= htmlspecialchars($mensaje) ?></div>
        <?php endif; ?>

        <form method="POST" class="mt-4">
            <div class="mb-3">
                <label for="email" class="form-label">Email de tu cuenta</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            
            <button type="submit" class="btn btn-gradient w-100 btn-lg mt-3">Continuar</button>
        </form>
    </div>
</main>

<?php include 'includes/footer.php'; ?>