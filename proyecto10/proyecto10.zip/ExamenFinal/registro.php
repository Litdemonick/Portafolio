<?php
session_start();
include 'includes/header.php';
require_once "conexion_dbs.php";

$mensaje = $_SESSION['mensaje'] ?? '';
$_SESSION['mensaje'] = ''; // Limpiar el mensaje de sesión para que no se muestre en otras páginas

// Variables para mantener los valores del formulario
$nombres_val   = '';
$apellidos_val = '';
$correo_val    = '';
$tipo_documento_val = '';
$numero_documento_val = '';
$telefono_val  = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Recolectar y sanear datos para repoblar el formulario en caso de error
    $nombres_val   = htmlspecialchars($_POST['nombres'] ?? '');
    $apellidos_val = htmlspecialchars($_POST['apellidos'] ?? '');
    $correo_val    = htmlspecialchars($_POST['email'] ?? '');
    $tipo_documento_val = htmlspecialchars($_POST['tipo_documento'] ?? '');
    $numero_documento_val = htmlspecialchars($_POST['numero_documento'] ?? '');
    $telefono_val  = htmlspecialchars($_POST['telefono'] ?? '');

    // 1. Validaciones básicas
    if (empty($_POST['nombres']) || empty($_POST['apellidos']) || empty($_POST['email']) || empty($_POST['password']) || empty($_POST['tipo_documento']) || empty($_POST['numero_documento'])) {
        $mensaje = "❌ Todos los campos con * son obligatorios.";
    } elseif (strlen($_POST['password']) < 6) {
        $mensaje = "❌ La contraseña debe tener al menos 6 caracteres.";
    } elseif ($_POST['password'] !== $_POST['password_repeat']) {
        $mensaje = "❌ Las contraseñas no coinciden.";
    } else {
        // 2. Recolección y saneamiento de datos para la BD
        $nombres   = $conexion_local->real_escape_string($_POST["nombres"]);
        $apellidos = $conexion_local->real_escape_string($_POST["apellidos"]);
        $correo    = $conexion_local->real_escape_string($_POST["email"]);
        $tipo_documento = $conexion_local->real_escape_string($_POST["tipo_documento"]);
        $numero_documento = $conexion_local->real_escape_string($_POST["numero_documento"]);
        $telefono_input = $_POST["telefono"] ?? '';
        $telefono  = !empty($telefono_input) ? $conexion_local->real_escape_string($telefono_input) : 'agregar_numero';
        $password  = password_hash($_POST["password"], PASSWORD_DEFAULT);
        $rol       = 'publico'; // Rol para usuarios que buscan empleo
        $fecha     = date("Y-m-d H:i:s");

        // 3. Verificar si el correo, documento o teléfono ya existen usando consultas preparadas
        $stmt_check = $conexion_local->prepare("SELECT id FROM usuarios WHERE correo = ?");
        $stmt_check->bind_param("s", $correo);
        $stmt_check->execute();
        $email_result = $stmt_check->get_result();

        $stmt_check = $conexion_local->prepare("SELECT id FROM usuarios WHERE numero_documento = ?");
        $stmt_check->bind_param("s", $numero_documento);
        $stmt_check->execute();
        $doc_result = $stmt_check->get_result();

        $phone_result = null;
        if (!empty($telefono_input)) {
            $stmt_check = $conexion_local->prepare("SELECT id FROM usuarios WHERE telefono = ?");
            $stmt_check->bind_param("s", $telefono);
            $stmt_check->execute();
            $phone_result = $stmt_check->get_result();
        }

        if ($email_result && $email_result->num_rows > 0) {
            $mensaje = "❌ Error: El correo electrónico '$correo_val' ya está registrado.";
        } elseif ($doc_result && $doc_result->num_rows > 0) {
            $mensaje = "❌ Error: El número de documento '$numero_documento_val' ya está registrado.";
        } elseif ($phone_result && $phone_result->num_rows > 0) {
            $mensaje = "❌ Error: El número de teléfono '$telefono_val' ya está en uso.";
        } else {
            // 4. Insertar el nuevo usuario
            $sql = "INSERT INTO usuarios (nombres, apellidos, correo, tipo_documento, numero_documento, telefono, password, rol, fecha_creacion, foto_perfil)
                    VALUES ('$nombres', '$apellidos', '$correo', '$tipo_documento', '$numero_documento', '$telefono', '$password', '$rol', '$fecha', 'foto_default')";

            $resultado_replicacion = replicar_consulta($sql);
            if ($resultado_replicacion['success']) {
                // Iniciar sesión automáticamente y redirigir al asistente de HV
                $nuevo_usuario_id = $conexion_local->insert_id;
                $_SESSION['usuario_id'] = $nuevo_usuario_id;
                $_SESSION['usuario_nombre'] = $nombres . ' ' . $apellidos;
                $_SESSION['usuario_rol'] = $rol;
                $_SESSION['usuario_foto'] = 'foto_default';
                // Mensaje de bienvenida para el asistente
                $_SESSION['mensaje_dashboard'] = "👋 ¡Bienvenido! Completa tu Hoja de Vida para empezar.";
                header("Location: crear_hv.php");
                exit();
            } else {
                $mensaje = "❌ Error registrando el usuario. Por favor, inténtalo de nuevo.";
            }
        }
    }
}
?>

<main class="container py-5">
    <div class="row justify-content-center align-items-center" style="min-height: calc(100vh - 200px);">
        <div class="col-lg-5 col-md-7 col-sm-9">
            <div class="form-container">
                <h1 class="form-title text-center">Crea tu Cuenta</h1>
                <p class="form-subtitle text-center">Únete a la comunidad y encuentra tu próximo trabajo.</p>

                <?php if (!empty($mensaje)) : ?>
            <div class="alert <?= str_contains($mensaje, '❌') ? 'alert-danger' : 'alert-success' ?> mt-3"><?= htmlspecialchars($mensaje) ?></div>
                <?php endif; ?>

                <form method="POST" action="registro.php" class="mt-4">
                    <div class="mb-3"><label for="nombres" class="form-label">Nombre(s)*</label><input type="text" class="form-control" id="nombres" name="nombres" value="<?= $nombres_val ?>" required maxlength="100"></div>
                    <div class="mb-3"><label for="apellidos" class="form-label">Apellido(s)*</label><input type="text" class="form-control" id="apellidos" name="apellidos" value="<?= $apellidos_val ?>" required maxlength="100"></div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="tipo_documento" class="form-label">Tipo de Documento*</label>
                            <select class="form-select" id="tipo_documento" name="tipo_documento" required>
                                <option value="" disabled <?= empty($tipo_documento_val) ? 'selected' : '' ?>>Seleccione...</option>
                                <option value="cedula" <?= $tipo_documento_val == 'cedula' ? 'selected' : '' ?>>Cédula</option>
                                <option value="pasaporte" <?= $tipo_documento_val == 'pasaporte' ? 'selected' : '' ?>>Pasaporte</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="numero_documento" class="form-label">Número de Documento*</label>
                            <input type="text" class="form-control" id="numero_documento" name="numero_documento" value="<?= $numero_documento_val ?>" required>
                        </div>
                    </div>
                    <div class="mb-3"><label for="email" class="form-label">Email*</label><input type="email" class="form-control" id="email" name="email" value="<?= $correo_val ?>" required></div>
                    <div class="mb-3">
                        <label for="telefono" class="form-label">Teléfono (Opcional)</label>
                        <input type="tel" class="form-control" id="telefono" name="telefono" value="<?= $telefono_val ?>" maxlength="20">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Contraseña*</label>
                        <input type="password" class="form-control" id="password" name="password" required minlength="6">
                        <div class="form-text">Debe tener al menos 6 caracteres.</div>
                    </div>
                    <div class="mb-3">
                        <label for="password_repeat" class="form-label">Repetir Contraseña*</label>
                        <input type="password" class="form-control" id="password_repeat" name="password_repeat" required minlength="6">
                    </div>
                    
                    <button type="submit" class="btn btn-gradient w-100 btn-lg mt-3">Crear Cuenta</button>

                    <p class="text-center mt-4">
                        ¿Eres una empresa? <a href="registro_empresa.php">Regístrate aquí</a>
                    </p>
                </form>
            </div>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?>