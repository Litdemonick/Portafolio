<?php
session_start();
require_once "conexion_dbs.php";

// 1. Proteger la página y obtener IDs
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] !== 'empresa') {
    header("Location: login.php");
    exit();
}

$id_empresa = $_SESSION['usuario_id'];
$id_vacante = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id_vacante) {
    header("Location: ver_vacantes.php");
    exit();
}

// 2. Obtener los datos actuales de la vacante (y verificar que pertenece a la empresa)
$stmt_vacante = $conexion_local->prepare("SELECT * FROM vacantes WHERE id = ? AND id_empresa = ?");
$stmt_vacante->bind_param("ii", $id_vacante, $id_empresa);
$stmt_vacante->execute();
$resultado_vacante = $stmt_vacante->get_result();

if ($resultado_vacante->num_rows === 0) {
    // La vacante no existe o no pertenece a esta empresa
    $_SESSION['mensaje_vacantes'] = "❌ Acceso denegado o vacante no encontrada.";
    header("Location: ver_vacantes.php");
    exit();
}
$vacante = $resultado_vacante->fetch_assoc();
$stmt_vacante->close();

$mensaje = '';

// 3. Lógica de actualización (POST)
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Validaciones básicas
    if (empty($_POST['titulo']) || empty($_POST['descripcion']) || empty($_POST['ubicacion']) || empty($_POST['modalidad'])) {
        $mensaje = "❌ Los campos con * son obligatorios.";
    } elseif (isset($_POST['puestos_disponibles']) && intval($_POST['puestos_disponibles']) > 1500) {
        $mensaje = "❌ El número de puestos disponibles no puede ser mayor a 1500.";
    } else {
        $titulo_post = $_POST['titulo'];

        // Validar título duplicado (excluyendo la vacante actual)
        $stmt_check_titulo = $conexion_local->prepare("SELECT id FROM vacantes WHERE titulo = ? AND id_empresa = ? AND id != ?");
        $stmt_check_titulo->bind_param("sii", $titulo_post, $id_empresa, $id_vacante);
        $stmt_check_titulo->execute();
        
        if ($stmt_check_titulo->get_result()->num_rows > 0) {
            $mensaje = "❌ Ya tienes otra vacante con el título '" . htmlspecialchars($titulo_post) . "'.";
        } else {
            // Recolectar datos (sin escape manual, ya que usamos consultas preparadas)
            $titulo = $_POST['titulo'];
            $descripcion = $_POST['descripcion'];
            $ubicacion = $_POST['ubicacion'];
            $modalidad = $_POST['modalidad'];
            $slogan = $_POST['slogan_puesto'];
            $puestos_disponibles = intval($_POST['puestos_disponibles']) > 0 ? intval($_POST['puestos_disponibles']) : 1;
 
            // Construir y replicar la consulta UPDATE de forma segura
            $sql = "UPDATE vacantes SET 
                        titulo = ?, 
                        descripcion = ?, 
                        ubicacion = ?, 
                        modalidad = ?, 
                        slogan_puesto = ?, 
                        puestos_disponibles = ?
                    WHERE id = ? AND id_empresa = ?";
            
            $params = [$titulo, $descripcion, $ubicacion, $modalidad, $slogan, $puestos_disponibles, $id_vacante, $id_empresa];
            $types = "sssssiis";
 
            // --- CORRECCIÓN: Ejecutar primero en la base de datos local (Windows) ---
            $local_success = false;
            try {
                $stmt_local = $conexion_local->prepare($sql);
                $stmt_local->bind_param($types, ...$params);
                if ($stmt_local->execute()) {
                    $local_success = true;
                } else {
                    throw new Exception($stmt_local->error);
                }
                $stmt_local->close();
            } catch (Exception $e) {
                $mensaje = "❌ Error al actualizar en la base de datos principal: " . $e->getMessage();
            }

            // Si la actualización local fue exitosa, replicar en la remota
            if ($local_success) {
                replicar_consulta($sql, $types, $params); // Esta función ya maneja la BD remota

                $_SESSION['mensaje_vacantes'] = "✅ ¡Vacante actualizada con éxito!";
                header("Location: ver_vacantes.php");
                exit();
            } else {
                // Si la actualización local falló, el mensaje de error ya se estableció en el bloque catch.
                // No es necesario hacer nada más aquí.
            }

        }
        $stmt_check_titulo->close();
    }
    // Si hay error, recargar los datos del POST en la variable $vacante para que el formulario los muestre
    $vacante = array_merge($vacante, $_POST);
}

include 'includes/header.php';
?>

<main class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="form-container">
                <h1 class="form-title text-center">Editar Vacante</h1>
                <p class="form-subtitle text-center">Actualiza los detalles de la oportunidad laboral.</p>

                <?php if (!empty($mensaje)) : ?>
                    <div class="alert <?= str_contains($mensaje, '❌') ? 'alert-danger' : 'alert-success' ?> mt-3"><?= htmlspecialchars($mensaje) ?></div>
                <?php endif; ?>

                <form method="POST" action="editar_vacante.php?id=<?= $id_vacante ?>" class="mt-4">
                    <div class="mb-3">
                        <label for="titulo" class="form-label">Título del Puesto*</label>
                        <input type="text" class="form-control" id="titulo" name="titulo" value="<?= htmlspecialchars($vacante['titulo']) ?>" required maxlength="100">
                    </div>

                    <div class="mb-3">
                        <label for="descripcion" class="form-label">Descripción del Puesto*</label>
                        <textarea class="form-control" id="descripcion" name="descripcion" rows="6" required maxlength="4000"><?= htmlspecialchars($vacante['descripcion']) ?></textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="ubicacion" class="form-label">Ubicación*</label>
                            <input type="text" class="form-control" id="ubicacion" name="ubicacion" value="<?= htmlspecialchars($vacante['ubicacion']) ?>" placeholder="Ej: Ciudad, País o 'Remoto'" required maxlength="100">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="modalidad" class="form-label">Modalidad de Trabajo*</label>
                            <select class="form-select" id="modalidad" name="modalidad" required>
                                <option value="Presencial" <?= $vacante['modalidad'] == 'Presencial' ? 'selected' : '' ?>>Presencial</option>
                                <option value="Remoto" <?= $vacante['modalidad'] == 'Remoto' ? 'selected' : '' ?>>Remoto</option>
                                <option value="Híbrido" <?= $vacante['modalidad'] == 'Híbrido' ? 'selected' : '' ?>>Híbrido</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="puestos_disponibles" class="form-label">Puestos Disponibles*</label>
                        <input type="number" class="form-control" id="puestos_disponibles" name="puestos_disponibles" value="<?= htmlspecialchars($vacante['puestos_disponibles']) ?>" min="1" max="1500" required>
                    </div>

                    <div class="mb-3">
                        <label for="industria" class="form-label">Industria</label>
                        <input type="text" class="form-control" id="industria" name="industria" value="<?= htmlspecialchars($vacante['industria']) ?>" disabled readonly>
                        <div class="form-text">La industria se toma del perfil de tu empresa y no se puede cambiar aquí.</div>
                    </div>

                    <div class="mb-3">
                        <label for="slogan_puesto" class="form-label">Slogan o Mensaje Motivacional (Opcional)</label>
                        <textarea class="form-control" id="slogan_puesto" name="slogan_puesto" rows="4" placeholder="Ej: En nuestra empresa, creemos en el poder de la colaboración... ¡Únete a nuestro equipo!" maxlength="1000"><?= htmlspecialchars($vacante['slogan_puesto']) ?></textarea>
                    </div>

                    <div class="d-flex justify-content-between mt-4">
                        <a href="ver_vacantes.php" class="btn btn-outline-secondary">Cancelar</a>
                        <button type="submit" class="btn btn-gradient">Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const puestosInput = document.getElementById('puestos_disponibles');
    if (puestosInput) {
        puestosInput.addEventListener('input', function() {
            const max = parseInt(this.getAttribute('max'), 10);
            let value = parseInt(this.value, 10);
            if (!isNaN(value) && value > max) { this.value = max; }
        });
    }
});
</script>

<?php include 'includes/footer.php'; ?>