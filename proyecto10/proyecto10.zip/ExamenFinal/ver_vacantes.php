<?php
session_start();
require_once "conexion_dbs.php";
 
// Proteger la página: solo para empresas logueadas
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] !== 'empresa') {
    header("Location: login.php");
    exit();
}
 
$id_empresa = $_SESSION['usuario_id'];
$mensaje = $_SESSION['mensaje_vacantes'] ?? '';
unset($_SESSION['mensaje_vacantes']); // Limpiar mensaje
 
// --- LÓGICA PARA CAMBIAR ESTADO DE VACANTE ---
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['cambiar_estado'])) {
    $id_vacante = intval($_POST['id_vacante']);
    $nuevo_estado = $_POST['nuevo_estado'] === 'activa' ? 'activa' : 'cerrada';
 
    // Validar que la vacante pertenece a la empresa
    $stmt_check = $conexion_local->prepare("SELECT id FROM vacantes WHERE id = ? AND id_empresa = ?");
    $stmt_check->bind_param("ii", $id_vacante, $id_empresa);
    $stmt_check->execute();
    $resultado_check = $stmt_check->get_result();
 
    if ($resultado_check->num_rows > 0) {
        // --- CORRECCIÓN: Ejecutar primero en local y luego replicar ---
        $sql = "UPDATE vacantes SET estado = ? WHERE id = ?";
        $params = [$nuevo_estado, $id_vacante];
        $types = "si";

        $local_success = false;
        try {
            $stmt_local = $conexion_local->prepare($sql);
            $stmt_local->bind_param($types, ...$params);
            if ($stmt_local->execute()) {
                $local_success = true;
            }
            $stmt_local->close();
        } catch (Exception $e) {
            $_SESSION['mensaje_vacantes'] = "❌ Error al actualizar en la BD principal: " . $e->getMessage();
        }

        if ($local_success) {
            replicar_consulta($sql, $types, $params);
            $_SESSION['mensaje_vacantes'] = "✅ Estado de la vacante actualizado.";
        }
    }

    // Redirigir para evitar el reenvío del formulario al recargar (Patrón PRG)
    $query_params = http_build_query(['q' => ($_GET['q'] ?? ''), 'page' => ($_GET['page'] ?? 1)]);
    header("Location: ver_vacantes.php?" . $query_params);
    exit();
}

 
// --- LÓGICA DE BÚSQUEDA Y PAGINACIÓN ---
$search_query = $_GET['q'] ?? '';
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$items_per_page = 6;
$offset = ($page - 1) * $items_per_page;
 
// Construcción de la consulta con búsqueda
$sql_base = "FROM vacantes WHERE id_empresa = ?";
$params = [$id_empresa];
$types = "i";
 
if (!empty($search_query)) {
    $sql_base .= " AND titulo LIKE ?";
    $params[] = "%" . $search_query . "%";
    $types .= "s";
}
 
// Contar total de resultados para la paginación
$sql_count = "SELECT COUNT(*) as total " . $sql_base;
$stmt_count = $conexion_local->prepare($sql_count);
$stmt_count->bind_param($types, ...$params);
$stmt_count->execute();
$total_items = $stmt_count->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_items / $items_per_page);
 
// Obtener vacantes para la página actual
$sql_select = "SELECT id, titulo, estado, fecha_publicacion, puestos_disponibles " . $sql_base . " ORDER BY fecha_publicacion DESC LIMIT ? OFFSET ?";
$params[] = $items_per_page;
$params[] = $offset;
$types .= "ii";
 
$stmt = $conexion_local->prepare($sql_select);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$resultado = $stmt->get_result();
$vacantes = $resultado->fetch_all(MYSQLI_ASSOC);
 
include 'includes/header.php';
?>
 
<main class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="display-6">Mis Vacantes Publicadas</h1>
        <a href="abrir_vacante.php" class="btn btn-gradient"><i class="bi bi-plus-lg me-2"></i>Publicar Nueva</a>
    </div>
 
    <?php if (!empty($mensaje)) : ?>
        <div class="alert <?= str_contains($mensaje, '❌') ? 'alert-danger' : 'alert-success' ?>"><?= htmlspecialchars($mensaje) ?></div>
    <?php endif; ?>
 
    <!-- Formulario de Búsqueda -->
    <div class="mb-4">
        <form method="GET" action="ver_vacantes.php">
            <div class="input-group">
                <input type="text" class="form-control" name="q" placeholder="Buscar por título de vacante..." value="<?= htmlspecialchars($search_query) ?>">
                <button class="btn btn-outline-custom" type="submit"><i class="bi bi-search"></i> Buscar</button>
            </div>
        </form>
    </div>
 
    <?php if (empty($vacantes)): ?>
        <div class="text-center p-5 border rounded bg-light">
            <?php if (!empty($search_query)): ?>
                <p class="lead">No se encontraron vacantes con el título "<?= htmlspecialchars($search_query) ?>".</p>
                <a href="ver_vacantes.php" class="btn btn-sm btn-outline-secondary">Limpiar búsqueda</a>
            <?php else: ?>
                <p class="lead">Aún no has publicado ninguna vacante.</p>
                <p>¡Empieza ahora y encuentra al candidato ideal!</p>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="list-group scrollable-list">
            <?php foreach ($vacantes as $vacante): ?>
                <div class="list-group-item list-group-item-action flex-column align-items-start">
                    <div class="d-flex w-100 justify-content-between">
                        <h5 class="mb-1"><?= htmlspecialchars($vacante['titulo']) ?></h5>
                        <small>Publicada: <?= date("d/m/Y", strtotime($vacante['fecha_publicacion'])) ?></small>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-2">
                        <div>
                            <?php if ($vacante['estado'] === 'activa'): ?>
                                <span class="badge bg-success">Activa</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Cerrada</span>
                            <?php endif; ?>
                            <span class="badge bg-info text-dark ms-2"><?= htmlspecialchars($vacante['puestos_disponibles']) ?> <?= ($vacante['puestos_disponibles'] == 1) ? 'puesto' : 'puestos' ?></span>
                        </div>
                        <div class="d-flex gap-2">
                            <a href="editar_vacante.php?id=<?= $vacante['id'] ?>" class="btn btn-sm btn-outline-custom">
                                <i class="bi bi-pencil-square me-1"></i> Editar
                            </a>
                            <form method="POST" action="ver_vacantes.php" class="d-inline">
                                <input type="hidden" name="id_vacante" value="<?= $vacante['id'] ?>">
                                <?php if ($vacante['estado'] === 'activa'): ?>
                                    <input type="hidden" name="nuevo_estado" value="cerrada">
                                    <button type="submit" name="cambiar_estado" class="btn btn-sm btn-outline-danger"><i class="bi bi-x-circle me-1"></i> Cerrar</button>
                                <?php else: ?>
                                    <input type="hidden" name="nuevo_estado" value="activa">
                                    <button type="submit" name="cambiar_estado" class="btn btn-sm btn-outline-success"><i class="bi bi-check-circle me-1"></i> Reabrir</button>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
 
        <!-- Paginación -->
        <?php if ($total_pages > 1): ?>
            <nav aria-label="Paginación de vacantes" class="mt-4">
                <ul class="pagination justify-content-center">
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?>&q=<?= urlencode($search_query) ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        <?php endif; ?>
    <?php endif; ?>
</main>
 
<?php include 'includes/footer.php'; ?>