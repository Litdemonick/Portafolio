<?php
session_start();
require_once "conexion_dbs.php";

// Proteger la página
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] !== 'publico') {
    header('Location: login.php');
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$mensaje = $_SESSION['mensaje_hv'] ?? '';
$mensaje_tipo = $_SESSION['mensaje_hv_tipo'] ?? 'info';
unset($_SESSION['mensaje_hv'], $_SESSION['mensaje_hv_tipo']);

// --- LÓGICA DE ACTUALIZACIÓN (POST) ---
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $sql_updates_exitosos = true;

    // 1. Actualizar datos de la tabla 'usuarios' (nombre, apellidos, telefono)
    $nombres = $conexion_local->real_escape_string($_POST['nombres']);
    $apellidos = $conexion_local->real_escape_string($_POST['apellidos']);
    $telefono_input = $_POST['telefono'] ?? '';
    $telefono = !empty($telefono_input) ? $conexion_local->real_escape_string($telefono_input) : 'agregar_numero';

    // Validar teléfono duplicado antes de actualizar
    if (!empty($telefono_input)) {
        $stmt_check = $conexion_local->prepare("SELECT id FROM usuarios WHERE telefono = ? AND id != ?");
        $stmt_check->bind_param("si", $telefono, $usuario_id);
        $stmt_check->execute();
        if ($stmt_check->get_result()->num_rows > 0) {
            $sql_updates_exitosos = false;
            $_SESSION['mensaje_hv'] = "❌ El número de teléfono '$telefono' ya está en uso por otro usuario.";
        }
        $stmt_check->close();
    }

    if ($sql_updates_exitosos) {
        $sql_update_usuario = "UPDATE usuarios SET nombres = '$nombres', apellidos = '$apellidos', telefono = '$telefono' WHERE id = $usuario_id";
        $resultado_replicacion = replicar_consulta($sql_update_usuario);
        if (!$resultado_replicacion['success']) {
            $sql_updates_exitosos = false;
            $_SESSION['mensaje_hv'] = "❌ Error al actualizar tus datos personales.";
        } else {
            // Actualizar el nombre en la sesión para que se refleje en el header
            $_SESSION['usuario_nombre'] = $nombres . ' ' . $apellidos;
        }
    }


    // 2. Actualizar datos de la tabla 'hvs'
    if ($sql_updates_exitosos) {
        // Lógica mejorada para asegurar "no especificado" en campos vacíos
        $nacionalidad = !empty($_POST['nacionalidad']) ? $conexion_local->real_escape_string($_POST['nacionalidad']) : 'no especificado';
        $fecha_nacimiento = !empty($_POST['fecha_nacimiento']) ? $conexion_local->real_escape_string($_POST['fecha_nacimiento']) : NULL;
        $genero = !empty($_POST['genero']) ? $conexion_local->real_escape_string($_POST['genero']) : 'no especificado';
        $estado_civil = !empty($_POST['estado_civil']) ? $conexion_local->real_escape_string($_POST['estado_civil']) : 'no especificado';
        $titulo_profesional = !empty($_POST['titulo_profesional']) ? $conexion_local->real_escape_string($_POST['titulo_profesional']) : 'no especificado';
        $resumen_profesional = !empty($_POST['resumen_profesional']) ? $conexion_local->real_escape_string($_POST['resumen_profesional']) : 'no especificado';
        $experiencia_laboral = !empty($_POST['experiencia_laboral']) ? $conexion_local->real_escape_string($_POST['experiencia_laboral']) : 'no especificado';
        $educacion = !empty($_POST['educacion']) ? $conexion_local->real_escape_string($_POST['educacion']) : 'no especificado';
        $habilidades = !empty($_POST['habilidades']) ? $conexion_local->real_escape_string($_POST['habilidades']) : 'no especificado';
        $idiomas = !empty($_POST['idiomas']) ? $conexion_local->real_escape_string($_POST['idiomas']) : 'no especificado';
        $enlace_linkedin = !empty($_POST['enlace_linkedin']) ? $conexion_local->real_escape_string($_POST['enlace_linkedin']) : 'no especificado';
        $enlace_github = !empty($_POST['enlace_github']) ? $conexion_local->real_escape_string($_POST['enlace_github']) : 'no especificado';
        $enlace_portfolio = !empty($_POST['enlace_portfolio']) ? $conexion_local->real_escape_string($_POST['enlace_portfolio']) : 'no especificado';

        $sql_update_hv = "UPDATE hvs SET 
            nacionalidad = '$nacionalidad', fecha_nacimiento = ".($fecha_nacimiento ? "'$fecha_nacimiento'" : "NULL").", genero = '$genero', estado_civil = '$estado_civil',
            titulo_profesional = '$titulo_profesional', resumen_profesional = '$resumen_profesional', experiencia_laboral = '$experiencia_laboral',
            educacion = '$educacion', habilidades = '$habilidades', idiomas = '$idiomas', enlace_linkedin = '$enlace_linkedin',
            enlace_github = '$enlace_github', enlace_portfolio = '$enlace_portfolio'
            WHERE usuario_id = $usuario_id";
        
        if (!replicar_consulta($sql_update_hv)) {
            $sql_updates_exitosos = false;
            $_SESSION['mensaje_hv'] = "❌ Error al actualizar la información de tu HV.";
        }
    }

    // 3. Manejo de archivo adjunto
    if ($sql_updates_exitosos && isset($_FILES['archivo_hv']) && $_FILES['archivo_hv']['error'] == 0) {
        $directorio_subida = 'uploads/cvs/';
        if (!is_dir($directorio_subida)) mkdir($directorio_subida, 0755, true);

        $info_archivo = pathinfo($_FILES['archivo_hv']['name']);
        $extension = strtolower($info_archivo['extension']);
        $extensiones_permitidas = ['pdf', 'doc', 'docx'];

        if (in_array($extension, $extensiones_permitidas)) {
            // Obtener nombre de archivo anterior para borrarlo
            $sql_get_old_file = "SELECT archivo_adjunto FROM hvs WHERE usuario_id = $usuario_id";
            $res_old_file = $conexion_local->query($sql_get_old_file);
            $old_file_name = $res_old_file->fetch_assoc()['archivo_adjunto'] ?? null;
            
            $nombre_archivo = 'cv_' . $usuario_id . '_' . time() . '.' . $extension;
            $ruta_destino = $directorio_subida . $nombre_archivo;

            if (move_uploaded_file($_FILES['archivo_hv']['tmp_name'], $ruta_destino)) {
                $sql_update_file = "UPDATE hvs SET archivo_adjunto = '$nombre_archivo' WHERE usuario_id = $usuario_id";
                if (replicar_consulta($sql_update_file)) {
                    // Borrar archivo antiguo si existe
                    if ($old_file_name && file_exists($directorio_subida . $old_file_name)) {
                        unlink($directorio_subida . $old_file_name);
                    }
                } else {
                    $sql_updates_exitosos = false;
                    $_SESSION['mensaje_hv'] = "❌ Error al guardar la referencia del nuevo CV.";
                }
            } else {
                $sql_updates_exitosos = false;
                $_SESSION['mensaje_hv'] = "❌ Error al mover el archivo del CV.";
            }
        } else {
            $sql_updates_exitosos = false;
            $_SESSION['mensaje_hv'] = "❌ Formato de archivo no permitido. Sube solo PDF, DOC o DOCX.";
        }
    }

    if ($sql_updates_exitosos && empty($_SESSION['mensaje_hv'])) {
        $_SESSION['mensaje_hv'] = "✅ ¡Tu Hoja de Vida ha sido actualizada con éxito!";
        $_SESSION['mensaje_hv_tipo'] = 'success';
    } else {
        $_SESSION['mensaje_hv_tipo'] = 'danger';
    }

    header('Location: mi_hv.php');
    exit();
}

// --- LÓGICA DE VISUALIZACIÓN (GET) ---
// Usamos un LEFT JOIN para obtener datos de ambas tablas.
$sql_select_all = "
    SELECT u.*, h.id as hv_id, h.nacionalidad, h.fecha_nacimiento, h.genero, h.estado_civil, h.titulo_profesional, h.resumen_profesional, h.experiencia_laboral, h.educacion, h.habilidades, h.idiomas, h.enlace_linkedin, h.enlace_github, h.enlace_portfolio, h.archivo_adjunto, h.estado, h.fecha_actualizacion
    FROM usuarios u 
    LEFT JOIN hvs h ON u.id = h.usuario_id 
    WHERE u.id = $usuario_id 
    LIMIT 1";
$resultado = $conexion_local->query($sql_select_all);
$data = $resultado->fetch_assoc();

// Si no existe una entrada en HVS, redirigir a la creación
if (is_null($data['hv_id'])) { // 'hv_id' es el alias para el id de la tabla hvs. Si es NULL, la HV no existe.
    header('Location: crear_hv.php');
    exit();
}

include 'includes/header.php';
?>

<style>
    .hv-container { max-width: 1000px; }
    .hv-card {
        background-color: var(--surface-color);
        border: 1px solid var(--border-color);
        border-radius: 0.75rem;
        margin-bottom: 1.5rem;
        overflow: hidden;
    }
    .hv-card-header {
        padding: 1rem 1.5rem;
        background-color: rgba(var(--primary-color-rgb), 0.05);
        border-bottom: 1px solid var(--border-color);
    }
    .hv-card-header h5 {
        margin: 0;
        font-weight: 600;
        color: var(--text-color);
    }
    .hv-card-body { padding: 1.5rem; }
    .data-label {
        font-weight: 600;
        color: var(--text-color-muted);
        font-size: 0.9rem;
    }
    .data-value { color: var(--text-color); }
    .edit-mode .data-value { display: none; }
    .view-mode .form-control, .view-mode .form-select { display: none; }

    /* Forzar color de texto en modo edición para tema oscuro */
    body[data-theme="dark"] .edit-mode .form-control,
    body[data-theme="dark"] .edit-mode .form-select {
        color: #FFFFFF !important;
    }
    .alert.fade-out {
        opacity: 0;
        transition: opacity 0.5s ease-out;
    }
</style>

<main class="container py-5 hv-container">
    <form method="POST" enctype="multipart/form-data" id="hv-form" class="view-mode">
        <!-- Cabecera con Foto y Botones -->
        <div class="text-center mb-4"> 
            <?php
                $foto_perfil_path_hv = (!empty($data['foto_perfil']) && $data['foto_perfil'] !== 'foto_default' && file_exists('uploads/avatars/' . $data['foto_perfil']))
                    ? 'uploads/avatars/' . htmlspecialchars($data['foto_perfil'])
                    : null;
            ?>
            <img src="<?= $foto_perfil_path_hv ? $foto_perfil_path_hv . '?t=' . time() : '#' ?>" alt="Foto de perfil" class="profile-avatar mb-3" style="<?= $foto_perfil_path_hv ? '' : 'display:none;' ?>">
            <div class="profile-avatar-default mx-auto mb-3" style="<?= $foto_perfil_path_hv ? 'display:none;' : '' ?>"><i class="bi bi-person-fill"></i></div>

            <h2><?= htmlspecialchars(($data['nombres'] ?? '') . ' ' . ($data['apellidos'] ?? '')) ?></h2>
            <p class="lead text-muted data-value"><?= ($data['titulo_profesional'] !== 'no especificado') ? htmlspecialchars($data['titulo_profesional']) : 'No especificado' ?></p>
            <input type="text" class="form-control form-control-lg text-center view-mode mb-2" name="titulo_profesional" value="<?= ($data['titulo_profesional'] !== 'no especificado') ? htmlspecialchars($data['titulo_profesional']) : '' ?>" placeholder="Tu título profesional" maxlength="255">
            <div class="mt-3">
                <button type="button" id="edit-btn" class="btn btn-outline-custom"><i class="bi bi-pencil-fill me-2"></i>Editar HV</button>
                <button type="submit" id="save-btn" class="btn btn-gradient" style="display: none;"><i class="bi bi-check-lg me-2"></i>Guardar Cambios</button>
                <button type="button" id="cancel-btn" class="btn btn-outline-secondary" style="display: none;">Cancelar</button>
            </div>
            <?php if (!empty($mensaje)) : ?>
                <div id="hv-alert-message" class="alert alert-<?= $mensaje_tipo ?> mt-3 col-md-6 mx-auto"><?= htmlspecialchars($mensaje) ?></div>
            <?php endif; ?>
        </div>

        <!-- Datos Personales -->
        <div class="hv-card">
            <div class="hv-card-header"><h5><i class="bi bi-person-badge me-2"></i>Datos Personales</h5></div>
            <div class="hv-card-body row">
                <div class="col-md-6 mb-3">
                    <div class="data-label">Nombre(s)</div>
                    <p class="data-value"><?= htmlspecialchars($data['nombres'] ?? '') ?></p> 
                    <input type="text" class="form-control" name="nombres" value="<?= htmlspecialchars($data['nombres'] ?? '') ?>" maxlength="100">
                </div>
                <div class="col-md-6 mb-3">
                    <div class="data-label">Apellido(s)</div>
                    <p class="data-value"><?= htmlspecialchars($data['apellidos'] ?? '') ?></p>
                    <input type="text" class="form-control" name="apellidos" value="<?= htmlspecialchars($data['apellidos'] ?? '') ?>" maxlength="100">
                </div>
                <div class="col-md-6 mb-3">
                    <div class="data-label">Fecha de Nacimiento</div>
                    <p class="data-value"><?= (!empty($data['fecha_nacimiento']) && $data['fecha_nacimiento'] !== 'no especificado') ? date("d/m/Y", strtotime($data['fecha_nacimiento'])) : 'No especificado' ?></p>
                    <input type="date" class="form-control" name="fecha_nacimiento" value="<?= (!empty($data['fecha_nacimiento']) && $data['fecha_nacimiento'] !== 'no especificado') ? htmlspecialchars($data['fecha_nacimiento']) : '' ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <div class="data-label">Nacionalidad</div>
                    <p class="data-value"><?= ($data['nacionalidad'] !== 'no especificado' && !empty($data['nacionalidad'])) ? htmlspecialchars($data['nacionalidad']) : 'No especificado' ?></p> 
                    <input type="text" class="form-control" name="nacionalidad" value="<?= ($data['nacionalidad'] !== 'no especificado') ? htmlspecialchars($data['nacionalidad']) : '' ?>" maxlength="100">
                </div>
                <div class="col-md-6 mb-3">
                    <div class="data-label">Género</div>
                    <p class="data-value"><?= ($data['genero'] !== 'no especificado' && !empty($data['genero'])) ? ucfirst($data['genero']) : 'No especificado' ?></p>
                    <select name="genero" class="form-select">
                        <option value="masculino" <?= ($data['genero'] ?? '') == 'masculino' ? 'selected' : '' ?>>Masculino</option>
                        <option value="femenino" <?= ($data['genero'] ?? '') == 'femenino' ? 'selected' : '' ?>>Femenino</option>
                        <option value="otro" <?= ($data['genero'] ?? '') == 'otro' ? 'selected' : '' ?>>Otro</option>
                        <option value="prefiero_no_decir" <?= ($data['genero'] ?? '') == 'prefiero_no_decir' ? 'selected' : '' ?>>Prefiero no decir</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="data-label">Estado Civil</div>
                    <p class="data-value"><?= ($data['estado_civil'] !== 'no especificado' && !empty($data['estado_civil'])) ? ucfirst(str_replace('_', ' ', $data['estado_civil'])) : 'No especificado' ?></p>
                    <select name="estado_civil" class="form-select">
                        <option value="soltero" <?= ($data['estado_civil'] ?? '') == 'soltero' ? 'selected' : '' ?>>Soltero/a</option>
                        <option value="casado" <?= ($data['estado_civil'] ?? '') == 'casado' ? 'selected' : '' ?>>Casado/a</option>
                        <option value="divorciado" <?= ($data['estado_civil'] ?? '') == 'divorciado' ? 'selected' : '' ?>>Divorciado/a</option>
                        <option value="viudo" <?= ($data['estado_civil'] ?? '') == 'viudo' ? 'selected' : '' ?>>Viudo/a</option>
                        <option value="union_libre" <?= ($data['estado_civil'] ?? '') == 'union_libre' ? 'selected' : '' ?>>Unión Libre</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Contacto y Documentos -->
        <div class="hv-card">
            <div class="hv-card-header"><h5><i class="bi bi-telephone-fill me-2"></i>Contacto y Documentos</h5></div>
            <div class="hv-card-body row">
                <div class="col-md-6 mb-3">
                    <div class="data-label">Email</div>
                    <p class="data-value"><?= htmlspecialchars($data['correo'] ?? '') ?></p>
                    <input type="email" class="form-control" value="<?= htmlspecialchars($data['correo'] ?? '') ?>" disabled>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="data-label">Teléfono</div>
                    <p class="data-value"><?= htmlspecialchars(($data['telefono'] ?? '') !== 'agregar_numero' ? $data['telefono'] : 'No especificado') ?></p> 
                    <input type="tel" class="form-control" name="telefono" value="<?= htmlspecialchars(($data['telefono'] ?? '') !== 'agregar_numero' ? $data['telefono'] : '') ?>" maxlength="20">
                </div>
                <div class="col-md-6 mb-3">
                    <div class="data-label">Documento</div>
                    <p class="data-value"><?= ucfirst($data['tipo_documento'] ?? '') . ': ' . htmlspecialchars($data['numero_documento'] ?? '') ?></p>
                    <input type="text" class="form-control" value="<?= ucfirst($data['tipo_documento'] ?? '') . ': ' . htmlspecialchars($data['numero_documento'] ?? '') ?>" disabled>
                </div>
            </div>
        </div>

        <!-- Resumen Profesional -->
        <div class="hv-card">
            <div class="hv-card-header"><h5><i class="bi bi-person-lines-fill me-2"></i>Resumen Profesional</h5></div>
            <div class="hv-card-body">
                <p class="data-value"><?= ($data['resumen_profesional'] !== 'no especificado' && !empty($data['resumen_profesional'])) ? nl2br(htmlspecialchars($data['resumen_profesional'])) : 'No especificado' ?></p> 
                <textarea name="resumen_profesional" class="form-control" rows="5" maxlength="2000"><?= ($data['resumen_profesional'] !== 'no especificado' && !empty($data['resumen_profesional'])) ? htmlspecialchars($data['resumen_profesional']) : '' ?></textarea>
            </div>
        </div>

        <!-- Experiencia y Educación -->
        <div class="row">
            <div class="col-md-6">
                <div class="hv-card">
                    <div class="hv-card-header"><h5><i class="bi bi-briefcase-fill me-2"></i>Experiencia Laboral</h5></div>
                    <div class="hv-card-body">
                        <p class="data-value"><?= ($data['experiencia_laboral'] !== 'no especificado' && !empty($data['experiencia_laboral'])) ? nl2br(htmlspecialchars($data['experiencia_laboral'])) : 'No especificado' ?></p> 
                        <textarea name="experiencia_laboral" class="form-control" rows="8" maxlength="4000"><?= ($data['experiencia_laboral'] !== 'no especificado' && !empty($data['experiencia_laboral'])) ? htmlspecialchars($data['experiencia_laboral']) : '' ?></textarea>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="hv-card">
                    <div class="hv-card-header"><h5><i class="bi bi-mortarboard-fill me-2"></i>Educación</h5></div>
                    <div class="hv-card-body">
                        <p class="data-value"><?= ($data['educacion'] !== 'no especificado' && !empty($data['educacion'])) ? nl2br(htmlspecialchars($data['educacion'])) : 'No especificado' ?></p> 
                        <textarea name="educacion" class="form-control" rows="8" maxlength="4000"><?= ($data['educacion'] !== 'no especificado' && !empty($data['educacion'])) ? htmlspecialchars($data['educacion']) : '' ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <!-- Habilidades e Idiomas -->
        <div class="hv-card">
            <div class="hv-card-header"><h5><i class="bi bi-gear-wide-connected me-2"></i>Habilidades e Idiomas</h5></div>
            <div class="hv-card-body">
                <div class="mb-3">
                    <div class="data-label">Habilidades Clave</div>
                    <p class="data-value"><?= ($data['habilidades'] !== 'no especificado' && !empty($data['habilidades'])) ? htmlspecialchars($data['habilidades']) : 'No especificado' ?></p> 
                    <textarea name="habilidades" class="form-control" rows="3" maxlength="1000"><?= ($data['habilidades'] !== 'no especificado' && !empty($data['habilidades'])) ? htmlspecialchars($data['habilidades']) : '' ?></textarea>
                </div>
                <div>
                    <div class="data-label">Idiomas</div>
                    <p class="data-value"><?= ($data['idiomas'] !== 'no especificado' && !empty($data['idiomas'])) ? htmlspecialchars($data['idiomas']) : 'No especificado' ?></p> 
                    <input type="text" class="form-control" name="idiomas" value="<?= ($data['idiomas'] !== 'no especificado' && !empty($data['idiomas'])) ? htmlspecialchars($data['idiomas']) : '' ?>" maxlength="255">
                </div>
            </div>
        </div>

        <!-- Enlaces y Archivo Adjunto -->
        <div class="hv-card">
            <div class="hv-card-header"><h5><i class="bi bi-cloud-arrow-up-fill me-2"></i>Presencia Online y Archivos</h5></div>
            <div class="hv-card-body">
                <div class="row">
                    <div class="col-md-4 mb-3"><div class="data-label">LinkedIn</div><p class="data-value"><?= ($data['enlace_linkedin'] !== 'no especificado' && !empty($data['enlace_linkedin'])) ? '<a href="'.htmlspecialchars($data['enlace_linkedin']).'" target="_blank">Ver Perfil</a>' : 'No especificado' ?></p><input type="url" class="form-control" name="enlace_linkedin" value="<?= ($data['enlace_linkedin'] !== 'no especificado') ? htmlspecialchars($data['enlace_linkedin']) : '' ?>" maxlength="255"></div>
                    <div class="col-md-4 mb-3"><div class="data-label">GitHub</div><p class="data-value"><?= ($data['enlace_github'] !== 'no especificado' && !empty($data['enlace_github'])) ? '<a href="'.htmlspecialchars($data['enlace_github']).'" target="_blank">Ver Perfil</a>' : 'No especificado' ?></p><input type="url" class="form-control" name="enlace_github" value="<?= ($data['enlace_github'] !== 'no especificado') ? htmlspecialchars($data['enlace_github']) : '' ?>" maxlength="255"></div>
                    <div class="col-md-4 mb-3"><div class="data-label">Portfolio</div><p class="data-value"><?= ($data['enlace_portfolio'] !== 'no especificado' && !empty($data['enlace_portfolio'])) ? '<a href="'.htmlspecialchars($data['enlace_portfolio']).'" target="_blank">Ver Sitio</a>' : 'No especificado' ?></p><input type="url" class="form-control" name="enlace_portfolio" value="<?= ($data['enlace_portfolio'] !== 'no especificado') ? htmlspecialchars($data['enlace_portfolio']) : '' ?>" maxlength="255"></div>
                </div>
                <hr>
                <div class="data-label">Adjuntar CV (PDF, DOC, DOCX)</div>
                <div class="data-value">
                    <?php if (!empty($data['archivo_adjunto']) && $data['archivo_adjunto'] !== 'no especificado'): ?>
                        <a href="uploads/cvs/<?= htmlspecialchars($data['archivo_adjunto']) ?>" target="_blank" class="btn btn-sm btn-outline-custom"><i class="bi bi-download me-2"></i>Descargar CV Actual</a>
                    <?php else: ?>
                        <p>No has subido ningún archivo.</p>
                    <?php endif; ?>
                </div>
                <input type="file" class="form-control view-mode" name="archivo_hv" accept=".pdf,.doc,.docx">
                <div class="form-text view-mode">Sube un nuevo archivo para reemplazar el actual.</div>
            </div>
        </div>

        <div class="text-center text-muted mt-4">
            <small>Última modificación: <?= date("d/m/Y H:i", strtotime($data['fecha_actualizacion'])) ?></small>
        </div>
    </form>
</main>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('hv-form');
    const editBtn = document.getElementById('edit-btn');
    const saveBtn = document.getElementById('save-btn');
    const cancelBtn = document.getElementById('cancel-btn');

    editBtn.addEventListener('click', () => {
        form.classList.remove('view-mode');
        form.classList.add('edit-mode');
        editBtn.style.display = 'none';
        saveBtn.style.display = 'inline-block';
        cancelBtn.style.display = 'inline-block';
    });

    cancelBtn.addEventListener('click', () => {
        form.classList.remove('edit-mode');
        form.classList.add('view-mode');
        editBtn.style.display = 'inline-block';
        saveBtn.style.display = 'none';
        cancelBtn.style.display = 'none';
        // Opcional: resetear el formulario a sus valores originales si se cancela
        form.reset();
    });

    // Hacer que el mensaje de alerta desaparezca después de 5 segundos
    const alertMessage = document.getElementById('hv-alert-message');
    if (alertMessage) {
        setTimeout(() => {
            alertMessage.classList.add('fade-out');
            // Opcional: remover el elemento del DOM después de la transición
            setTimeout(() => alertMessage.remove(), 500);
        }, 5000); // 5000 milisegundos = 5 segundos
    }
});
</script>

<?php include 'includes/footer.php'; ?>