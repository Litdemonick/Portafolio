<?php
session_start();
require_once "conexion_dbs.php";

// --- 1. SEGURIDAD Y OBTENCIÓN DE DATOS ---
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] !== 'empresa') {
    header("Location: login.php");
    exit();
}

$id_empresa = $_SESSION['usuario_id'];
$id_postulacion = filter_input(INPUT_GET, 'id_postulacion', FILTER_VALIDATE_INT);

if (!$id_postulacion) {
    header("Location: revision_postulacion.php");
    exit();
}

// --- 2. LÓGICA DE ACCIONES (ACEPTAR/RECHAZAR) ---
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['accion_candidato'])) {
    $accion = $_POST['accion_candidato'];
    $nuevo_estado = '';

    if ($accion === 'aceptar') {
        $nuevo_estado = 'aceptado';
    } elseif ($accion === 'rechazar') {
        $nuevo_estado = 'rechazado';
    }

    if (!empty($nuevo_estado)) {
        // Iniciar transacción para asegurar consistencia
        $conexion_local->begin_transaction();
        try {
            // 1. Preparar y ejecutar en la base de datos LOCAL (Windows)
            $stmt_local = $conexion_local->prepare("UPDATE postulaciones SET estado = ?, fecha_decision = NOW() WHERE id = ?");
            $stmt_local->bind_param("si", $nuevo_estado, $id_postulacion);
            if (!$stmt_local->execute()) {
                throw new Exception("Error al actualizar en la base de datos local: " . $stmt_local->error);
            }

            // 2. Preparar y ejecutar en la base de datos REMOTA (Ubuntu)
            $stmt_remoto = $conexion_remota->prepare("UPDATE postulaciones SET estado = ?, fecha_decision = NOW() WHERE id = ?");
            $stmt_remoto->bind_param("si", $nuevo_estado, $id_postulacion);
            if (!$stmt_remoto->execute()) {
                throw new Exception("Error al actualizar en la base de datos remota: " . $stmt_remoto->error);
            }

            // --- LÓGICA PARA ACTUALIZAR PUESTOS DISPONIBLES Y CERRAR VACANTE ---
            if ($nuevo_estado === 'aceptado') {
                // Si se acepta, se resta un puesto disponible
                $sql_update_puestos = "UPDATE vacantes SET puestos_disponibles = puestos_disponibles - 1 WHERE id = (SELECT id_vacante FROM postulaciones WHERE id = ?) AND puestos_disponibles > 0";
                
                $stmt_vacante_local = $conexion_local->prepare($sql_update_puestos);
                $stmt_vacante_local->bind_param("i", $id_postulacion);
                $stmt_vacante_local->execute();

                $stmt_vacante_remoto = $conexion_remota->prepare($sql_update_puestos);
                $stmt_vacante_remoto->bind_param("i", $id_postulacion);
                $stmt_vacante_remoto->execute();

                // --- NUEVA LÓGICA: CERRAR VACANTE SI LLEGA A CERO ---
                // Obtenemos el ID de la vacante desde la postulación
                $stmt_get_vacante = $conexion_local->prepare("SELECT id, puestos_disponibles FROM vacantes WHERE id = (SELECT id_vacante FROM postulaciones WHERE id = ?)");
                $stmt_get_vacante->bind_param("i", $id_postulacion);
                $stmt_get_vacante->execute();
                $vacante_actual = $stmt_get_vacante->get_result()->fetch_assoc();

                if ($vacante_actual && $vacante_actual['puestos_disponibles'] <= 0) {
                    // --- CORRECCIÓN: Ejecutar en local y luego replicar ---
                    $sql_cerrar_vacante = "UPDATE vacantes SET estado = 'cerrada' WHERE id = ?";
                    $params_cerrar = [$vacante_actual['id']];
                    
                    $stmt_cerrar_local = $conexion_local->prepare($sql_cerrar_vacante);
                    $stmt_cerrar_local->bind_param("i", ...$params_cerrar);
                    $stmt_cerrar_local->execute();
                    replicar_consulta($sql_cerrar_vacante, "i", $params_cerrar);
                }
            }

            // 3. Confirmar transacción en AMBAS bases de datos
            $conexion_local->commit();
            $conexion_remota->commit(); // Es importante confirmar también en la remota si se usa transacción allí

            $_SESSION['mensaje_postulaciones'] = "✅ Acción sobre el candidato registrada con éxito.";
            
            // Actualizar el estado en la variable local para reflejar el cambio inmediatamente
            $candidato['estado'] = $nuevo_estado;
        } catch (Exception $e) {
            $conexion_local->rollback();
            $_SESSION['mensaje_postulaciones'] = "❌ Error al procesar la acción: " . $e->getMessage();
        } finally {
            $conexion_remota->rollback(); // Asegurarse de revertir la remota en caso de fallo
        }
        header("Location: revision_postulacion.php");
        exit();
    }
}

// --- 3. OBTENER DATOS COMPLETOS DEL CANDIDATO ---
// Consulta segura que verifica que la postulación pertenece a la empresa logueada
$sql_candidato = "
    SELECT 
        p.id as id_postulacion, 
        p.estado as estado_postulacion,
        v.titulo as titulo_vacante,
        u.nombres, u.apellidos, u.correo, u.telefono, u.foto_perfil,
        h.nacionalidad, 
        h.fecha_nacimiento, 
        h.genero, 
        h.estado_civil, 
        h.titulo_profesional, 
        h.resumen_profesional, 
        h.experiencia_laboral, 
        h.educacion, 
        h.habilidades, 
        h.idiomas, 
        h.enlace_linkedin, h.enlace_github, h.enlace_portfolio, 
        h.archivo_adjunto
    FROM postulaciones p
    JOIN vacantes v ON p.id_vacante = v.id
    JOIN usuarios u ON p.id_usuario = u.id
    JOIN hvs h ON p.id_hv = h.id
    WHERE p.id = ? AND v.id_empresa = ?
";
$stmt = $conexion_local->prepare($sql_candidato);
$stmt->bind_param("ii", $id_postulacion, $id_empresa);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    // Si no hay resultados, la postulación no existe o no pertenece a esta empresa
    $_SESSION['mensaje_postulaciones'] = "❌ Acceso denegado o postulación no encontrada.";
    header("Location: revision_postulacion.php");
    exit();
}
$candidato = $resultado->fetch_assoc();
// Renombramos la clave para usarla de forma clara en el HTML
$candidato['estado'] = $candidato['estado_postulacion'];


include 'includes/header.php';
?>

<style>
    .hv-container { max-width: 1140px; } /* Más centrado */
    .hv-card {
        background-color: var(--surface-color);
        border: 1px solid var(--border-color);
        border-radius: 0.75rem;
        margin-bottom: 1.5rem;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    }
    .hv-card-header {
        padding: 1rem 1.5rem;
        background-color: rgba(var(--primary-color-rgb), 0.05);
        border-bottom: 1px solid var(--border-color);
    }
    .hv-card-header h5 { 
        margin: 0; 
        font-weight: 600; 
        color: var(--text-color); 
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }
    .hv-card-header h5 i { color: var(--primary-color); }
    .hv-card-body { padding: 1.5rem; }
    .data-label { 
        font-weight: 500; 
        color: var(--text-color-muted); 
        font-size: 0.85rem; 
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 0.25rem;
    }
    .data-value { color: var(--text-color); }
    .profile-header { 
        text-align: center; padding: 2.5rem; 
        background: linear-gradient(135deg, var(--surface-color) 0%, var(--surface-color-secondary) 100%);
        border-radius: 1rem; 
    }
    .profile-avatar { width: 120px; height: 120px; object-fit: cover; border-radius: 50%; border: 5px solid var(--primary-color); box-shadow: 0 0 20px rgba(var(--primary-color-rgb), 0.4); }
    .profile-avatar-default { width: 120px; height: 120px; border-radius: 50%; background-color: var(--border-color); color: var(--text-color-muted); display: flex; align-items: center; justify-content: center; font-size: 5rem; }
    .action-card { position: sticky; top: 100px; }
</style>

<main class="container py-5 hv-container">
    <div class="row g-4">
        <!-- Columna Izquierda: Información del Candidato -->
        <div class="col-lg-8">
            <div class="profile-header mb-4">
                <?php
                    $foto_candidato = (!empty($candidato['foto_perfil']) && $candidato['foto_perfil'] !== 'foto_default' && file_exists('uploads/avatars/' . $candidato['foto_perfil']))
                        ? 'uploads/avatars/' . htmlspecialchars($candidato['foto_perfil'])
                        : null;
                ?>
                <?php if ($foto_candidato): ?>
                    <img src="<?= $foto_candidato ?>" alt="Foto de perfil" class="profile-avatar mx-auto mb-3">
                <?php else: ?>
                    <div class="profile-avatar-default mx-auto mb-3"><i class="bi bi-person-fill"></i></div>
                <?php endif; ?>
                <h2 class="mb-1"><?= htmlspecialchars($candidato['nombres'] . ' ' . $candidato['apellidos']) ?></h2>
                <p class="lead text-muted"><?= htmlspecialchars($candidato['titulo_profesional']) ?></p>
                <p class="mb-0">Postulado para: <strong><?= htmlspecialchars($candidato['titulo_vacante']) ?></strong></p>
            </div>

            <!-- Datos Personales -->
            <div class="hv-card">
                <div class="hv-card-header"><h5><i class="bi bi-person-badge"></i>Datos Personales</h5></div>
                <div class="hv-card-body row">
                    <div class="col-md-6 mb-3"><div class="data-label">Nacionalidad</div><p class="data-value"><?= htmlspecialchars($candidato['nacionalidad']) ?></p></div>
                    <div class="col-md-6 mb-3"><div class="data-label">Fecha de Nacimiento</div><p class="data-value"><?= !empty($candidato['fecha_nacimiento']) ? date("d/m/Y", strtotime($candidato['fecha_nacimiento'])) : 'No especificado' ?></p></div>
                    <div class="col-md-6 mb-3"><div class="data-label">Género</div><p class="data-value"><?= ucfirst($candidato['genero']) ?></p></div>
                    <div class="col-md-6 mb-3"><div class="data-label">Estado Civil</div><p class="data-value"><?= ucfirst(str_replace('_', ' ', $candidato['estado_civil'])) ?></p></div>
                </div>
            </div>

            <!-- Contacto -->
            <div class="hv-card">
                <div class="hv-card-header"><h5><i class="bi bi-telephone-fill"></i>Contacto</h5></div>
                <div class="hv-card-body row">
                    <div class="col-md-6 mb-3"><div class="data-label">Email</div><p class="data-value"><?= htmlspecialchars($candidato['correo']) ?></p></div>
                    <div class="col-md-6 mb-3"><div class="data-label">Teléfono</div><p class="data-value"><?= htmlspecialchars($candidato['telefono'] !== 'agregar_numero' ? $candidato['telefono'] : 'No especificado') ?></p></div>
                </div>
            </div>

            <!-- Resumen Profesional -->
            <div class="hv-card">
                <div class="hv-card-header"><h5><i class="bi bi-person-lines-fill"></i>Resumen Profesional</h5></div>
                <div class="hv-card-body"><p class="data-value"><?= nl2br(htmlspecialchars($candidato['resumen_profesional'])) ?></p></div>
            </div>

            <!-- Experiencia y Educación -->
            <div class="row">
                <div class="col-md-6">
                    <div class="hv-card">
                        <div class="hv-card-header"><h5><i class="bi bi-briefcase-fill"></i>Experiencia Laboral</h5></div>
                        <div class="hv-card-body"><p class="data-value"><?= nl2br(htmlspecialchars($candidato['experiencia_laboral'])) ?></p></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="hv-card">
                        <div class="hv-card-header"><h5><i class="bi bi-mortarboard-fill"></i>Educación</h5></div>
                        <div class="hv-card-body"><p class="data-value"><?= nl2br(htmlspecialchars($candidato['educacion'])) ?></p></div>
                    </div>
                </div>
            </div>

            <!-- Habilidades e Idiomas -->
            <div class="hv-card">
                <div class="hv-card-header"><h5><i class="bi bi-gear-wide-connected"></i>Habilidades e Idiomas</h5></div>
                <div class="hv-card-body">
                    <div class="mb-3"><div class="data-label">Habilidades Clave</div><p class="data-value"><?= htmlspecialchars($candidato['habilidades']) ?></p></div>
                    <div><div class="data-label">Idiomas</div><p class="data-value"><?= htmlspecialchars($candidato['idiomas']) ?></p></div>
                </div>
            </div>

            <!-- Enlaces y Archivo Adjunto -->
            <div class="hv-card">
                <div class="hv-card-header"><h5><i class="bi bi-cloud-arrow-up-fill"></i>Presencia Online y Archivos</h5></div>
                <div class="hv-card-body">
                    <div class="row">
                        <div class="col-md-4 mb-3"><div class="data-label">LinkedIn</div><p class="data-value"><?= ($candidato['enlace_linkedin'] !== 'no especificado' && !empty($candidato['enlace_linkedin'])) ? '<a href="'.htmlspecialchars($candidato['enlace_linkedin']).'" target="_blank">Ver Perfil</a>' : 'No especificado' ?></p></div>
                        <div class="col-md-4 mb-3"><div class="data-label">GitHub</div><p class="data-value"><?= ($candidato['enlace_github'] !== 'no especificado' && !empty($candidato['enlace_github'])) ? '<a href="'.htmlspecialchars($candidato['enlace_github']).'" target="_blank">Ver Perfil</a>' : 'No especificado' ?></p></div>
                        <div class="col-md-4 mb-3"><div class="data-label">Portfolio</div><p class="data-value"><?= ($candidato['enlace_portfolio'] !== 'no especificado' && !empty($candidato['enlace_portfolio'])) ? '<a href="'.htmlspecialchars($candidato['enlace_portfolio']).'" target="_blank">Ver Sitio</a>' : 'No especificado' ?></p></div>
                    </div>
                    <hr>
                    <div class="data-label">CV Adjunto</div>
                    <div class="data-value">
                        <?php if (!empty($candidato['archivo_adjunto']) && $candidato['archivo_adjunto'] !== 'no especificado'): ?>
                            <a href="uploads/cvs/<?= htmlspecialchars($candidato['archivo_adjunto']) ?>" target="_blank" class="btn btn-sm btn-outline-custom"><i class="bi bi-download me-2"></i>Descargar CV</a>
                        <?php else: ?>
                            <p>No se adjuntó archivo.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Columna Derecha: Acciones -->
        <div class="col-lg-4">
            <div class="action-card">
                <div class="hv-card">
                    <div class="hv-card-header"><h5><i class="bi bi-check2-circle"></i>Tomar una Decisión</h5></div>
                    <div class="hv-card-body">
                        <?php if (isset($candidato['estado']) && $candidato['estado'] === 'recibido'): ?>
                            <p class="text-muted small">Evalúa el perfil del candidato y decide si avanza en el proceso de selección o si no es el adecuado para esta vacante.</p>
                            <form method="POST" action="ver_candidato.php?id_postulacion=<?= $id_postulacion ?>" class="mt-4">
                                <div class="d-grid gap-2">
                                    <button type="submit" name="accion_candidato" value="aceptar" class="btn btn-success btn-lg">
                                        <i class="bi bi-hand-thumbs-up-fill me-2"></i>Aceptar / Avanzar
                                    </button>
                                    <button type="submit" name="accion_candidato" value="rechazar" class="btn btn-danger btn-lg mt-2">
                                        <i class="bi bi-hand-thumbs-down-fill me-2"></i>Rechazar
                                    </button>
                                </div>
                            </form>
                        <?php else: ?>
                            <div class="alert alert-info text-center">
                                <p class="lead">Ya se ha tomado una decisión sobre este candidato.</p>
                                <p class="mb-0">Estado actual: <strong class="text-capitalize"><?= htmlspecialchars($candidato['estado']) ?></strong></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?>
