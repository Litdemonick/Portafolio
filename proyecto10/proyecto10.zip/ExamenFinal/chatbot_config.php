<?php
// ========================================
// ARCHIVO: chatbot_config.php
// Descripción: Lógica y respuestas del Chatbot
// ========================================

/**
 * Normaliza un string: lo convierte a minúsculas, quita tildes y signos de puntuación.
 * Esto permite una comparación de texto mucho más flexible.
 * @param string $str El string a normalizar.
 * @return string El string normalizado.
 */
function normalize_string($str) {
    $str = strtolower($str);
    $unwanted_array = [
        'á'=>'a', 'é'=>'e', 'í'=>'i', 'ó'=>'o', 'ú'=>'u', 'ü'=>'u', 'ñ'=>'n',
        'à'=>'a', 'è'=>'e', 'ì'=>'i', 'ò'=>'o', 'ù'=>'u'
    ];
    $str = strtr($str, $unwanted_array);
    // Elimina solo signos de puntuación comunes, pero conserva caracteres como '/'
    $str = preg_replace('/[¿?!¡,.;:"()\[\]]/u', '', $str);
    return trim($str);
}

function get_chatbot_response($message, $conexion_local, $user_info) {
    $normalized_message = normalize_string($message);
    $response = "";
    $rol = $user_info['rol'] ?? 'invitado';
    $nombre_usuario = htmlspecialchars($user_info['nombre'] ?? 'Visitante');

    // --- Lógica de Coincidencia Flexible (Inteligencia Mejorada) ---
    $preguntas_conocidas = [
        "hola" => "saludo",
        "qué es jobs360" => "sobre_sitio",
        "cómo funciona" => "como_funciona",
        "cómo creo mi hv" => "crear_hv",
        "cómo publico una vacante" => "publicar_vacante",
        "cuántas vacantes hay" => "contar_vacantes",
        "mi información" => "mi_informacion",
        "ayuda" => "ayuda",
        "costo de peaje" => "info_peaje",
        "facturación" => "facturacion",
        "generar factura" => "facturacion",
        "gracias" => "despedida",
        "adios" => "despedida",
        "ver mis postulaciones" => "ver_postulaciones"
    ];

    $mejor_coincidencia = null;
    $max_similitud = 0;

    foreach ($preguntas_conocidas as $pregunta => $intencion) {
        // Comparamos el mensaje normalizado con la pregunta conocida (que ya está normalizada)
        similar_text($normalized_message, $pregunta, $similitud);
        if ($similitud > $max_similitud) {
            $max_similitud = $similitud;
            $mejor_coincidencia = $intencion;
        }
    }

    // --- Lógica de Coincidencia por Patrón (para preguntas dinámicas) ---
    // SE PRIORIZAN LOS PATRONES COMPLEJOS ANTES QUE LAS COINCIDENCIAS SIMPLES
    // Patrón mejorado: busca con comillas y, si no, sin comillas.
    if (preg_match('/(vistas|visitas|interacciones) de la vacante ([\'"])(.+?)\2/i', $normalized_message, $matches)) {
        // Caso 1: El título está entre comillas. Ej: vistas de la vacante "Mi Vacante"
        $intencion = 'vistas_vacante';
        $titulo_vacante_extraido = $matches[3];
    } elseif (preg_match('/(vistas|visitas|interacciones) de la vacante (.+)/i', $normalized_message, $matches)) {
        // Caso 2: El título no tiene comillas. Toma todo lo que sigue.
        $intencion = 'vistas_vacante';
        $titulo_vacante_extraido = trim($matches[2]);
    } 
    // NUEVA LÓGICA PARA BUSCAR VACANTES (MEJORADA Y PRIORIZADA)
    elseif (preg_match('/(busca|dime|ver|mostrar|quiero|necesito) (vacantes|puestos|empleos|trabajos)/i', $normalized_message, $matches)) {
        $intencion = 'buscar_vacantes';
        $keyword = '';
        $location = '';

        // Extraer palabra clave (ej: "de diseñador", "como analista")
        if(preg_match('/(de|como) ([\w\s-]+)/i', $message, $keyword_matches)) {
            $keyword = trim($keyword_matches[2]);
            // Quitar la ubicación de la palabra clave si también está presente
            if(preg_match('/en ([\w\s-]+)/i', $keyword, $loc_inner_match)) {
                $keyword = str_replace($loc_inner_match[0], '', $keyword);
            }
        }

        // Extraer ubicación (ej: "en panamá", "para david")
        if(preg_match('/en ([\w\s\p{L}-]+)/u', $normalized_message, $location_matches)) {
            $location = trim($location_matches[1]);
        }
        
        // Limpiar keyword por si acaso
        $keyword = trim(str_replace([' en ', ' para '], ' ', $keyword));

    } else {
        // Si no coincide ningún patrón complejo, usamos la mejor coincidencia por similitud
        $intencion = ($max_similitud > 70) ? $mejor_coincidencia : null;
    }

    // --- Lógica de Respuestas ---
    if ($intencion === 'saludo' || in_array($normalized_message, ['hola', 'buenos dias', 'buenas tardes', 'buenas noches'])) {
        if ($rol === 'invitado') {
            $response = "¡Hola! 👋 Soy tu asistente virtual de Jobs360. ¿En qué puedo ayudarte hoy?";
        } elseif ($rol === 'empresa') {
            $response = "¡Hola, {$nombre_usuario}! Como representante de empresa, estoy aquí para ayudarte a gestionar tus vacantes y encontrar el mejor talento. ¿Qué necesitas?";
        } else {
            $response = "¡Hola, {$nombre_usuario}! 👋 Soy tu asistente virtual. ¿En qué puedo ayudarte?";
        }
    }
    // Comando de Ayuda
    elseif ($intencion === 'ayuda' || in_array($normalized_message, ['help', 'comandos'])) {
        if ($rol === 'empresa') {
            $response = "¡Claro! Como empresa, puedes preguntarme sobre:\n\n" .
                        "• '¿Cómo publico una vacante?'\n" .
                        "• \"Vistas de la vacante 'nombre'\"\n" .
                        "• 'Costo de peaje' o 'Facturación'\n" .
                        "• 'Mi información' para ver datos de tu empresa.";
        } elseif ($rol === 'publico') {
            $response = "¡Hola! Como candidato, puedes consultarme sobre:\n\n" .
                        "• '¿Cómo creo mi HV?'\n" .
                        "• 'Busca empleos de [puesto] en [lugar]'\n" .
                        "• 'Ver mis postulaciones'\n" .
                        "• 'Mi información' para ver tus datos.\n" .
                        "• '¿Cuántas vacantes hay?'";
        } else {
            $response = "¡Hola! Puedes preguntarme:\n'¿Qué es Jobs360?' o '¿Cómo funciona?'.";
        }
        $response .= "\n\nJobs360.";
    }
    // Preguntas sobre el sitio
    elseif ($intencion === 'sobre_sitio') {
        $response = "Jobs360 es una plataforma innovadora que conecta a los mejores talentos con las empresas más destacadas. Nuestro objetivo es facilitar el proceso de búsqueda de empleo y contratación.";
    }
    elseif ($intencion === 'como_funciona') {
        $response = "Es muy fácil:\n1. Los candidatos crean su Hoja de Vida (HV).\n2. Las empresas publican sus vacantes.\n3. Los candidatos se postulan a las vacantes de su interés.\n¡Nosotros conectamos las oportunidades con el talento!";
    }
    // Preguntas de Candidatos
    elseif ($intencion === 'crear_hv') {
        if ($rol === 'publico' || $rol === 'invitado') {
            $response = "¡Claro, {$nombre_usuario}! Para gestionar tu Hoja de Vida, puedes ir directamente desde aquí o desde el menú de tu perfil seleccionando 'Mi HV'.\n\n" .
                        "[Ir a Mi HV](mi_hv.php)";
        } else {
            $response = "Esta opción es para candidatos. Como empresa, puedes publicar vacantes.";
        }
    }
    elseif ($intencion === 'ver_postulaciones') {
        if ($rol === 'publico') {
            $response = "¡Por supuesto! Puedes ver el estado de todas tus postulaciones en la sección 'Mis Postulaciones'.\n\n" .
                        "[Ver Mis Postulaciones](mis_postulaciones.php)";
        } else {
            $response = "Esta opción es para candidatos. Como empresa, puedes revisar las postulaciones que has recibido.";
        }
    }
    elseif (str_contains($normalized_message, 'como busco empleo')) {
        if ($rol === 'publico' || $rol === 'invitado') {
            $response = "¡Excelente pregunta! Puedes buscar empleos usando la barra de búsqueda principal o explorar todas las oportunidades en la página de búsqueda. Además, ¡también puedes buscar empresas directamente!\n\n" .
                        "Elige qué te gustaría hacer:\n\n" .
                        "[Ir a Buscar Empleos](buscar.php)\n" .
                        "[Ir a Buscar Empresas](buscar_empresas.php)";
        } else {
            $response = "Como empresa, tu rol es publicar empleos, no buscarlos. ¡Los candidatos te encontrarán!";
        }
    }
    // Preguntas de Empresas
    elseif ($intencion === 'publicar_vacante') {
        if ($rol === 'empresa') {
            $response = "¡Hola, {$nombre_usuario}! Para publicar una nueva vacante, simplemente ve a tu menú de perfil y haz clic en 'Abrir Vacante', o usa este enlace directo:\n\n" .
                        "[Publicar Nueva Vacante](abrir_vacante.php)";
        } else {
            $response = "Esta función es para empresas. Si representas a una, puedes registrar una cuenta de empresa.";
        }
    }
    // Pregunta específica de empresa sobre su información
    elseif ($rol === 'empresa' && ($intencion === 'mi_informacion')) {
        $response = "Eres un representante de la empresa '{$nombre_usuario}'. Tu rol en nuestra plataforma es '{$rol}'. Desde aquí puedes gestionar tus vacantes y revisar postulaciones.\n\n" .
                    "Puedes ver o editar los datos de tu perfil y de la empresa aquí:\n\n" .
                    "[Ir a Mi Perfil](perfil.php)";
    }
    // Pregunta específica de candidato sobre su información
    elseif ($rol === 'publico' && ($intencion === 'mi_informacion')) {
        $response = "Eres {$nombre_usuario}, un valioso candidato en nuestra plataforma. Tu rol es '{$rol}'. Puedes buscar empleos, gestionar tu HV y ver tus postulaciones.\n\n" .
                    "Puedes ver o editar tus datos personales aquí:\n\n" .
                    "[Ir a Mi Perfil](perfil.php)";
    }
    // --- PREGUNTAS DE EMPRESAS (VISTAS, PEAJE, FACTURACIÓN) ---
    elseif ($intencion === 'vistas_vacante') {
        if ($rol !== 'empresa') {
            $response = "Lo siento, esta función solo está disponible para empresas.";
        } else {
            // --- MEJORA: Usar LIKE para una búsqueda de título más flexible ---
            $search_term = "%" . $titulo_vacante_extraido . "%";
            $stmt = $conexion_local->prepare("SELECT v.id, v.titulo FROM vacantes v WHERE v.titulo LIKE ? AND v.id_empresa = ? LIMIT 1");
            $stmt->bind_param("si", $search_term, $user_info['id']);
            $stmt->execute();
            $vacante_res = $stmt->get_result();

            if ($vacante_res->num_rows > 0) {
                $vacante_encontrada = $vacante_res->fetch_assoc();
                $id_vacante = $vacante_encontrada['id'];
                $stmt_vistas = $conexion_local->prepare("SELECT COUNT(*) as total FROM vacante_vistas WHERE id_vacante = ?");
                $stmt_vistas->bind_param("i", $id_vacante);
                $stmt_vistas->execute();
                $total_vistas = $stmt_vistas->get_result()->fetch_assoc()['total'];
                $response = "La vacante \"" . htmlspecialchars($vacante_encontrada['titulo']) . "\" ha tenido un total de **{$total_vistas} interacciones** (vistas).";
            } else {
                $response = "No encontré una vacante con el título \"{$titulo_vacante_extraido}\" que te pertenezca. Asegúrate de escribir el título exacto entre comillas.";
            }
        }
    }
    elseif ($intencion === 'info_peaje') {
        if ($rol === 'empresa') {
            $response = "Nuestro modelo de 'peaje' se basa en la interacción. Cada vez que un candidato ve el detalle de una de tus vacantes, se contabiliza una vista. Esto nos permite calcular un costo justo basado en la visibilidad que te proporcionamos. Puedes ver el detalle y generar una factura preguntándome por 'facturación'.";
        } else {
            $response = "El 'costo de peaje' es información relevante para las cuentas de empresa que publican vacantes.";
        }
    }
    elseif ($intencion === 'facturacion') {
        if ($rol !== 'empresa') {
            $response = "Lo siento, la sección de facturación solo está disponible para empresas.";
        } else {
            $response = "¡Claro! Puedes consultar el detalle de tus interacciones, ver el costo de peaje y generar una factura en nuestra sección de facturación.\n\n" .
                        "[Ir a Facturación](facturacion.php?id_empresa={$user_info['id']})";
        }
    }
    // --- NUEVA LÓGICA DE BÚSQUEDA DE VACANTES ---
    elseif ($intencion === 'buscar_vacantes') {
        $sql_busqueda = "SELECT v.id, v.titulo, e.nombre_empresa FROM vacantes v JOIN empresas e ON v.id_empresa = e.usuario_id WHERE v.estado = 'activa'";
        $params_busqueda = [];
        $types_busqueda = '';

        if (!empty($keyword)) {
            $sql_busqueda .= " AND v.titulo LIKE ?";
            $params_busqueda[] = "%" . $keyword . "%";
            $types_busqueda .= 's';
        }
        if (!empty($location)) {
            $sql_busqueda .= " AND v.ubicacion LIKE ?";
            $params_busqueda[] = "%" . $location . "%";
            $types_busqueda .= 's';
        }
        $sql_busqueda .= " LIMIT 5"; // Limitar a 5 resultados para no saturar el chat

        $stmt = $conexion_local->prepare($sql_busqueda);
        if (!empty($types_busqueda)) {
            $stmt->bind_param($types_busqueda, ...$params_busqueda);
        }
        $stmt->execute();
        $resultados = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

        if (count($resultados) > 0) {
            $response = "¡Genial! Encontré estas oportunidades para ti:\n\n";
            foreach ($resultados as $vacante) {
                $response .= "• **" . htmlspecialchars($vacante['titulo']) . "** en " . htmlspecialchars($vacante['nombre_empresa']) . "\n";
                $response .= "  [Ver Detalles](ver_vacante_detalle.php?id=" . $vacante['id'] . ")\n";
            }
            $response .= "\nPara una búsqueda más detallada, te recomiendo usar el [buscador principal](buscar.php).";
        } else {
            $response = "No encontré vacantes que coincidan con tu búsqueda. Intenta con otros términos o revisa la [página de búsqueda](buscar.php) para ver todas las opciones.";
        }
    }
    // Preguntas Dinámicas (con acceso a BD)
    elseif ($intencion === 'contar_vacantes') {
        try {
            // 1. Contar el total de vacantes activas
            $stmt_total = $conexion_local->prepare("SELECT COUNT(*) as total FROM vacantes WHERE estado = 'activa'");
            $stmt_total->execute();
            $total = $stmt_total->get_result()->fetch_assoc()['total'] ?? 0;
            $stmt_total->close();

            if ($total > 0) {
                $response = "¡Actualmente tenemos **$total vacantes activas** esperando por ti! 🚀\n\n";
                $response .= "Aquí tienes algunas destacadas:\n\n";

                // 2. Obtener hasta 3 vacantes destacadas (aleatorias)
                $stmt_destacadas = $conexion_local->prepare("SELECT id, titulo FROM vacantes WHERE estado = 'activa' ORDER BY RAND() LIMIT 3");
                $stmt_destacadas->execute();
                $vacantes_destacadas = $stmt_destacadas->get_result()->fetch_all(MYSQLI_ASSOC);
                $stmt_destacadas->close();

                foreach ($vacantes_destacadas as $vacante) {
                    $response .= "• **" . htmlspecialchars($vacante['titulo']) . "**\n";
                    $response .= "  [Ver Detalles](ver_vacante_detalle.php?id=" . $vacante['id'] . ")\n";
                }
                $response .= "\n[Ver todas las vacantes](buscar.php)";
            } else {
                $response = "Actualmente no hay vacantes activas, pero vuelve a consultar pronto. ¡Las oportunidades cambian rápidamente!";
            }
        } catch (Exception $e) {
            $response = "Lo siento, no pude consultar el número de vacantes en este momento. Inténtalo más tarde.";
        }
    }
    // Despedidas
    elseif ($intencion === 'despedida') {
        $response = "¡De nada! Ha sido un placer ayudarte. ¡Mucho éxito! 👍";
    }
    // Respuesta por defecto
    else {
        $response = "Lo siento, no he entendido tu pregunta. 🤔\nPuedes intentar reformularla, usar los botones de sugerencia o escribir 'ayuda' para ver lo que puedo hacer.";
    }

    return $response;
}
?>