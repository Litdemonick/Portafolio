<?php
session_start();
require_once "conexion_dbs.php";

// 1. OBTENER VARIABLES INICIALES (Necesarias antes de cualquier lógica)
$id_vacante = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$usuario_id = $_SESSION['usuario_id'] ?? null;
$usuario_rol = $_SESSION['usuario_rol'] ?? null;

// Validar ID
if (!$id_vacante) {
    header("Location: buscar.php");
    exit();
}

// --- LÓGICA DE CONFIRMACIÓN Y REGISTRO DE VISITA (CORREGIDO ANTI-DUPLICADOS) ---
// Esta sección debe estar ANTES del include 'header.php' para que funcione la redirección.
if ($usuario_rol === 'publico' && isset($_GET['confirm_view']) && $_GET['confirm_view'] === 'yes') {
    $id_usuario_vista = $_SESSION['usuario_id'];
    $visita_confirmada_key = 'view_confirmed_vacante_' . $id_vacante;

    // Solo intentar registrar si no se ha confirmado previamente en esta sesión
    if (!isset($_SESSION[$visita_confirmada_key])) {
        
        // 1. PROTECCIÓN ANTI-DUPLICADOS: Verificar si ya existe una vista hoy en la BD Local
        // Esto frena el problema de "doble click" o recarga rápida en Windows
        $ya_registrado_hoy = false;
        try {
            $sql_check = "SELECT id FROM vacante_vistas WHERE id_vacante = ? AND id_usuario = ? AND DATE(fecha_vista) = CURDATE()";
            $stmt_check = $conexion_local->prepare($sql_check);
            $stmt_check->bind_param("ii", $id_vacante, $id_usuario_vista);
            $stmt_check->execute();
            $stmt_check->store_result();
            
            if ($stmt_check->num_rows > 0) {
                $ya_registrado_hoy = true;
                // Si ya existe en BD, marcamos la sesión como verdadera para no volver a consultar
                $_SESSION[$visita_confirmada_key] = true;
            }
            $stmt_check->close();
        } catch (Exception $e) {
            // Si falla la verificación, asumimos que no está y dejamos que el insert intente (o falle)
            error_log("Error verificando duplicidad: " . $e->getMessage());
        }

        // 2. SI NO ESTÁ REGISTRADO HOY, PROCEDEMOS A INSERTAR
        if (!$ya_registrado_hoy) {
            $sql_vista = "INSERT INTO vacante_vistas (id_vacante, id_usuario, fecha_vista) VALUES (?, ?, NOW())";
            
            try {
                // Usamos la conexión local directa ($conexion_local)
                $stmt_vista = $conexion_local->prepare($sql_vista);
                $stmt_vista->bind_param("ii", $id_vacante, $id_usuario_vista);
                
                if ($stmt_vista->execute()) {
                    
                    // --- INICIO REPLICACIÓN ---
                    // Construimos la consulta con los valores reales para la función de replicación
                    // Solo se ejecuta si la inserción local fue exitosa
                    $sql_replica = "INSERT INTO vacante_vistas (id_vacante, id_usuario, fecha_vista) VALUES ($id_vacante, $id_usuario_vista, NOW())";
                    
                    // Envolvemos replicación en try/catch silencioso para no romper el flujo si falla la remota
                    try {
                        replicar_consulta($sql_replica);
                    } catch (Exception $ex_rep) {
                        error_log("Error replicando vista: " . $ex_rep->getMessage());
                    }
                    // --- FIN REPLICACIÓN ---

                    $_SESSION[$visita_confirmada_key] = true; // Marcar como confirmado
                    $_SESSION['mensaje_vista_registrada'] = "¡Gracias por visitar esta vacante! Tu visita ha sido registrada.";
                    $stmt_vista->close();
                } else {
                    throw new Exception("Error SQL: " . $conexion_local->error);
                }
            } catch (Exception $e) {
                error_log("Error al registrar vista de vacante: " . $e->getMessage());
                $_SESSION['mensaje_detalle_vacante'] = "❌ Hubo un error al registrar tu visita.";
                $_SESSION['mensaje_detalle_vacante_tipo'] = 'danger';
            }
        }
    }
    
    // Redirigir siempre para limpiar la URL de 'confirm_view=yes'
    // IMPORTANTE: Guardar sesión antes de redirigir para evitar race conditions
    session_write_close(); 
    
    header("Location: ver_vacante_detalle.php?id=" . $id_vacante);
    exit();
}

// --- AHORA SÍ, INCLUIMOS EL HEADER (HTML) ---
include 'includes/header.php';

// Recuperar mensajes de sesión después del header
$mensaje = $_SESSION['mensaje_detalle_vacante'] ?? '';
$mensaje_tipo = $_SESSION['mensaje_detalle_vacante_tipo'] ?? 'info';
unset($_SESSION['mensaje_detalle_vacante'], $_SESSION['mensaje_detalle_vacante_tipo']);

$mensaje_visita = $_SESSION['mensaje_vista_registrada'] ?? '';
unset($_SESSION['mensaje_vista_registrada']);


// --- OBTENER DATOS DE LA VACANTE (GET) ---
$sql = "
    SELECT 
        v.*, 
        e.nombre_empresa, 
        u.foto_perfil,
        e.industria,
        e.cantidad_empleados,
        e.tipo_empresa,
        (SELECT AVG(calificacion) FROM calificaciones_empresas WHERE id_empresa = v.id_empresa) as avg_rating,
        (SELECT COUNT(*) FROM postulaciones WHERE id_vacante = v.id) as num_postulaciones
    FROM vacantes v
    JOIN usuarios u ON v.id_empresa = u.id
    JOIN empresas e ON u.id = e.usuario_id
    WHERE v.id = ?
";
$stmt = $conexion_local->prepare($sql);
$stmt->bind_param("i", $id_vacante);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    echo "<main class='container py-5 text-center'><div class='alert alert-warning'>La vacante no existe o ya no está disponible.</div> <a href='buscar.php' class='btn btn-primary'>Volver a la búsqueda</a></main>";
    include 'includes/footer.php';
    exit();
}
$vacante = $resultado->fetch_assoc();


// 2. Comprobar si se debe mostrar el modal de confirmación (Lógica visual)
$debe_mostrar_modal = false;
if ($vacante && $usuario_rol === 'publico') {
    $visita_confirmada = isset($_SESSION['view_confirmed_vacante_' . $id_vacante]);
    if (!$visita_confirmada) {
        $debe_mostrar_modal = true;
    }
}


// --- VERIFICACIONES PARA EL USUARIO LOGUEADO ---
// Inicializamos variables
$ya_postulado = false;
$tiene_hv = false;
$bloqueado_temporalmente = false;
$hv_data = null;
$calificacion_usuario = 0;

if ($debe_mostrar_modal) {
    // Si el modal se va a mostrar, no necesitamos ejecutar el resto de lógica pesada.
} else {
    if ($usuario_id && $usuario_rol === 'publico') {
        // Verificar si ya se postuló
        $stmt_check = $conexion_local->prepare("SELECT id, estado, fecha_decision FROM postulaciones WHERE id_vacante = ? AND id_usuario = ?");
        $stmt_check->bind_param("ii", $id_vacante, $usuario_id);
        $stmt_check->execute();
        $postulacion_existente = $stmt_check->get_result()->fetch_assoc();
        $ya_postulado = (bool)$postulacion_existente;

        // Lógica para el bloqueo temporal si fue rechazado
        if ($ya_postulado && $postulacion_existente['estado'] === 'rechazado' && !empty($postulacion_existente['fecha_decision'])) {
            $fecha_decision = new DateTime($postulacion_existente['fecha_decision']);
            if ($fecha_decision->modify('+1 day') > new DateTime()) {
                $bloqueado_temporalmente = true;
            }
        }

        // Obtener datos de la HV incluyendo archivo adjunto
        $stmt_hv = $conexion_local->prepare("SELECT id, archivo_adjunto FROM hvs WHERE usuario_id = ?");
        $stmt_hv->bind_param("i", $usuario_id);
        $stmt_hv->execute();
        $hv_result = $stmt_hv->get_result();
        if ($hv_result->num_rows > 0) {
            $tiene_hv = true;
            $hv_data = $hv_result->fetch_assoc();
        }

        // Obtener calificación del usuario para esta empresa
        $stmt_rating = $conexion_local->prepare("SELECT calificacion FROM calificaciones_empresas WHERE id_empresa = ? AND id_usuario = ?");
        $stmt_rating->bind_param("ii", $vacante['id_empresa'], $usuario_id);
        $stmt_rating->execute();
        $res_rating = $stmt_rating->get_result()->fetch_assoc();
        if ($res_rating) {
            $calificacion_usuario = $res_rating['calificacion'];
        }
    }
}

// Función para obtener el icono según la extensión del archivo
function get_file_icon($filename) {
    if (empty($filename) || $filename === 'no especificado') return '';
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    switch($ext) {
        case 'pdf': return '<i class="bi bi-file-pdf-fill text-danger"></i>';
        case 'doc':
        case 'docx': return '<i class="bi bi-file-word-fill text-primary"></i>';
        default: return '<i class="bi bi-file-earmark-fill"></i>';
    }
}
?>

<div class="modal fade" id="confirmViewModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="confirmViewModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content" style="background-color: var(--surface-color); border-color: var(--border-color);">
      <div class="modal-header" style="border-bottom-color: var(--border-color);">
        <h5 class="modal-title" id="confirmViewModalLabel"><i class="bi bi-eye-fill me-2"></i>Confirmar Visita</h5>
      </div>
      <div class="modal-body">
        <p>Estás a punto de ver los detalles de esta vacante.</p>
        <p class="text-muted">Para asegurar un sistema justo para las empresas, tu visita será registrada. Esto podría tener un costo de "peaje" para la empresa que publicó la oferta.</p>
        <p><strong>¿Deseas continuar?</strong></p>
      </div>
      <div class="modal-footer" style="border-top-color: var(--border-color);">
        <a href="buscar.php" class="btn btn-outline-secondary">No, volver</a>
        <a href="ver_vacante_detalle.php?id=<?= $id_vacante ?>&confirm_view=yes" class="btn btn-gradient">Sí, continuar</a>
      </div>
    </div>
  </div>
</div>

<?php
// Lógica para mostrar el modal con JavaScript
if ($debe_mostrar_modal) {
    echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            var myModal = new bootstrap.Modal(document.getElementById('confirmViewModal'));
            myModal.show();
        });
    </script>";
}
?>

<style>
    :root {
        --surface-color-secondary: #2a2a2a;
    }
    
    [data-theme="light"] {
        --surface-color-secondary: #f8f9fa;
    }
    
    .job-header {
        background: linear-gradient(135deg, var(--surface-color) 0%, var(--surface-color-secondary) 100%);
        border-bottom: 2px solid var(--primary-color);
        box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    }
    
    .company-logo-detail {
        width: 90px;
        height: 90px;
        object-fit: contain;
        border-radius: 1rem;
        background-color: var(--surface-color);
        padding: 8px;
        border: 2px solid var(--primary-color);
        box-shadow: 0 4px 15px rgba(0,198,255,0.2);
    }
    
    .company-logo-default-detail {
        width: 90px; 
        height: 90px; 
        display: flex; 
        align-items: center; 
        justify-content: center;
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        border-radius: 1rem;
        font-size: 3rem; 
        color: white;
        box-shadow: 0 4px 15px rgba(0,198,255,0.3);
    }
    
    .sidebar-card {
        background-color: var(--surface-color);
        border: 1px solid var(--border-color);
        border-radius: 1rem;
        padding: 2rem;
        box-shadow: 0 8px 30px rgba(0,0,0,0.15);
        transition: all 0.3s ease;
    }
    
    .sidebar-sticky-wrapper {
        position: sticky;
        top: 100px;
    }

    .sidebar-card:hover {
        box-shadow: 0 12px 40px rgba(0,198,255,0.2);
        transform: translateY(-2px);
    }
    
    /* Contenedor para arreglar el sticky sidebar */
    .job-detail-wrapper {
        display: flex;
        align-items: flex-start; /* Evita que las columnas se estiren a la misma altura */
    }

    .sidebar-card h5 {
        color: var(--text-color);
        font-weight: 600;
        margin-bottom: 1.5rem;
        padding-bottom: 0.75rem;
        border-bottom: 2px solid var(--primary-color);
    }
    
    /* Sistema de Calificación con Estrellas */
    .rating-stars { 
        display: inline-flex;
        flex-direction: row-reverse;
        justify-content: center;
        gap: 0.5rem;
    }
    
    .rating-stars input[type="radio"] { 
        display: none; 
    }
    
    .rating-stars label { 
        font-size: 2.5rem; 
        color: #444;
        cursor: pointer; 
        transition: all 0.2s ease;
        text-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    /* Modo oscuro - estrellas sin seleccionar */
    body[data-theme="dark"] .rating-stars label {
        color: #555;
    }
    
    /* Estrellas seleccionadas (checked) y todas las anteriores */
    .rating-stars input[type="radio"]:checked ~ label,
    .rating-stars:not(:hover) input[type="radio"]:checked ~ label {
        color: #FFD700 !important;
        text-shadow: 0 0 10px rgba(255, 215, 0, 0.5);
        transform: scale(1.1);
    }
    
    /* Estrellas al pasar el mouse */
    .rating-stars label:hover,
    .rating-stars label:hover ~ label {
        color: #FFA500 !important;
        transform: scale(1.15);
    }
    
    /* Info boxes mejoradas */
    .info-box {
        background-color: var(--surface-color-secondary);
        border: 1px solid var(--border-color);
        border-radius: 0.75rem;
        padding: 1rem;
        margin-bottom: 1rem;
        transition: all 0.3s ease;
    }
    
    .info-box:hover {
        border-color: var(--primary-color);
        box-shadow: 0 4px 15px rgba(0,198,255,0.15);
    }
    
    .info-box i {
        font-size: 1.5rem;
        color: var(--primary-color);
    }
    
    .info-box strong {
        color: var(--text-color);
        display: block;
        margin-bottom: 0.25rem;
        font-size: 0.9rem;
    }
    
    .info-box .value {
        color: var(--text-color);
        font-size: 1rem;
    }
    
    /* Badge mejorado */
    .badge-custom {
        background: linear-gradient(135deg, rgba(0,198,255,0.2), rgba(0,114,255,0.2));
        color: var(--text-color);
        border: 1px solid var(--primary-color);
        padding: 0.5rem 1rem;
        border-radius: 0.5rem;
        font-weight: 500;
    }
    
    /* Sección de contenido principal */
    .content-section {
        background-color: var(--surface-color);
        border: 1px solid var(--border-color);
        border-radius: 1rem;
        padding: 2rem;
        margin-bottom: 2rem;
        box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    }
    
    .content-section h3 {
        color: var(--text-color);
        font-weight: 600;
        margin-bottom: 1.5rem;
        padding-bottom: 0.75rem;
        border-bottom: 2px solid var(--primary-color);
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    .content-section p {
        color: var(--text-color);
        line-height: 1.8;
    }
    
    /* Slogan especial */
    .slogan-box {
        background: linear-gradient(135deg, rgba(0,198,255,0.1), rgba(0,114,255,0.1));
        border-left: 4px solid var(--primary-color);
        border-radius: 0.75rem;
        padding: 1.5rem;
        margin-bottom: 2rem;
    }
    
    .slogan-box h4 {
        color: var(--primary-color);
        font-weight: 600;
        margin-bottom: 1rem;
    }
    
    .slogan-box p {
        color: var(--text-color);
        font-style: italic;
        margin-bottom: 0;
    }

    /* HV Info Card */
    .hv-info-card {
        background: linear-gradient(135deg, rgba(0,198,255,0.1), rgba(0,114,255,0.05));
        border: 2px dashed var(--primary-color);
        border-radius: 0.75rem;
        padding: 1.25rem;
        margin-top: 1rem;
    }
    
    .hv-info-card .icon {
        font-size: 2rem;
        color: var(--primary-color);
    }
    
    .hv-info-card .text {
        color: var(--text-color);
        font-size: 0.9rem;
        line-height: 1.6;
    }
    
    .hv-info-card .file-badge {
        background-color: var(--surface-color);
        border: 1px solid var(--primary-color);
        border-radius: 0.5rem;
        padding: 0.5rem 1rem;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        margin-top: 0.75rem;
        color: var(--text-color);
        font-weight: 500;
    }
</style>

<header class="job-header py-5">
    <div class="container">
        <div class="d-flex align-items-center">
            <?php
                $foto_empresa = (!empty($vacante['foto_perfil']) && $vacante['foto_perfil'] !== 'foto_default' && file_exists('uploads/avatars/' . $vacante['foto_perfil']))
                    ? 'uploads/avatars/' . htmlspecialchars($vacante['foto_perfil'])
                    : null;
            ?>
            <?php if ($foto_empresa): ?>
                <img src="<?= $foto_empresa ?>" alt="Logo <?= htmlspecialchars($vacante['nombre_empresa']) ?>" class="company-logo-detail me-4">
            <?php else: ?>
                <div class="company-logo-default-detail me-4"><i class="bi bi-building"></i></div>
            <?php endif; ?>
            <div>
                <h1 class="display-5 mb-2 fw-bold"><?= htmlspecialchars($vacante['titulo']) ?></h1>
                <h2 class="h3 fw-normal mb-3" style="color: var(--text-color-muted);"><?= htmlspecialchars($vacante['nombre_empresa']) ?></h2>
                <div>
                    <span class="badge-custom me-2"><i class="bi bi-geo-alt-fill me-1"></i><?= htmlspecialchars($vacante['ubicacion']) ?></span>
                    <span class="badge-custom me-2"><?= htmlspecialchars($vacante['modalidad']) ?></span>
                    <span class="badge-custom"><i class="bi bi-clock-fill me-1"></i>Publicado: <?= date("d/m/Y", strtotime($vacante['fecha_publicacion'])) ?></span>
                </div>
            </div>
        </div>
    </div>
</header>

<main class="container py-5">
    <div class="job-detail-wrapper">
        <div class="row g-4">
            <div class="col-lg-8">
                <?php if (!empty($mensaje)): ?>
                    <div class="alert alert-<?= $mensaje_tipo ?> alert-dismissible fade show" role="alert">
                        <?= htmlspecialchars($mensaje) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if (!empty($mensaje_visita)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="bi bi-eye-fill me-2"></i><?= htmlspecialchars($mensaje_visita) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if (!empty($vacante['slogan_puesto'])): ?>
                    <div class="slogan-box">
                        <h4><i class="bi bi-quote me-2"></i>Un mensaje de la empresa</h4>
                        <p class="mb-0">"<?= nl2br(htmlspecialchars($vacante['slogan_puesto'])) ?>"</p>
                    </div>
                <?php endif; ?>

                <article class="content-section">
                    <h3><i class="bi bi-file-text-fill"></i>Descripción del Puesto</h3>
                    <p><?= nl2br(htmlspecialchars($vacante['descripcion'])) ?></p>
                </article>
            </div>

            <div class="col-lg-4">
                <div class="sidebar-sticky-wrapper">
                    <div class="sidebar-card mb-4">
                        <h5><i class="bi bi-send-fill me-2"></i>¿Interesado en este puesto?</h5>

                        <?php if ($vacante['estado'] === 'cerrada'): // CASO 0: La vacante está cerrada ?>
                            <div class="alert alert-secondary text-center">
                                <i class="bi bi-archive-fill h4"></i>
                                <p class="mb-0">Esta vacante está cerrada y ya no acepta postulaciones.</p>
                            </div>

                        <?php elseif (!$usuario_id) : // CASO 1: Usuario no ha iniciado sesión ?>
                            <div class="d-grid gap-2">
                                <a href="login.php" class="btn btn-gradient btn-lg">
                                    <i class="bi bi-box-arrow-in-right me-2"></i>Inicia sesión para postularte
                                </a>
                            </div>

                        <?php elseif ($usuario_rol === 'publico') : // CASO 2: Usuario es un candidato ?>
                            
                            <?php if ($ya_postulado) : // Subcaso 2.1: Ya se postuló ?>
                                <button type="button" class="btn btn-success btn-lg w-100" disabled>
                                    <i class="bi bi-check-circle-fill me-2"></i>Ya te postulaste
                                </button>
                            <?php elseif ($vacante['puestos_disponibles'] <= 0) : // Subcaso 2.1.1: No hay puestos disponibles ?>
                                <button type="button" class="btn btn-secondary btn-lg w-100" disabled>
                                    <i class="bi bi-slash-circle-fill me-2"></i>No hay puestos disponibles
                                </button>
                            <?php elseif ($bloqueado_temporalmente) : // Subcaso 2.1.2: Fue rechazado hace menos de 1 día ?>
                                <button type="button" class="btn btn-secondary btn-lg w-100" disabled>
                                    <i class="bi bi-clock-history me-2"></i>No aplicas para este puesto
                                </button>
                            <?php elseif (!$tiene_hv) : // Subcaso 2.2: No tiene HV ?>
                                <a href="crear_hv.php" class="btn btn-warning btn-lg w-100">
                                    <i class="bi bi-file-earmark-person-fill me-2"></i>Crea tu HV para postularte
                                </a>
                            <?php else : // Subcaso 2.3: Puede postularse ?>
                                <a href="postulacion_detalle.php?id_vacante=<?= $id_vacante ?>" class="btn btn-gradient btn-lg w-100">
                                    <i class="bi bi-send-fill me-2"></i>Postularse Ahora
                                </a>
                            <?php endif; ?>

                        <?php endif; ?>
                    </div>

                    <div class="sidebar-card mb-4">
                        <h5><i class="bi bi-building-fill me-2"></i>Sobre la Empresa</h5>
                        <div class="info-box">
                            <i class="bi bi-person-workspace"></i>
                            <strong>Puestos Disponibles</strong>
                            <span class="value"><?= htmlspecialchars($vacante['puestos_disponibles']) ?></span>
                        </div>
                        <div class="info-box">
                            <i class="bi bi-briefcase-fill"></i>
                            <strong>Industria</strong>
                            <span class="value"><?= htmlspecialchars($vacante['industria'] ?: 'No especificada') ?></span>
                        </div>
                        <div class="info-box">
                            <i class="bi bi-people-fill"></i>
                            <strong>Tamaño</strong>
                            <span class="value"><?= htmlspecialchars($vacante['cantidad_empleados'] ?: 'No especificado') ?></span>
                        </div>
                        <div class="info-box">
                            <i class="bi bi-shield-check"></i>
                            <strong>Tipo de Empresa</strong>
                            <span class="value"><?= htmlspecialchars(ucfirst($vacante['tipo_empresa'] ?: 'No especificado')) ?></span>
                        </div>
                        <div class="info-box">
                            <i class="bi bi-star-fill"></i>
                            <strong>Calificación General</strong>
                            <span class="value"><?= number_format($vacante['avg_rating'] ?? 0, 1) ?> / 5.0 ⭐</span>
                        </div>
                    </div>

                    <?php if ($usuario_rol === 'publico') : ?>
                        <div class="sidebar-card">
                            <h5><i class="bi bi-star-half me-2"></i>Tu Opinión Importa</h5>
                            <a href="calificacion_empresa.php?id_empresa=<?= $vacante['id_empresa'] ?>" class="btn btn-outline-custom w-100">
                                <i class="bi bi-star-fill me-2"></i>
                                <?= $calificacion_usuario > 0 ? 'Ver o Editar Mi Calificación' : 'Calificar esta Empresa' ?>
                            </a>
                            <?php if ($calificacion_usuario > 0): ?>
                                <div class="alert alert-info mt-3 mb-0" style="font-size: 0.85rem;">
                                    <i class="bi bi-info-circle me-1"></i>Tu calificación actual: <strong><?= $calificacion_usuario ?> estrellas</strong>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?>