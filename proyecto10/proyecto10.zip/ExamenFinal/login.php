<?php
session_start();

// Si ya hay una sesión activa, redirigir al dashboard
if (isset($_SESSION['usuario_id'])) {
    header('Location: dashboard.php');
    exit();
}

// Lógica para "Recordarme" con cookie
if (isset($_COOKIE['remember_me']) && !isset($_SESSION['usuario_id'])) {
    // No es necesario un require_once si ya se incluye más abajo.
    $usuario_id = (int)$_COOKIE['remember_me'];

    if ($usuario_id > 0) {
        // Conectamos a la DB solo si es necesario
        require_once "conexion_dbs.php";
        $stmt = $conexion_local->prepare("SELECT id, nombres, apellidos, rol, foto_perfil FROM usuarios WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $usuario_id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        if ($resultado && $resultado->num_rows === 1) {
            $usuario_cookie = $resultado->fetch_assoc();
            $_SESSION['usuario_id'] = $usuario_cookie['id'];
            $_SESSION['usuario_nombre'] = $usuario_cookie['nombres'] . ' ' . $usuario_cookie['apellidos'];
            $_SESSION['usuario_rol'] = $usuario_cookie['rol'];
            $_SESSION['usuario_foto'] = $usuario_cookie['foto_perfil'];
            header('Location: dashboard.php');
            exit();
        }
    }
}

include 'includes/header.php';
require_once "conexion_dbs.php";

$mensaje = $_SESSION['mensaje'] ?? '';
unset($_SESSION['mensaje']);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (empty($_POST['email']) || empty($_POST['password'])) {
        $mensaje = "❌ Debes ingresar correo y contraseña.";
    } else {
        $correo = $conexion_local->real_escape_string($_POST['email']);
        $password = $_POST['password'];

        $stmt = $conexion_local->prepare("SELECT id, nombres, apellidos, password, rol, foto_perfil FROM usuarios WHERE correo = ? LIMIT 1");
        $stmt->bind_param("s", $correo);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado && $resultado->num_rows === 1) {
            $usuario = $resultado->fetch_assoc();

            // Verificar la contraseña
            if (password_verify($password, $usuario['password'])) {
                // Contraseña correcta: Iniciar sesión
                $_SESSION['usuario_id'] = $usuario['id'];
                $_SESSION['usuario_nombre'] = $usuario['nombres'] . ' ' . $usuario['apellidos'];
                $_SESSION['usuario_rol'] = $usuario['rol'];
                $_SESSION['usuario_foto'] = $usuario['foto_perfil'];

                // Gestionar "Recordarme"
                if (!empty($_POST['remember'])) {
                    // Crear una cookie que dure 30 días
                    setcookie('remember_me', $usuario['id'], time() + (86400 * 30), "/");
                }

                header("Location: dashboard.php");
                exit();
            }
            $stmt->close();
        }
        // Si el usuario no existe o la contraseña es incorrecta
        $mensaje = "❌ Correo o contraseña incorrectos.";
    }
}
?>

<main class="container py-5">
    <div class="row justify-content-center align-items-center" style="min-height: calc(100vh - 200px);">
        <div class="col-lg-5 col-md-7 col-sm-10">
            <div class="form-container">
                <h1 class="form-title text-center">Iniciar Sesión</h1>
                <p class="form-subtitle text-center">Bienvenido de nuevo.</p>

                <?php if (!empty($mensaje)) : ?>
                    <div class="alert alert-danger mt-3"><?= htmlspecialchars($mensaje) ?></div>
                <?php endif; ?>

                <form method="POST" class="mt-4">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Contraseña</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="1" id="remember" name="remember">
                            <label class="form-check-label" for="remember">Recordarme</label>
                        </div>
                        <a href="recuperar_password.php" style="font-size: 0.9rem;">¿Olvidaste tu contraseña?</a>
                    </div>

                    <button type="submit" class="btn btn-gradient w-100 btn-lg mt-3">Ingresar</button>

                    <p class="text-center mt-4">
                        ¿No tienes una cuenta? <a href="registro.php">Regístrate aquí</a>
                    </p>
                </form>
            </div>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?>