<?php
if (session_status() == PHP_SESSION_NONE) {
  session_start();
}

// --- LÓGICA PARA NOTIFICACIONES DE EMPRESA ---
$nuevas_postulaciones = 0;
if (isset($_SESSION['usuario_id']) && $_SESSION['usuario_rol'] === 'empresa') {
    // Incluir la conexión solo si es necesario
    require_once __DIR__ . '/../conexion_dbs.php';
    $id_empresa = $_SESSION['usuario_id'];
    
    $sql_notif = "SELECT COUNT(p.id) as total_nuevas
                  FROM postulaciones p
                  JOIN vacantes v ON p.id_vacante = v.id
                  WHERE v.id_empresa = ? AND p.visto = 0";
    $stmt_notif = $conexion_local->prepare($sql_notif);
    $stmt_notif->bind_param("i", $id_empresa);
    $stmt_notif->execute();
    $nuevas_postulaciones = $stmt_notif->get_result()->fetch_assoc()['total_nuevas'] ?? 0;
}
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jobs360 - Encuentra tu próximo empleo</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- Google Fonts (Poppins) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <!-- Estilos personalizados -->
    <link rel="stylesheet" href="css/styles.css">

    <!-- Script del Chatbot (movido aquí para asegurar su carga) -->
    <!-- <script src="js/chatbot.js" defer></script> --> <!-- Ya no es necesario en todas las páginas -->
    <!-- Script para el cambio de tema (movido aquí para disponibilidad global) -->
    <script src="scripts/theme-switcher.js" defer></script>
    <script>
        // Script bloqueante para prevenir el parpadeo del tema (FOUC)
        (function() {
            const theme = localStorage.getItem('theme') || 'dark'; // 'dark' es el tema por defecto
            document.documentElement.setAttribute('data-theme', theme);
        })();
    </script>
    
    <!-- Script de protección (anti-copia, etc.) -->
    <script src="scripts/protect.js" defer></script>

    <!-- <link rel="stylesheet" href="css/estilo.css"> --> <!-- Eliminamos o comentamos la línea del CSS antiguo -->
</head>
<body class="d-flex flex-column min-vh-100" 
      data-user-name="<?= htmlspecialchars($_SESSION['usuario_nombres'] ?? 'Visitante') ?>" 
      data-user-role="<?= htmlspecialchars($_SESSION['usuario_rol'] ?? 'invitado') ?>">

<nav class="navbar navbar-expand-lg sticky-top py-2">
    <div class="container">
        <div class="d-flex align-items-center">
            <a class="navbar-brand" href="index.php">Jobs<span class="brand-gradient">360</span></a>
            <!-- Enlace a la página dedicada del Chatbot -->
            <a href="chat-bot.php" class="chatbot-toggler ms-2" title="Asistente Virtual">
                <span class="bi bi-chat-dots-fill"></span>
            </a>
        </div>
        <div class="ms-auto d-flex align-items-center order-lg-2">
            <button class="theme-switcher me-3" id="theme-switcher" title="Cambiar tema">
                <i id="theme-icon" class="bi bi-sun-fill"></i>
            </button>

            <?php if (isset($_SESSION['usuario_id']) && !empty($_SESSION['usuario_id'])) : ?>
                <!-- Vista para usuario logueado -->
                <div class="dropdown text-end">
                    <a href="#" class="d-block link-body-emphasis text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php
                            // Comprobación segura para mostrar foto o ícono por defecto
                            $foto_perfil = (!empty($_SESSION['usuario_foto']) && $_SESSION['usuario_foto'] !== 'foto_default' && file_exists('uploads/avatars/' . $_SESSION['usuario_foto']))
                                ? 'uploads/avatars/' . $_SESSION['usuario_foto']
                                : null;
                        ?>
                        <?php if ($foto_perfil): ?>
                            <img src="<?= htmlspecialchars($foto_perfil) ?>?t=<?= time() ?>" alt="Perfil" width="32" height="32" class="rounded-circle" style="object-fit: cover;">
                        <?php else: ?>
                            <i class="bi bi-person-circle" style="font-size: 1.5rem;"></i>
                        <?php endif; ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark text-small dropdown-menu-end">
                        <li><a class="dropdown-item" href="perfil.php"><i class="bi bi-person-circle me-2"></i>Mi Perfil</a></li>
                        <li><a class="dropdown-item" href="dashboard.php"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a></li>
                        <?php if ($_SESSION['usuario_rol'] === 'publico'): ?>
                            <li><a class="dropdown-item" href="mi_hv.php"><i class="bi bi-file-earmark-person me-2"></i>Mi HV</a></li>
                            <li><a class="dropdown-item" href="mis_postulaciones.php"><i class="bi bi-card-list me-2"></i>Mis Postulaciones</a></li>
                        <?php elseif ($_SESSION['usuario_rol'] === 'empresa'): ?>
                            <li><a class="dropdown-item" href="abrir_vacante.php"><i class="bi bi-plus-square-dotted me-2"></i>Abrir Vacante</a></li>
                            <li><a class="dropdown-item" href="ver_vacantes.php"><i class="bi bi-briefcase me-2"></i>Ver Vacantes</a></li>
                            <li>
                                <a class="dropdown-item position-relative" href="revision_postulacion.php">
                                    <i class="bi bi-people-fill me-2"></i>Postulaciones
                                    <?php if ($nuevas_postulaciones > 0): ?>
                                        <span class="position-absolute top-50 start-100 translate-middle badge rounded-pill bg-danger"><?= $nuevas_postulaciones ?></span>
                                    <?php endif; ?>
                                </a>
                            </li>
                        <?php endif; ?>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i>Cerrar Sesión</a></li>
                    </ul>
                </div>
            <?php else : ?>
                <!-- Vista para usuario no logueado -->
                <a href="login.php" class="btn btn-outline-custom me-3">Iniciar Sesión</a>
                <div class="dropdown">
                    <button class="btn btn-gradient dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                        Registrarse
                    </button>
                    <ul class="dropdown-menu dropdown-menu-dark dropdown-menu-end" aria-labelledby="dropdownMenuButton1">
                        <li><a class="dropdown-item" href="registro.php">Como Persona</a></li>
                        <li><a class="dropdown-item" href="registro_empresa.php">Como Empresa</a></li>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </div>
</nav>

<?php
// Mostrar el buscador en páginas clave como el inicio o la página de búsqueda.
$currentPage = basename($_SERVER['PHP_SELF']);
$showSearch = in_array($currentPage, ['index.php', 'buscar.php']) || (isset($_SESSION['usuario_id']) && $currentPage !== 'abrir_vacante.php' && $currentPage !== 'editar_vacante.php');

if ($showSearch && !in_array($currentPage, ['login.php', 'registro.php', 'registro_empresa.php'])) :
?>
<header class="search-hero-section py-5">
    <div class="container text-center">
        <?php if ($currentPage === 'index.php'): ?>
            <h1 class="display-5 fw-bold">Encuentra tu próximo empleo</h1>
            <p class="fs-5 text-muted mb-4">Busca entre miles de ofertas de las mejores empresas.</p>
        <?php endif; ?>
        
        <form action="buscar.php" method="GET" class="search-form">
            <div class="row g-3 justify-content-center">
                <div class="col-md-4">
                    <input type="text" class="form-control form-control-lg" name="q" placeholder="Puesto, empresa o palabra clave" value="<?= htmlspecialchars($_GET['q'] ?? '') ?>" maxlength="100">
                </div>
                <div class="col-md-3">
                    <input type="text" class="form-control form-control-lg" name="location" placeholder="Ubicación" value="<?= htmlspecialchars($_GET['location'] ?? '') ?>" maxlength="100">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-gradient btn-lg w-100">Buscar</button>
                </div>
            </div>
        </form>

        <div class="mt-4">
            <a href="buscar_empresas.php" class="btn btn-outline-secondary me-2">Buscar Empresas</a>
            <a href="jovenes_profesionales.php" class="btn btn-outline-secondary">Jóvenes Profesionales</a>
        </div>
    </div>
</header>
<?php endif; ?>
