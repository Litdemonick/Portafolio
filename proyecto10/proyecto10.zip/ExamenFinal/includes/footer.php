<?php
// includes/footer.php
?>

<footer class="footer mt-auto py-3">
    <div class="container text-center">
        <span>© <?= date("Y") ?> Jobs360 | Desarrollado por Carlos Miranda</span>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Script para ocultar alertas automáticamente
    document.addEventListener('DOMContentLoaded', () => {
        const alertMessage = document.querySelector('.alert');

        if (alertMessage) {
            // Después de 5 segundos, añade la clase para empezar a desvanecer
            setTimeout(() => {
                alertMessage.classList.add('fade-out');
                
                // Después de que termine la animación de desvanecimiento, elimina el elemento
                setTimeout(() => {
                    alertMessage.remove();
                }, 500); // Coincide con la duración de la transición en CSS
            }, 5000); // 5000ms = 5 segundos
        }
    });

    // Script para previsualizar la imagen de perfil
    const fotoInput = document.getElementById('foto');
    const avatarPreview = document.getElementById('avatar-preview');
    const defaultAvatar = document.getElementById('default-avatar');

    if (fotoInput && avatarPreview && defaultAvatar) {
        fotoInput.addEventListener('change', function(event) {
            if (event.target.files && event.target.files[0]) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    avatarPreview.src = e.target.result;
                    avatarPreview.style.display = 'block';
                    defaultAvatar.style.display = 'none';
                };
                reader.readAsDataURL(event.target.files[0]);
            }
        });
    }
</script>

<!-- Scripts movidos al final para asegurar la carga correcta -->
</body>
</html>
