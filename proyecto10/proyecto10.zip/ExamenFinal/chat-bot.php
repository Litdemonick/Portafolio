<?php
include 'includes/header.php';

// Redirigir si el usuario no está logueado (opcional, pero recomendado)
if (!isset($_SESSION['usuario_id'])) {
    $_SESSION['mensaje'] = "❌ Debes iniciar sesión para usar el asistente.";
    header("Location: login.php");
    exit();
}


// --- LÓGICA PARA PREGUNTAS SUGERIDAS DINÁMICAS ---
$rol_usuario = $_SESSION['usuario_rol'] ?? 'invitado';
$sugerencias = [];

if ($rol_usuario === 'empresa') {
    $sugerencias = [
        "¿Cómo publico una vacante?" => "Publicar Vacante",
        "Vistas de la vacante 'título'" => "Ver Vistas",
        "Generar factura" => "Facturación",
        "¿Cómo funciona el costo de peaje?" => "Costo Peaje",
        "Ayuda" => "Ayuda"
    ];
} elseif ($rol_usuario === 'publico') {
    $sugerencias = [
        "Busca empleos de programador" => "Buscar Empleos",
        "¿Cómo creo mi HV?" => "Crear mi HV",
        "Ver mis postulaciones" => "Mis Postulaciones",
        "¿Cuántas vacantes hay?" => "Vacantes Activas",
        "Ayuda" => "Ayuda"
    ];
} else { // Invitado o rol no definido
    $sugerencias = [
        "¿Qué es Jobs360?" => "¿Qué es Jobs360?",
        "¿Cómo funciona?" => "¿Cómo funciona?",
        "Busca empleos" => "Buscar Empleos",
        "Ayuda" => "Ayuda"
    ];
}

?>

<main class="container py-5">
    <!-- Contenedor principal para centrar el chatbot -->
    <div class="row justify-content-center">
        <div class="col-lg-7 col-md-9">
            <div class="chatbot-page-container">
                <header>
                    <h2>Asistente Jobs360</h2>
                </header>
                <ul class="chatbox">
                    <li class="chat incoming">
                        <span class="bi bi-robot"></span><p>¡Hola, <?= htmlspecialchars($_SESSION['usuario_nombres'] ?? 'invitado') ?>! 👋 Soy tu asistente virtual. ¿En qué puedo ayudarte hoy? Escribe 'ayuda' para ver una lista de comandos.</p>
                    </li>
                </ul>
                <div class="chat-input">
                    <div class="suggested-questions">
                        <?php foreach ($sugerencias as $pregunta => $texto_boton): ?>
                            <button data-question="<?= htmlspecialchars($pregunta) ?>"><?= htmlspecialchars($texto_boton) ?></button>
                        <?php endforeach; ?>
                    </div>
                    <div class="d-flex align-items-center w-100">
                        <textarea placeholder="Escribe un mensaje..." spellcheck="false" required></textarea>
                        <span id="send-btn" class="bi bi-send-fill"></span>
                    </div>
                </div>

            </div>
        </div>
    </div>
</main>

<!-- Incluimos el script del chatbot solo en esta página -->
<script src="chatbot.js" defer></script>

<?php include 'includes/footer.php'; ?>
