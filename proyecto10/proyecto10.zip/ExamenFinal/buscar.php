<?php
include 'includes/header.php';
require_once "conexion_dbs.php";

// --- LÓGICA DE BÚSQUEDA Y PAGINACIÓN ---
$search_query = trim($_GET['q'] ?? '');
$location_query = trim($_GET['location'] ?? '');
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$items_per_page = 9;
$offset = ($page - 1) * $items_per_page;

// --- CONSTRUCCIÓN DE LA CONSULTA ---
$params = [];
$types = "";

// Usamos un LEFT JOIN para obtener la calificación promedio de cada empresa
$sql_base = "
    FROM vacantes v
    JOIN usuarios u ON v.id_empresa = u.id
    LEFT JOIN (
        SELECT id_empresa, AVG(calificacion) as avg_rating, COUNT(calificacion) as rating_count
        FROM calificaciones_empresas
        GROUP BY id_empresa
    ) c ON u.id = c.id_empresa
    WHERE v.estado = 'activa'
";

if (!empty($search_query)) {
    $sql_base .= " AND (v.titulo LIKE ? OR u.nombres LIKE ?)";
    $params[] = "%" . $search_query . "%";
    $params[] = "%" . $search_query . "%";
    $types .= "ss";
}

if (!empty($location_query)) {
    $sql_base .= " AND v.ubicacion LIKE ?";
    $params[] = "%" . $location_query . "%";
    $types .= "s";
}

// Contar total de resultados para la paginación
$sql_count = "SELECT COUNT(v.id) as total " . $sql_base;
$stmt_count = $conexion_local->prepare($sql_count);
if (!empty($types)) {
    $stmt_count->bind_param($types, ...$params);
}
$stmt_count->execute();
$total_items = $stmt_count->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_items / $items_per_page);

// Obtener vacantes para la página actual
$sql_select = "
    SELECT 
        v.id, v.titulo, v.ubicacion, v.modalidad,
        u.nombres as nombre_empresa, u.foto_perfil,
        c.avg_rating, c.rating_count
" . $sql_base . " ORDER BY v.fecha_publicacion DESC LIMIT ? OFFSET ?";

$params[] = $items_per_page;
$params[] = $offset;
$types .= "ii";

$stmt = $conexion_local->prepare($sql_select);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$resultado = $stmt->get_result();
$vacantes = $resultado->fetch_all(MYSQLI_ASSOC);

function render_stars($rating) {
    $rating = floatval($rating);
    $full_stars = floor($rating);
    $half_star = ($rating - $full_stars) >= 0.5;
    $empty_stars = 5 - $full_stars - ($half_star ? 1 : 0);
    $stars_html = '';

    for ($i = 0; $i < $full_stars; $i++) $stars_html .= '<i class="bi bi-star-fill text-warning"></i>';
    if ($half_star) $stars_html .= '<i class="bi bi-star-half text-warning"></i>';
    for ($i = 0; $i < $empty_stars; $i++) $stars_html .= '<i class="bi bi-star text-warning"></i>';
    
    return $stars_html;
}
?>

<main class="container py-5">
    <div class="row">
        <div class="col-12 text-center mb-5">
            <h2 class="display-6">Resultados de la Búsqueda</h2>
            <p class="lead text-muted">Se encontraron <?= $total_items ?> oportunidades laborales.</p>
        </div>
    </div>

    <?php if (empty($vacantes)): ?>
        <div class="text-center p-5 border rounded bg-light">
            <i class="bi bi-search-heart display-1 text-muted mb-3"></i>
            <p class="lead">No se encontraron vacantes para tu búsqueda.</p>
            <p class="text-muted">Intenta con otras palabras clave o una ubicación diferente.</p>
            <a href="index.php" class="btn btn-gradient mt-3">Volver al Inicio</a>
        </div>
    <?php else: ?>
        <div class="row g-4">
            <?php foreach ($vacantes as $vacante): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card h-100 job-card">
                        <div class="card-body d-flex flex-column">
                            <div class="d-flex align-items-center mb-3">
                                <?php
                                    $foto_empresa = (!empty($vacante['foto_perfil']) && $vacante['foto_perfil'] !== 'foto_default' && file_exists('uploads/avatars/' . $vacante['foto_perfil']))
                                        ? 'uploads/avatars/' . htmlspecialchars($vacante['foto_perfil'])
                                        : null;
                                ?>
                                <?php if ($foto_empresa): ?>
                                    <img src="<?= $foto_empresa ?>" alt="Logo <?= htmlspecialchars($vacante['nombre_empresa']) ?>" width="50" height="50" class="rounded-circle me-3" style="object-fit: cover;">
                                <?php else: ?>
                                    <div class="job-icon-box me-3"><i class="bi bi-building"></i></div>
                                <?php endif; ?>
                                <div>
                                    <h5 class="card-title mb-0"><a href="ver_vacante_detalle.php?id=<?= $vacante['id'] ?>" class="stretched-link text-decoration-none" style="color: inherit;"><?= htmlspecialchars($vacante['titulo']) ?></a></h5>
                                    <small class="text-muted"><?= htmlspecialchars($vacante['nombre_empresa']) ?></small>
                                </div>
                            </div>
                            <div class="mt-auto">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="badge bg-secondary bg-opacity-10 text-secondary-emphasis fw-medium"><i class="bi bi-geo-alt-fill me-1"></i><?= htmlspecialchars($vacante['ubicacion']) ?></span>
                                    <span class="badge bg-secondary bg-opacity-10 text-secondary-emphasis fw-medium"><?= htmlspecialchars($vacante['modalidad']) ?></span>
                                </div>
                                <div class="d-flex justify-content-start align-items-center small">
                                    <?= render_stars($vacante['avg_rating']) ?>
                                    <span class="text-muted ms-2">(<?= number_format($vacante['avg_rating'] ?? 0, 1) ?>)</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Paginación -->
        <?php if ($total_pages > 1): ?>
            <nav aria-label="Paginación de vacantes" class="mt-5">
                <ul class="pagination justify-content-center">
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?>&q=<?= urlencode($search_query) ?>&location=<?= urlencode($location_query) ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        <?php endif; ?>
    <?php endif; ?>
</main>

<?php include 'includes/footer.php'; ?>
