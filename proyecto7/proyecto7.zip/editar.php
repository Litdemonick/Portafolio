<?php
include("conexion.php");

if (isset($_GET['id'])) {
  $id = $_GET['id'];
  $result = $conn->query("SELECT * FROM usuarios WHERE id=$id");
  $row = $result->fetch_assoc();
}

if (isset($_POST['update'])) {
  $id = $_POST['id'];
  $nombre = $_POST['nombre'];
  $correo = $_POST['correo'];

  $sql = "UPDATE usuarios SET nombre='$nombre', correo='$correo' WHERE id=$id";
  if ($conn->query($sql) === TRUE) {
    include 'sincronizar_usuarios.php'; // 🔁 Sincronizar después de actualizar
    echo "<script>alert('✅ Usuario actualizado y sincronizado correctamente'); window.location='index.php';</script>";
  } else {
    echo "❌ Error: " . $conn->error;
  }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Editar usuario</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <div class="container">
    <h2>Editar Usuario</h2>
    <form method="POST">
      <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
      <input type="text" name="nombre" value="<?php echo $row['nombre']; ?>" required>
      <input type="email" name="correo" value="<?php echo $row['correo']; ?>" required>
      <button type="submit" name="update">Guardar Cambios</button>
      <a href="index.php" class="btn-back">⬅️ Volver</a>
    </form>
  </div>
</body>
</html>
