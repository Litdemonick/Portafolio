<?php
include("conexion.php");

if (isset($_GET['id'])) {
  $id = $_GET['id'];
  $sql = "DELETE FROM usuarios WHERE id=$id";

  if ($conn->query($sql) === TRUE) {
    include 'sincronizar_usuarios.php'; // 🔁 Sincronizar después de eliminar
    echo "<script>alert('🗑️ Usuario eliminado y sincronizado correctamente'); window.location='index.php';</script>";
  } else {
    echo "❌ Error: " . $conn->error;
  }
}

$conn->close();
?>
