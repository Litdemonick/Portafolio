<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Conceptos Fundamentales</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <div class="slide-container">
    <h1>1️⃣ Conceptos Fundamentales</h1>
    <ul class="content-list">
      <li><b>MySQL/MariaDB</b> es un SGBD relacional que permite almacenar y administrar información estructurada.</li>
      <li><b>PHP</b> se usa para conectar el sistema web con la base de datos.</li>
      <li><b>XAMPP</b> provee Apache, PHP y MySQL en un entorno local.</li>
      <li>En este proyecto se implementa una <b>replicación maestro-esclavo</b> entre Windows y Ubuntu.</li>
    </ul>
    <div class="nav-buttons">
      <a href="index.php" class="btn-prev">← Anterior</a>
      <a href="configuracion.php" class="btn-next">Siguiente →</a>
    </div>
  </div>
  <script src="js/protect.js"></script>
</body>
</html>
