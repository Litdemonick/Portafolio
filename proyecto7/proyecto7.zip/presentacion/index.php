<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Investigación 3 - Replicación MySQL</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <div class="slide-container">
    <h1>Investigación 3</h1>
    <h2>Replicación de Base de Datos MySQL/MariaDB con PHP y XAMPP en Windows y Linux</h2>
    <div class="info-box">
      <p><strong>Universidad Tecnológica de Panamá</strong></p>
      <p>Facultad: Sistemas Computacionales</p>
      <p>Profesor: Napoleón Ibarra</p>
      <p>Estudiantes: <b>Carlos Antonio Miranda and Harold Morales</b></p>
      <p>Fecha: 16/10/2025</p>
    </div>
    <a href="conceptos.php" class="btn-next">Comenzar →</a>
  </div>
</body>
<script src="js/protect.js"></script>
</html>
