<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Replicación con MongoDB</title>
  <!-- Mantiene tu mismo estilo general -->
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <div class="slide-container">
    <h1>4️⃣ Replicación e Integración con MongoDB</h1>

    <p>Además de la replicación MySQL entre <b>Windows (maestro)</b> y <b>Ubuntu (esclavo)</b>, se añadió una capa adicional de replicación hacia una base de datos <b>NoSQL MongoDB</b> instalada en Windows.</p>

    <ul class="content-list">
      <li><b>🎯 Objetivo:</b> Replicar los datos del sistema MySQL hacia MongoDB de forma automática al insertar un nuevo registro.</li>
      <li><b>⚙️ Tecnología usada:</b> PHP + Driver oficial de MongoDB (Composer).</li>
      <li><b>🔗 Flujo funcional:</b>
        <ol>
          <li>Usuario ingresa datos en la web (Windows).</li>
          <li>Se insertan en <b>MySQL (maestro)</b>.</li>
          <li>La replicación los envía al <b>MySQL del Ubuntu (esclavo)</b>.</li>
          <li>Un script PHP adicional (<code>sync_mysql_mongo.php</code>) los copia a <b>MongoDB</b>.</li>
        </ol>
      </li>
    </ul>

    <div class="code-box">
      <h3>📄 Fragmento del script de sincronización PHP</h3>
<pre>
$mysql = new mysqli("localhost", "root", "", "investigacion3_db", 3307);
$client = new MongoDB\Client("mongodb://localhost:27017");
$mongoDB = $client->investigacion3_nosql;

$result = $mysql->query("SELECT * FROM usuarios ORDER BY id DESC LIMIT 10");
while ($row = $result->fetch_assoc()) {
    $mongoDB->usuarios->insertOne([
        "id_mysql" => (int)$row['id'],
        "nombre" => $row['nombre'],
        "correo" => $row['correo']
    ]);
}
</pre>
    </div>

    <div class="img-box">
      <img src="img/replicacion-mongo.png" alt="Replicación MySQL a MongoDB">
      <p class="img-desc">Sincronización de MySQL (Windows) hacia MongoDB y replicación simultánea con Ubuntu.</p>
    </div>

    <div class="nav-buttons">
      <a href="demostracion.php" class="btn-prev">← Atrás</a>
      <a href="conclusiones.php" class="btn-next">Siguiente →</a>
    </div>
  </div>
</body>
<script src="js/protect.js"></script>
</html>
