// js/protect.js
(function() {
  document.addEventListener('contextmenu', e => e.preventDefault()); // Bloquear clic derecho
  document.addEventListener('selectstart', e => e.preventDefault()); // Bloquear selección de texto
  document.addEventListener('copy', e => e.preventDefault());        // Bloquear copiar
  document.addEventListener('cut', e => e.preventDefault());         // Bloquear cortar
  document.addEventListener('paste', e => e.preventDefault());       // Bloquear pegar
  document.addEventListener('dragstart', e => e.preventDefault());   // Bloquear arrastrar

  // Bloquear F12, Ctrl+Shift+I, Ctrl+U, Ctrl+S, Ctrl+Shift+C
  document.addEventListener('keydown', e => {
    if (
      e.key === 'F12' ||
      (e.ctrlKey && e.shiftKey && ['I', 'C', 'J'].includes(e.key.toUpperCase())) ||
      (e.ctrlKey && ['U', 'S'].includes(e.key.toUpperCase()))
    ) {
      e.preventDefault();
      alert("⚠️ Inspección y copia deshabilitadas por seguridad.");
      return false;
    }
  });

  // Bloquear el menú de inspección rápido (click derecho + tecla)
  window.addEventListener('keydown', e => {
    if (e.key === 'F12') e.preventDefault();
  });

  // Si el usuario abre DevTools, redirigir
  setInterval(() => {
    const before = new Date();
    debugger;
    if (new Date() - before > 100) {
      document.body.innerHTML = "<h1 style='color:red;text-align:center;margin-top:50px;'>⚠️ Página protegida. Cierre las herramientas de desarrollador.</h1>";
    }
  }, 1000);
})();
