<?php
include("conexion.php");

$nombre = $_POST['nombre'];
$correo = $_POST['correo'];

$sql = "INSERT INTO usuarios (nombre, correo) VALUES ('$nombre', '$correo')";
if ($conn->query($sql) === TRUE) {
    include 'sincronizar_usuarios.php'; // 🔁 Sincronizar con MongoDB después de insertar
    echo "<script>alert('✅ Usuario registrado y sincronizado correctamente'); window.location='index.php';</script>";
} else {
    echo "❌ Error: " . $conn->error;
}

$conn->close();
?>
