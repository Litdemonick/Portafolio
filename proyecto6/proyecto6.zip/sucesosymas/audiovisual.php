<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <?php include 'includes/preload-theme.php'; ?>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Producción Audiovisual - SUCESOS y MÁS</title>


</head>

<body>
  <?php include('includes/menu.php'); ?>
  <?php include('includes/header.php'); ?>

  <main class="servicio-detalle">

    <!-- HERO -->
    <section class="servicio-hero">
      <div class="overlay"></div>
      <img src="assets/servicios/audiovisual.jpg" alt="Producción Audiovisual" class="hero-bg">
      <div class="hero-content">
        <h1>Producción Audiovisual</h1>
        <p>Transmitimos emociones a través de imágenes, sonido y narrativa visual.</p>
      </div>
    </section>

    <!-- DESCRIPCIÓN -->
    <section class="servicio-descripcion">
      <h2>🎬 Contamos tu historia con impacto</h2>
      <p>
        En <strong>SUCESOS y MÁS</strong> creemos que el contenido audiovisual es la forma más poderosa de conectar con las personas.  
        Producimos videos, spots publicitarios y sesiones fotográficas que reflejan la esencia de tu marca.
      </p>

      <ul>
        <li>📷 Producción y edición de video profesional.</li>
        <li>🎞️ Grabación de anuncios y documentales institucionales.</li>
        <li>💡 Animaciones y motion graphics para redes sociales.</li>
        <li>🎧 Postproducción y mezcla de sonido.</li>
      </ul>
    </section>

    <!-- GALERÍA CON ENLACES -->
    <section class="servicio-galeria">
      <h2>📸 Casos y ejemplos</h2>
      <div class="galeria-grid">

        <a href="proyectos/proyecto3.php" class="galeria-item" title="Campaña Café Aromas">
          <img src="assets/proyecto3.jpg" alt="Campaña Café Aromas">
          <div class="overlay-img">Café Aromas</div>
        </a>

        <a href="proyectos/proyecto1.php" class="galeria-item" title="Campaña Hotel Sol de Verano">
          <img src="assets/proyecto1c.jpg" alt="Hotel Sol de Verano">
          <div class="overlay-img">Hotel Sol de Verano</div>
        </a>

        <a href="proyectos/proyecto5.php" class="galeria-item" title="Campaña Verde Panamá">
          <img src="assets/proyecto5.jpg" alt="Campaña Verde Panamá">
          <div class="overlay-img">Verde Panamá</div>
        </a>

      </div>
    </section>

    <!-- RESULTADOS -->
    <section class="servicio-resultados">
      <h2>📊 Resultados visuales comprobables</h2>
      <p>
        Nuestro contenido audiovisual aumenta la recordación de marca, la interacción en redes sociales  
        y genera experiencias memorables que impulsan el crecimiento de tu negocio.
      </p>

      <div class="metricas">
        <div class="metrica">
          <h3>+200%</h3>
          <p>Aumento de visualizaciones</p>
        </div>
        <div class="metrica">
          <h3>+150%</h3>
          <p>Mayor retención del público</p>
        </div>
        <div class="metrica">
          <h3>+80%</h3>
          <p>Incremento en engagement</p>
        </div>
      </div>
    </section>

    <!-- CTA FINAL -->
    <section class="servicio-cta">
      <h2>¿Listo para llevar tu marca a la pantalla?</h2>
      <p>Transforma tu mensaje en contenido audiovisual profesional que cautive a tu audiencia.</p>
      <a href="contacto.php" class="btn-hero">🎥 Contáctanos</a>
    </section>

    <div class="volver">
      <a href="servicios.php" class="btn-volver">⬅ Volver a Servicios</a>
    </div>
  </main>

  <?php include('includes/footer.php'); ?>

  <script src="js/menu.js" defer></script>
  <script src="js/theme.js"></script>
  <script src="js/protect.js?v=<?php echo time(); ?>"></script>
  
</body>
</html>
