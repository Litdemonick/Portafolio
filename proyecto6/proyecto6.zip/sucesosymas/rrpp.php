<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <?php include 'includes/preload-theme.php'; ?>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Relaciones Públicas y Comunicación - SUCESOS y MÁS</title>

</head>

<body>
  <?php include('includes/menu.php'); ?>
  <?php include('includes/header.php'); ?>

  <main class="servicio-detalle">

    <!-- HERO -->
    <section class="servicio-hero">
      <div class="overlay"></div>
      <img src="assets/servicios/rrpp.jpg" alt="Relaciones Públicas y Comunicación" class="hero-bg">
      <div class="hero-content">
        <h1>Relaciones Públicas y Comunicación</h1>
        <p>Fortalece la reputación de tu marca con estrategias de comunicación efectivas.</p>
      </div>
    </section>

    <!-- DESCRIPCIÓN -->
    <section class="servicio-descripcion">
      <h2>🗣️ Conecta con tu público y genera confianza</h2>
      <p>
        En <strong>SUCESOS y MÁS</strong> nos enfocamos en construir puentes entre tu marca y la audiencia.  
        Diseñamos estrategias de comunicación institucional, manejo de prensa y reputación que reflejan tus valores corporativos.
      </p>

      <ul>
        <li>📰 Redacción de notas de prensa y boletines institucionales.</li>
        <li>🎤 Organización y cobertura de eventos corporativos.</li>
        <li>📡 Comunicación de crisis y gestión de reputación.</li>
        <li>💬 Estrategias de relaciones públicas y medios.</li>
      </ul>
    </section>

    <!-- GALERÍA CON ENLACES -->
    <section class="servicio-galeria">
      <h2>📸 Casos y ejemplos</h2>
      <div class="galeria-grid">

        <a href="proyectos/proyecto5.php" class="galeria-item" title="Campaña Ambiental Verde Panamá">
          <img src="assets/proyecto5.jpg" alt="Campaña Verde Panamá">
          <div class="overlay-img">Campaña Verde Panamá</div>
        </a>

        <a href="proyectos/proyecto3.php" class="galeria-item" title="Campaña Café Aromas">
          <img src="assets/proyecto3.jpg" alt="Campaña Café Aromas">
          <div class="overlay-img">Café Aromas</div>
        </a>

        <a href="proyectos/proyecto1.php" class="galeria-item" title="Campaña Hotel Sol de Verano">
          <img src="assets/proyecto1a.jpg" alt="Hotel Sol de Verano">
          <div class="overlay-img">Hotel Sol de Verano</div>
        </a>

      </div>
    </section>

    <!-- RESULTADOS -->
    <section class="servicio-resultados">
      <h2>📊 Resultados de comunicación estratégica</h2>
      <p>
        La comunicación efectiva genera reputación, confianza y conexión.  
        Nuestros clientes han logrado mayor presencia mediática, mejor percepción institucional y relaciones sólidas con su audiencia.
      </p>

      <div class="metricas">
        <div class="metrica">
          <h3>+90%</h3>
          <p>Visibilidad en medios</p>
        </div>
        <div class="metrica">
          <h3>+70%</h3>
          <p>Mejora en reputación de marca</p>
        </div>
        <div class="metrica">
          <h3>+120%</h3>
          <p>Alcance en eventos corporativos</p>
        </div>
      </div>
    </section>

    <!-- CTA FINAL -->
    <section class="servicio-cta">
      <h2>¿Quieres fortalecer tu imagen institucional?</h2>
      <p>Permítenos construir la voz de tu marca y conectar con tu público de manera profesional y estratégica.</p>
      <a href="contacto.php" class="btn-hero">📞 Contáctanos</a>
    </section>

    <div class="volver">
      <a href="servicios.php" class="btn-volver">⬅ Volver a Servicios</a>
    </div>
  </main>

  <?php include('includes/footer.php'); ?>

  <script src="js/menu.js" defer></script>
  <script src="js/theme.js"></script>
  <script src="js/protect.js?v=<?php echo time(); ?>"></script>
</body>
</html>
