<!DOCTYPE html>
<?php require_once __DIR__ . '/includes/init.php'; ?>

<html lang="es">
<head>
  <meta charset="UTF-8">
  <?php include 'includes/preload-theme.php'; ?>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SUCESOS y MÁS</title>

  <!-- Cargar tema SIN parpadeo -->
  <script>
    (function() {
      const theme = localStorage.getItem("theme") || "light";
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.id = "theme-style";
      link.href = theme === "dark" ? "css/style-dark.css" : "css/style-light.css";
      document.head.appendChild(link);
      document.documentElement.setAttribute("data-theme", theme);
    })();
  </script>
</head>

<body>
  <?php include __DIR__ . '/includes/menu.php'; ?>
  <?php include __DIR__ . '/includes/header.php'; ?>

  <main>
    <!-- HERO -->
    <section class="hero">
      <h2>Bienvenido a SUCESOS y MÁS</h2>
      <p>Explora nuestros productos, servicios y las últimas novedades del mundo actual.</p>
      <a class="btn-hero" href="productos.php">Ver Productos</a>
    </section>

    <!-- 📰 NOTICIAS / COLLAGE -->
    <section class="noticias">
      <h2>Noticias & Proyectos Destacados</h2>
      <p class="intro">Conoce algunos de los proyectos más recientes realizados por nuestro equipo creativo.</p>

      <div class="collage">
        <a href="proyectos/proyecto1.php" class="item">
          <img src="assets/proyecto1.jpg" alt="Campaña Publicitaria Hotel Sol" />
          <div class="info">
            <h3>Campaña Publicitaria Hotel Sol</h3>
            <p>Campaña visual para el Hotel Sol de Verano, con presencia digital mejorada.</p>
          </div>
        </a>

        <a href="proyectos/proyecto2.php" class="item">
          <img src="assets/proyecto2.jpg" alt="Portal Web Tienda FashionMix" />
          <div class="info">
            <h3>Portal Web Tienda FashionMix</h3>
            <p>E-commerce moderno y dinámico para tienda de moda local.</p>
          </div>
        </a>

        <a href="proyectos/proyecto3.php" class="item">
          <img src="assets/proyecto3.jpg" alt="Publicidad para Café Aromas" />
          <div class="info">
            <h3>Publicidad para Café Aromas</h3>
            <p>Campaña audiovisual profesional para redes sociales.</p>
          </div>
        </a>

        <a href="proyectos/proyecto4.php" class="item">
          <img src="assets/proyecto4.jpg" alt="Diseño de logo para TechPlus" />
          <div class="info">
            <h3>Diseño de logo para TechPlus</h3>
            <p>Creación de identidad corporativa moderna y profesional.</p>
          </div>
        </a>

        <a href="proyectos/proyecto5.php" class="item">
          <img src="assets/proyecto5.jpg" alt="Campaña ambiental Verde Panamá" />
          <div class="info">
            <h3>Campaña Ambiental Verde Panamá</h3>
            <p>Diseño gráfico y web para promover la conciencia ecológica.</p>
          </div>
        </a>

        <a href="proyectos/proyecto6.php" class="item">
          <img src="assets/proyecto6.jpg" alt="Tienda online de artesanías locales" />
          <div class="info">
            <h3>Tienda online de Artesanías</h3>
            <p>E-commerce para productores locales con pasarela de pago segura.</p>
          </div>
        </a>
      </div>
    </section>
  </main>

  <?php include __DIR__ . '/includes/footer.php'; ?>

  <!-- JS -->
  <script src="js/menu.js" defer></script>
  <script src="js/theme.js" defer></script>
  <script src="js/protect.js?v=<?php echo time(); ?>"></script>
</body>
</html>
