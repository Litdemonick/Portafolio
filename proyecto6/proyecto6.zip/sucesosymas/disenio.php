<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <?php include 'includes/preload-theme.php'; ?>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Diseño Gráfico y Branding - SUCESOS y MÁS</title>


</head>

<body>
  <?php include('includes/menu.php'); ?>
  <?php include('includes/header.php'); ?>

  <main class="servicio-detalle">

    <!-- HERO -->
    <section class="servicio-hero">
      <div class="overlay"></div>
      <img src="assets/servicios/disenio.jpg" alt="Diseño Gráfico y Branding" class="hero-bg">
      <div class="hero-content">
        <h1>Diseño Gráfico y Branding</h1>
        <p>Creamos identidades visuales únicas que hacen que tu marca destaque.</p>
      </div>
    </section>

    <!-- DESCRIPCIÓN -->
    <section class="servicio-descripcion">
      <h2>🎨 Construimos tu identidad visual</h2>
      <p>
        En <strong>SUCESOS y MÁS</strong> transformamos ideas en imágenes memorables.  
        Nuestro equipo combina arte, psicología del color y estrategia para diseñar marcas coherentes, atractivas y funcionales.
      </p>

      <ul>
        <li>🖼️ Diseño de logotipos y sistemas visuales.</li>
        <li>📘 Manuales de identidad corporativa.</li>
        <li>🧩 Rebranding y rediseño de marcas.</li>
        <li>📢 Material publicitario para medios digitales e impresos.</li>
      </ul>
    </section>

    <!-- GALERÍA CON ENLACES -->
    <section class="servicio-galeria">
      <h2>📸 Casos y ejemplos</h2>
      <div class="galeria-grid">

        <a href="proyectos/proyecto4.php" class="galeria-item" title="Diseño de Logo para TechPlus">
          <img src="assets/proyecto4.jpg" alt="Diseño TechPlus">
          <div class="overlay-img">TechPlus Branding</div>
        </a>

        <a href="proyectos/proyecto5.php" class="galeria-item" title="Campaña Verde Panamá">
          <img src="assets/proyecto5.jpg" alt="Campaña Verde Panamá">
          <div class="overlay-img">Verde Panamá</div>
        </a>

        <a href="proyectos/proyecto6.php" class="galeria-item" title="Tienda de Artesanías">
          <img src="assets/proyecto6.jpg" alt="Artesanías online">
          <div class="overlay-img">Artesanías Panamá</div>
        </a>

      </div>
    </section>

    <!-- RESULTADOS -->
    <section class="servicio-resultados">
      <h2>✨ Resultados visuales y estratégicos</h2>
      <p>
        El diseño es más que estética. Cada línea, color y forma transmite la esencia de tu marca.  
        Nuestras propuestas logran reconocimiento, coherencia visual y conexión emocional con tu público.
      </p>
      <div class="metricas">
        <div class="metrica">
          <h3>+80%</h3>
          <p>Recordación de marca</p>
        </div>
        <div class="metrica">
          <h3>+50%</h3>
          <p>Engagement visual</p>
        </div>
        <div class="metrica">
          <h3>+30%</h3>
          <p>Crecimiento en seguidores</p>
        </div>
      </div>
    </section>

    <!-- CTA FINAL -->
    <section class="servicio-cta">
      <h2>¿Listo para darle identidad a tu marca?</h2>
      <p>Deja que nuestro equipo creativo diseñe la imagen perfecta para tu empresa.</p>
      <a href="contacto.php" class="btn-hero">🖌️ Contáctanos</a>
    </section>

    <div class="volver">
      <a href="servicios.php" class="btn-volver">⬅ Volver a Servicios</a>
    </div>
  </main>

  <?php include('includes/footer.php'); ?>

  <script src="js/menu.js" defer></script>
  <script src="js/theme.js"></script>
  <script src="js/protect.js?v=<?php echo time(); ?>"></script>
</body>
</html>
