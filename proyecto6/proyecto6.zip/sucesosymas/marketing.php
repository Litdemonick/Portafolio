<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <?php include 'includes/preload-theme.php'; ?>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Consultoría de Marketing - SUCESOS y MÁS</title>

 
</head>

<body>
  <?php include('includes/menu.php'); ?>
  <?php include('includes/header.php'); ?>

  <main class="servicio-detalle">

    <!-- HERO -->
    <section class="servicio-hero">
      <div class="overlay"></div>
      <img src="assets/servicios/marketing.jpg" alt="Consultoría de Marketing" class="hero-bg">
      <div class="hero-content">
        <h1>Consultoría de Marketing</h1>
        <p>Impulsa tu marca con estrategias digitales que generan resultados reales.</p>
      </div>
    </section>

    <!-- DESCRIPCIÓN -->
    <section class="servicio-descripcion">
      <h2>🌐 Estrategias 360° para tu crecimiento</h2>
      <p>
        En <strong>SUCESOS y MÁS</strong> ayudamos a las empresas a construir una presencia digital sólida y efectiva.  
        Nuestra consultoría de marketing combina creatividad, análisis de datos y tecnología para asegurar que cada acción comunique y convierta.
      </p>

      <ul>
        <li>📊 Auditoría completa de marketing y posicionamiento.</li>
        <li>📈 Creación de estrategias digitales adaptadas a tu público.</li>
        <li>📣 Campañas en redes sociales, Google Ads y medios locales.</li>
        <li>🧩 Optimización continua basada en métricas de rendimiento.</li>
      </ul>
    </section>

    <!-- GALERÍA CON ENLACES -->
    <section class="servicio-galeria">
      <h2>📸 Casos y ejemplos</h2>
      <div class="galeria-grid">

        <a href="proyectos/proyecto1.php" class="galeria-item" title="Campaña Hotel Sol de Verano">
          <img src="assets/proyecto1a.jpg" alt="Campaña hotel Sol de Verano">
          <div class="overlay-img">Hotel Sol de Verano</div>
        </a>

        <a href="proyectos/proyecto2.php" class="galeria-item" title="Portal Web Tienda FashionMix">
          <img src="assets/proyecto2.jpg" alt="E-commerce moderno">
          <div class="overlay-img">Tienda FashionMix</div>
        </a>

        <a href="proyectos/proyecto3.php" class="galeria-item" title="Publicidad Café Aromas">
          <img src="assets/proyecto3.jpg" alt="Campaña audiovisual">
          <div class="overlay-img">Café Aromas</div>
        </a>

      </div>
    </section>

    <!-- RESULTADOS -->
    <section class="servicio-resultados">
      <h2>📊 Resultados medibles</h2>
      <p>
        Nuestras estrategias generan resultados comprobables: aumento de tráfico, mayor conversión y fidelización del cliente.  
        Creemos que el marketing solo tiene valor si impulsa el crecimiento sostenible de tu negocio.
      </p>
      <div class="metricas">
        <div class="metrica">
          <h3>+65%</h3>
          <p>Tráfico web orgánico</p>
        </div>
        <div class="metrica">
          <h3>+120%</h3>
          <p>Interacción en redes</p>
        </div>
        <div class="metrica">
          <h3>+45%</h3>
          <p>Conversión promedio</p>
        </div>
      </div>
    </section>

    <!-- CTA FINAL -->
    <section class="servicio-cta">
      <h2>¿Listo para transformar tu marca?</h2>
      <p>Agenda una reunión gratuita con nuestro equipo de marketing y descubre todo tu potencial.</p>
      <a href="contacto.php" class="btn-hero">🚀 Contáctanos</a>
    </section>

    <div class="volver">
      <a href="servicios.php" class="btn-volver">⬅ Volver a Servicios</a>
    </div>
  </main>

  <?php include('includes/footer.php'); ?>

  <script src="js/menu.js" defer></script>
  <script src="js/theme.js"></script>
  <script src="js/protect.js?v=<?php echo time(); ?>"></script>
</body>
</html>
