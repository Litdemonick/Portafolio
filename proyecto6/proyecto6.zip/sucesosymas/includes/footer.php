<footer>
  <p>&copy; 2025 SUCESOS y MÁS | Dirección: Calle 2da Este, Ciudad de David, Chiriquí, Panamá</p>
</footer>
