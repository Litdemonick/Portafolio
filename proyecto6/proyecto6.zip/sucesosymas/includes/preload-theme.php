<!-- includes/preload-theme.php -->
<script>
  (function() {
    const theme = localStorage.getItem("theme") || "light";
    document.documentElement.setAttribute("data-theme", theme);

    // Crear el link antes de mostrar nada
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.id = "theme-style";
    link.href = theme === "dark"
      ? "/sucesosymas/css/style-dark.css"
      : "/sucesosymas/css/style-light.css";
    document.head.appendChild(link);

    // Evitar flash de contenido sin estilos
    document.documentElement.style.visibility = "hidden";
    link.onload = () => {
      document.documentElement.style.visibility = "visible";
    };
  })();
</script>
