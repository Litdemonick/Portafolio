<header class="main-header">
  <div class="unheader-container">
    <div class="logo-section">
      <h1>
        <a href="/sucesosymas/index.php" class="logo-link">SUCESOS y MÁS</a>
      </h1>

      <!-- Logo principal (ahora clickeable también) -->
      <a href="/sucesosymas/index.php">
        <img src="assets/logo/logo.png" alt="Logo SUCESOS y MÁS" class="logo-banner">
      </a>

      <!-- Fondo tipo banner -->
      <div class="logo-banner-bg"></div>
    </div>

    <button id="toggle-theme" class="btn-toggle">🌙 Modo Oscuro</button>
  </div>
</header>
