<!-- includes/menu.php -->
<nav class="side-menu" id="sideMenu" aria-hidden="true">
  <button class="close-btn" id="closeMenu">✖</button>
  <ul>
    <li><a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/proyectos/') !== false) ? '../index.php' : 'index.php'; ?>">🏠 Inicio</a></li>
    <li><a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/proyectos/') !== false) ? '../clientes.php' : 'clientes.php'; ?>">👥 Clientes</a></li>
    <li><a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/proyectos/') !== false) ? '../productos.php' : 'productos.php'; ?>">🛒 Productos</a></li>
    <li><a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/proyectos/') !== false) ? '../servicios.php' : 'servicios.php'; ?>">💼 Servicios</a></li>
    <li><a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/proyectos/') !== false) ? '../contacto.php' : 'contacto.php'; ?>">📧 Contacto</a></li>
    <li><a href="<?php echo (strpos($_SERVER['REQUEST_URI'], '/proyectos/') !== false) ? '../factura.php' : 'factura.php'; ?>">🧾 Factura del servicio</a></li>
  </ul>
</nav>

<!-- Botón ☰ -->
<button class="menu-btn" id="menuToggle" aria-label="Abrir menú">☰</button>

<!-- Fondo oscuro -->
<div class="overlay" id="overlay"></div>
