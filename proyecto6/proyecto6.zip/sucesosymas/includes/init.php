<?php
ob_start(function($buffer) {
  $buffer = preg_replace('/<!--([\s\S]*?)-->/', '', $buffer);
  $buffer = preg_replace('/\s{2,}/', ' ', $buffer);
  $buffer = preg_replace('/>\s+</', '><', $buffer);
  return trim($buffer);
});

header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: DENY");
header("Referrer-Policy: no-referrer");
