<!DOCTYPE html>
<?php require_once __DIR__ . '/includes/init.php'; ?>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <?php include 'includes/preload-theme.php'; ?>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Factura del Servicio - SUCESOS y MÁS</title>

  <!-- 🩵 Fix: aplicar tema ANTES del render para evitar flash -->
  <script>
    (function() {
      try {
        const tema = localStorage.getItem("theme") || "light";
        document.documentElement.setAttribute("data-theme", tema);
        document.documentElement.style.backgroundColor =
          tema === "dark" ? "#0b0f17" : "#f7f8fc";
        document.documentElement.style.colorScheme = tema;
      } catch (e) {}
    })();
  </script>

  <!-- Librería PDF -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js" defer></script>

  <!-- 💅 Estilos propios de factura -->
  <style>
  body {
    font-family: "Poppins", sans-serif;
    margin: 0;
    padding: 0;
    line-height: 1.6;
    color: var(--text-color, #222);
    background: var(--bg-color, #f9f9f9);
    transition: background 0.3s ease, color 0.3s ease;
  }

  /* ===== CABECERA ===== */
  .factura-header {
    text-align: center;
    background: var(--header-gradient);
    color: var(--header-text);
    padding: 40px 10px;
    border-bottom: 4px solid var(--header-border);
    transition: background 0.3s ease, color 0.3s ease;
  }

  .factura-header h1 {
    margin: 0;
    font-size: 2rem;
    letter-spacing: 1px;
    color: inherit;
  }

  .factura-header p {
    font-size: 1.1rem;
    margin-top: 8px;
    color: inherit;
  }

  /* 🌞 Modo claro */
  [data-theme="light"] {
    --bg-color: #f7f8fc;
    --text-color: #222;
    --header-gradient: linear-gradient(90deg, #ffffff, #e6f2ff);
    --header-text: #003366;
    --header-border: #0078ff;
    --card-bg: #ffffff;
    --info-bg: #f2f8ff;
  }

  /* 🌙 Modo oscuro */
  [data-theme="dark"] {
    --bg-color: #0b0f17;
    --text-color: #e6e9f0;
    --header-gradient: linear-gradient(90deg, #002c6d, #001436);
    --header-text: #ffffff;
    --header-border: #1f8fff;
    --card-bg: #151a24;
    --info-bg: #10141d;
  }

  /* ===== CONTENIDO PRINCIPAL ===== */
  .factura-main {
    max-width: 850px;
    margin: 40px auto;
    background: var(--card-bg);
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    padding: 25px 35px;
    transition: background 0.3s ease, box-shadow 0.3s ease;
  }

  .tabla-factura {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 25px;
  }

  .tabla-factura th, .tabla-factura td {
    padding: 12px 10px;
    border-bottom: 1px solid rgba(0,0,0,0.1);
    text-align: left;
  }

  .tabla-factura th {
    background: #0078ff;
    color: #fff;
    font-weight: 600;
  }

  .tabla-factura tr:hover td {
    background: rgba(0,120,255,0.08);
  }

  .total-row {
    background: #eaf5ff;
    font-weight: bold;
  }

  .total-label {
    text-align: right;
  }

  .factura-info {
    font-size: 0.95rem;
    background: var(--info-bg);
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    line-height: 1.8;
  }

  .volver {
    text-align: center;
    margin-top: 25px;
  }

  .btn-hero {
    display: inline-block;
    background: #0078ff;
    color: white;
    border: none;
    padding: 12px 30px;
    border-radius: 10px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.25s ease;
    text-decoration: none;
  }

  .btn-hero:hover {
    background: #005fd1;
    transform: translateY(-3px);
    box-shadow: 0 5px 15px rgba(0,120,255,0.3);
  }

  .btn-hero:active {
    transform: translateY(1px);
    box-shadow: 0 2px 8px rgba(0,120,255,0.3);
  }

  .descargar-pdf {
    text-align: center;
    margin-top: 25px;
  }

  .descargar-pdf .btn-hero {
    background: #00c6ff;
    color: #0a0a0a;
    font-weight: 700;
  }

  .descargar-pdf .btn-hero:hover {
    background: #00a2e8;
    color: #fff;
  }

  /* ===== MODO OSCURO ===== */
  [data-theme="dark"] body {
    background: var(--bg-color);
    color: var(--text-color);
  }

  [data-theme="dark"] .tabla-factura th {
    background: #1f8fff;
    color: #fff;
  }

  [data-theme="dark"] .tabla-factura td {
    border-bottom: 1px solid rgba(255,255,255,0.1);
  }

  [data-theme="dark"] .tabla-factura tr:hover td {
    background: rgba(31,143,255,0.08);
  }

  [data-theme="dark"] .total-row {
    background: rgba(31,143,255,0.15);
  }

  [data-theme="dark"] .btn-hero {
    background: #1f8fff;
    color: #fff;
  }

  [data-theme="dark"] .btn-hero:hover {
    background: #5aa8ff;
    box-shadow: 0 0 10px rgba(31,143,255,0.4);
  }

  [data-theme="dark"] .factura-main {
    box-shadow: 0 4px 15px rgba(255,255,255,0.05);
  }

  [data-theme="dark"] .factura-info {
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.05);
  }

  /* === Fix transición y repintado de colores al cambiar de tema === */
html[data-theme="light"], 
html[data-theme="dark"] {
  color-scheme: var(--color-scheme, light dark);
}

[data-theme="light"], [data-theme="dark"] * {
  transition: background-color 0.25s ease, color 0.25s ease, border-color 0.25s ease !important;
  will-change: background-color, color, border-color;
}

/* Forzar repintado correcto en textos dentro de tablas y botones */
[data-theme="dark"] .tabla-factura td,
[data-theme="dark"] .tabla-factura th,
[data-theme="dark"] .btn-hero,
[data-theme="dark"] .factura-info,
[data-theme="dark"] body {
  color: #e6e9f0 !important;
  background-color: transparent;
}

/* Reforzar contraste de hover */
[data-theme="dark"] .tabla-factura tr:hover td {
  background-color: rgba(31,143,255,0.15) !important;
  color: #ffffff !important;
}

  </style>
</head>

<body>
  <?php include __DIR__ . '/includes/menu.php'; ?>

  <header class="factura-header">
    <div class="header-container">
      <h1>🧾 Factura del Servicio</h1>
      <p>Proyecto: <strong>Sitio Web “SUCESOS y MÁS”</strong></p>
    </div>
  </header>

  <main class="factura-main" id="factura-contenido">
    <section class="factura-tabla">
      <table class="tabla-factura">
        <thead>
          <tr>
            <th>Servicio</th>
            <th>Descripción</th>
            <th>Costo (USD)</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Desarrollo Web (PHP + CSS)</td>
            <td>Creación completa del sitio SUCESOS y MÁS</td>
            <td>350.00</td>
          </tr>
          <tr>
            <td>Hosting (1 año)</td>
            <td>Servidor local con XAMPP o remoto</td>
            <td>50.00</td>
          </tr>
          <tr>
            <td>Dominio (1 año)</td>
            <td>sucesosymas.com</td>
            <td>25.00</td>
          </tr>
          <tr>
            <td>Servicio futuro (SEO, soporte)</td>
            <td>Mantenimiento y posicionamiento</td>
            <td>75.00</td>
          </tr>
          <tr class="total-row">
            <td colspan="2" class="total-label"><strong>Total</strong></td>
            <td class="total-value"><strong>500.00</strong></td>
          </tr>
        </tbody>
      </table>
    </section>

    <section class="factura-info">
      <p><strong>Fecha de emisión:</strong> <?php echo date("d/m/Y"); ?></p>
      <p><strong>Desarrolladores:</strong> Carlos Miranda y Mariam Harris — Proyecto académico profesional</p>
      <p><strong>Contacto:</strong> sucesosymas@gmail.com</p>
    </section>

    <div class="volver">
      <a href="index.php" class="btn-hero">⬅ Volver al inicio</a>
    </div>

    <div class="descargar-pdf">
      <button id="btnDescargarPDF" class="btn-hero">📥 Descargar PDF</button>
    </div>
  </main>

  <?php include __DIR__ . '/includes/footer.php'; ?>

  <script src="js/menu.js" defer></script>
  <script src="js/theme.js" defer></script>
  <script src="js/protect.js?v=<?php echo time(); ?>"></script>
  <script src="js/pdf-style.js" defer></script>

</body>
</html>
