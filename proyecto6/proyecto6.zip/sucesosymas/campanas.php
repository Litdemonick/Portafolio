<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <?php include 'includes/preload-theme.php'; ?>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gestión de Campañas Digitales - SUCESOS y MÁS</title>


</head>

<body>
  <?php include('includes/menu.php'); ?>
  <?php include('includes/header.php'); ?>

  <main class="servicio-detalle">

    <!-- HERO -->
    <section class="servicio-hero">
      <div class="overlay"></div>
      <img src="assets/servicios/campanas.jpg" alt="Gestión de Campañas Digitales" class="hero-bg">
      <div class="hero-content">
        <h1>Gestión de Campañas Digitales</h1>
        <p>Maximiza el alcance de tu marca con estrategias publicitarias inteligentes.</p>
      </div>
    </section>

    <!-- DESCRIPCIÓN -->
    <section class="servicio-descripcion">
      <h2>📈 Publicidad que genera impacto real</h2>
      <p>
        En <strong>SUCESOS y MÁS</strong> diseñamos, administramos y optimizamos campañas digitales para lograr resultados concretos.  
        Nuestro enfoque combina análisis, segmentación y creatividad para conectar marcas con audiencias reales.
      </p>

      <ul>
        <li>🎯 Campañas publicitarias en Meta Ads, Google Ads y TikTok Ads.</li>
        <li>📊 Análisis de rendimiento y optimización continua.</li>
        <li>💬 Creación de contenido y copys persuasivos.</li>
        <li>🔁 Remarketing, segmentación avanzada y estrategias de conversión.</li>
      </ul>
    </section>

    <!-- GALERÍA CON ENLACES -->
    <section class="servicio-galeria">
      <h2>📸 Casos y ejemplos</h2>
      <div class="galeria-grid">

        <a href="proyectos/proyecto1.php" class="galeria-item" title="Campaña Hotel Sol de Verano">
          <img src="assets/proyecto1b.jpg" alt="Campaña Hotel Sol de Verano">
          <div class="overlay-img">Hotel Sol de Verano</div>
        </a>

        <a href="proyectos/proyecto5.php" class="galeria-item" title="Campaña Verde Panamá">
          <img src="assets/proyecto5.jpg" alt="Campaña Verde Panamá">
          <div class="overlay-img">Verde Panamá</div>
        </a>

        <a href="proyectos/proyecto3.php" class="galeria-item" title="Publicidad Café Aromas">
          <img src="assets/proyecto3.jpg" alt="Publicidad Café Aromas">
          <div class="overlay-img">Café Aromas</div>
        </a>

      </div>
    </section>

    <!-- RESULTADOS -->
    <section class="servicio-resultados">
      <h2>📊 Resultados medibles y escalables</h2>
      <p>
        No solo creamos campañas, creamos estrategias que evolucionan.  
        Cada acción es analizada y mejorada para alcanzar el máximo rendimiento publicitario.
      </p>

      <div class="metricas">
        <div class="metrica">
          <h3>+300%</h3>
          <p>Retorno de inversión promedio (ROI)</p>
        </div>
        <div class="metrica">
          <h3>+150%</h3>
          <p>Incremento en leads calificados</p>
        </div>
        <div class="metrica">
          <h3>+80%</h3>
          <p>Reducción en costos por clic (CPC)</p>
        </div>
      </div>
    </section>

    <!-- CTA FINAL -->
    <section class="servicio-cta">
      <h2>¿Listo para impulsar tus resultados?</h2>
      <p>Optimiza tu inversión y lleva tus campañas digitales al siguiente nivel con nosotros.</p>
      <a href="contacto.php" class="btn-hero">🚀 Contáctanos</a>
    </section>

    <div class="volver">
      <a href="servicios.php" class="btn-volver">⬅ Volver a Servicios</a>
    </div>
  </main>

  <?php include('includes/footer.php'); ?>

  <script src="js/menu.js" defer></script>
  <script src="js/theme.js"></script>
  <script src="js/protect.js?v=<?php echo time(); ?>"></script>
</body>
</html>
