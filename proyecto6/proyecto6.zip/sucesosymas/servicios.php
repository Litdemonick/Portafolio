<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <?php include 'includes/preload-theme.php'; ?>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Servicios - SUCESOS y MÁS</title>


</head>

<body>
  <?php include('includes/menu.php'); ?>
  <?php include('includes/header.php'); ?>

  <main class="servicios-page">

    <!-- HERO -->
    <section class="servicios-hero">
      <div class="overlay"></div>
      <img src="assets/servicios/banner-servicios.jpg" alt="Servicios" class="hero-bg">
      <div class="hero-content">
        <h1>Nuestros Servicios</h1>
        <p>Soluciones integrales en comunicación, marketing y diseño para tu marca.</p>
      </div>
    </section>

    <!-- SECCIÓN INTRO -->
    <section class="servicios-intro">
      <h2>¿Qué ofrecemos?</h2>
      <p>
        En <strong>SUCESOS y MÁS</strong> combinamos creatividad, estrategia y tecnología para ofrecer 
        servicios diseñados a medida de tus necesidades. Cada proyecto es único, y cada resultado, medible.
      </p>
    </section>

    <!-- GRID DE SERVICIOS -->
    <section class="servicios-grid">

      <article class="servicio-card">
        <img src="assets/servicios/marketing.jpg" alt="Consultoría de Marketing" class="servicio-img">
        <div class="servicio-content">
          <h3>🧠 Consultoría de Marketing</h3>
          <p>Diseñamos estrategias digitales que posicionan tu marca y maximizan tus resultados.</p>
          <ul>
            <li>Análisis de mercado y audiencia</li>
            <li>Campañas en redes sociales</li>
            <li>Gestión de contenido y posicionamiento</li>
          </ul>
          <a href="marketing.php" class="btn-vermas">Ver más</a>
        </div>
      </article>

      <article class="servicio-card">
        <img src="assets/servicios/disenio.jpg" alt="Diseño Gráfico" class="servicio-img">
        <div class="servicio-content">
          <h3>🎨 Diseño Gráfico y Branding</h3>
          <p>Potencia la imagen de tu empresa con una identidad visual profesional y coherente.</p>
          <ul>
            <li>Diseño de logotipos</li>
            <li>Manual de marca</li>
            <li>Material publicitario</li>
          </ul>
          <a href="disenio.php" class="btn-vermas">Ver más</a>
        </div>
      </article>

      <article class="servicio-card">
        <img src="assets/servicios/campanas.jpg" alt="Gestión de Campañas" class="servicio-img">
        <div class="servicio-content">
          <h3>📊 Gestión de Campañas Digitales</h3>
          <p>Planeamos, ejecutamos y medimos campañas publicitarias efectivas en todas las plataformas.</p>
          <ul>
            <li>Google Ads y Meta Ads</li>
            <li>Análisis de rendimiento</li>
            <li>Optimización continua</li>
          </ul>
          <a href="campanas.php" class="btn-vermas">Ver más</a>
        </div>
      </article>

      <article class="servicio-card">
        <img src="assets/servicios/rrpp.jpg" alt="Relaciones Públicas" class="servicio-img">
        <div class="servicio-content">
          <h3>🤝 Relaciones Públicas</h3>
          <p>Gestionamos la comunicación institucional y la imagen pública de tu organización.</p>
          <ul>
            <li>Notas de prensa</li>
            <li>Eventos corporativos</li>
            <li>Gestión de reputación</li>
          </ul>
          <a href="rrpp.php" class="btn-vermas">Ver más</a>
        </div>
      </article>

      <article class="servicio-card">
        <img src="assets/servicios/audiovisual.jpg" alt="Producción Audiovisual" class="servicio-img">
        <div class="servicio-content">
          <h3>🎬 Producción Audiovisual</h3>
          <p>Creación de videos, fotografías y animaciones que comunican con impacto profesional.</p>
          <ul>
            <li>Spots publicitarios</li>
            <li>Videos para redes</li>
            <li>Animación 2D / 3D</li>
          </ul>
          <a href="audiovisual.php" class="btn-vermas">Ver más</a>
        </div>
      </article>

    </section>

    <!-- CTA FINAL CENTRADO -->
    <section class="servicios-cta">
      <h2>¿Listo para llevar tu marca al siguiente nivel?</h2>
      <p>Contáctanos hoy y descubre cómo podemos ayudarte a destacar en el mundo digital.</p>
      <a href="contacto.php" class="btn-hero">📩 Contáctanos</a>
    </section>

  </main>

  <?php include('includes/footer.php'); ?>

  <script src="js/menu.js" defer></script>
  <script src="js/theme.js"></script>
  
  <script src="js/protect.js?v=<?php echo time(); ?>"></script>
</body>
</html>
