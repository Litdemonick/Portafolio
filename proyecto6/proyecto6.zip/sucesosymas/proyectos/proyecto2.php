<!DOCTYPE html>
<?php require_once __DIR__ . '/../includes/init.php'; ?>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Portal Web Tienda FashionMix - SUCESOS y MÁS</title>

  <!-- Cargar tema -->
  <script>
    (function() {
      const theme = localStorage.getItem("theme") || "light";
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.id = "theme-style";
      link.href = theme === "dark" ? "../css/style-dark.css" : "../css/style-light.css";
      document.head.appendChild(link);
      document.documentElement.setAttribute("data-theme", theme);
    })();
  </script>
</head>

<body>
  <?php include __DIR__ . '/../includes/menu.php'; ?>

  <header class="proyecto-header">
    <div class="overlay-hero"></div>
    <img src="../assets/proyecto2.jpg" alt="Portal Web Tienda FashionMix" class="hero-bg">
    <div class="hero-content">
      <h1>Portal Web Tienda FashionMix</h1>
      <p>E-commerce moderno y dinámico para tienda de moda local</p>
    </div>
  </header>

  <main class="proyecto-main">
    <section class="descripcion">
      <h2>Descripción General</h2>
      <p>
        <strong>FashionMix</strong> necesitaba una tienda en línea moderna y atractiva para expandir su mercado más allá del local físico. 
        Se desarrolló un <em>portal web responsivo y optimizado</em> que permite la compra rápida, el filtrado de productos y la gestión de usuarios.
      </p>
      <p>
        El sitio fue construido con tecnologías web modernas, incorporando un sistema de carrito de compras, panel de administración y 
        pasarela de pago segura, lo que aumentó las ventas online en un <strong>70%</strong> durante los primeros tres meses.
      </p>
    </section>

    <section class="detalles">
      <h2>Detalles del Proyecto</h2>
      <ul>
        <li>🗓️ <strong>Duración:</strong> Enero - Marzo 2025</li>
        <li>🛍️ <strong>Cliente:</strong> Tienda FashionMix</li>
        <li>🎯 <strong>Objetivo:</strong> Digitalizar el negocio y aumentar las ventas por internet</li>
        <li>💻 <strong>Servicios ofrecidos:</strong> Diseño web, desarrollo front-end y back-end, SEO y marketing digital</li>
      </ul>
    </section>

    <section class="galeria">
      <h2>Galería del Proyecto</h2>
      <div class="imagenes">
        <img src="../assets/proyecto2a.jpg" alt="Diseño principal del portal web" class="galeria-img">
        <img src="../assets/proyecto2b.jpg" alt="Sección de productos y catálogo" class="galeria-img">
        <img src="../assets/proyecto2c.jpg" alt="Vista móvil del e-commerce FashionMix" class="galeria-img">
      </div>
    </section>

    <section class="resumen">
      <h2>Impacto y Resultados</h2>
      <p>
        El portal web permitió a <strong>FashionMix</strong> alcanzar nuevos clientes y mejorar su presencia digital. 
        Las métricas muestran un <em>crecimiento del 70% en ventas</em>, un <strong>incremento del 50%</strong> en tráfico orgánico y 
        una excelente tasa de retención gracias a su diseño visual atractivo y su sistema de notificaciones personalizadas.
      </p>
    </section>

    <div class="volver">
      <a href="../index.php" class="btn-hero">⬅ Volver al inicio</a>
    </div>
  </main>

  <?php include __DIR__ . '/../includes/footer.php'; ?>

  <script src="../js/menu.js" defer></script>
  <script src="../js/theme.js" defer></script>
  <script src="../js/protect.js?v=<?php echo time(); ?>"></script>
  <script src="../js/proyecto.js" defer></script>
</body>
</html>
