<!DOCTYPE html>
<?php require_once __DIR__ . '/../includes/init.php'; ?>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hotel Sol de Verano - SUCESOS y MÁS</title>

  <!-- Cargar tema -->
  <script>
    (function() {
      const theme = localStorage.getItem("theme") || "light";
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.id = "theme-style";
      link.href = theme === "dark" ? "../css/style-dark.css" : "../css/style-light.css";
      document.head.appendChild(link);
      document.documentElement.setAttribute("data-theme", theme);
    })();
  </script>
</head>

<body>
  <?php include __DIR__ . '/../includes/menu.php'; ?>

  <header class="proyecto-header">
    <div class="overlay-hero"></div>
    <img src="../assets/proyecto1.jpg" alt="Hotel Sol de Verano" class="hero-bg">
    <div class="hero-content">
      <h1>Hotel Sol de Verano</h1>
      <p>Campaña publicitaria integral — Verano 2025</p>
    </div>
  </header>

  <main class="proyecto-main">
    <section class="descripcion">
      <h2>Descripción General</h2>
      <p>
        <strong>Hotel Sol de Verano</strong> buscaba posicionarse como el destino más atractivo para turistas nacionales e internacionales durante la temporada alta. 
        Nuestro equipo diseñó una <em>campaña publicitaria integral</em> que combinó presencia digital, redes sociales y spots audiovisuales.
      </p>
      <p>
        Se implementó una estrategia SEO y contenido visual optimizado que logró aumentar el tráfico web en un 60% y las reservas online en un 45%.
      </p>
    </section>

    <section class="detalles">
      <h2>Detalles del Proyecto</h2>
      <ul>
        <li>📅 <strong>Duración:</strong> Junio - Agosto 2025</li>
        <li>🏝️ <strong>Ubicación:</strong> Bocas del Toro, Panamá</li>
        <li>🎯 <strong>Objetivo:</strong> Incrementar reservas y mejorar posicionamiento online</li>
        <li>💼 <strong>Servicios ofrecidos:</strong> Diseño gráfico, campañas digitales, fotografía y video</li>
      </ul>
    </section>

      <section class="galeria">
      <h2>Galería del Proyecto</h2>
      <div class="imagenes">
        <img src="../assets/proyecto1a.jpg" alt="Vista aérea del hotel" class="galeria-img">
        <img src="../assets/proyecto1b.jpg" alt="Diseño de cartel promocional" class="galeria-img">
        <img src="../assets/proyecto1c.jpg" alt="Sesión fotográfica de campaña" class="galeria-img">
      </div>
    </section>

      <!-- Contenedor del lightbox -->
  <div id="lightbox" class="lightbox">
    <span class="cerrar" id="cerrarLightbox">✖</span>
    <img class="lightbox-img" id="lightboxImg" src="" alt="">
  </div>

    <section class="resumen">
      <h2>Impacto y Resultados</h2>
      <p>
        La campaña generó un <strong>incremento del 45%</strong> en las reservas, 
        una tasa de interacción del 120% en redes sociales y permitió posicionar al hotel entre los 
        <em>5 destinos turísticos más visitados</em> en Panamá según TripAdvisor.
      </p>
    </section>

    <div class="volver">
      <a href="../index.php" class="btn-hero">⬅ Volver al inicio</a>
    </div>
  </main>

  <?php include __DIR__ . '/../includes/footer.php'; ?>

  <script src="../js/menu.js" defer></script>
  <script src="../js/theme.js" defer></script>
  <script src="../js/proyecto.js" defer></script>
  <script src="../js/protect.js?v=<?php echo time(); ?>"></script>
</body>
</html>
