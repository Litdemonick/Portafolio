<!DOCTYPE html>
<?php require_once __DIR__ . '/../includes/init.php'; ?>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Publicidad para Café Aromas - SUCESOS y MÁS</title>

  <!-- Cargar tema -->
  <script>
    (function() {
      const theme = localStorage.getItem("theme") || "light";
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.id = "theme-style";
      link.href = theme === "dark" ? "../css/style-dark.css" : "../css/style-light.css";
      document.head.appendChild(link);
      document.documentElement.setAttribute("data-theme", theme);
    })();
  </script>
</head>

<body>
  <?php include __DIR__ . '/../includes/menu.php'; ?>

  <header class="proyecto-header">
    <div class="overlay-hero"></div>
    <img src="../assets/proyecto3.jpg" alt="Publicidad para Café Aromas" class="hero-bg">
    <div class="hero-content">
      <h1>Publicidad para Café Aromas</h1>
      <p>Campaña audiovisual profesional para redes sociales</p>
    </div>
  </header>

  <main class="proyecto-main">
    <section class="descripcion">
      <h2>Descripción General</h2>
      <p>
        <strong>Café Aromas</strong> es una marca artesanal panameña que deseaba fortalecer su presencia en redes sociales y proyectar una imagen más profesional. 
        Diseñamos una <em>campaña audiovisual integral</em> enfocada en transmitir la esencia natural del producto y conectar emocionalmente con el público.
      </p>
      <p>
        La campaña incluyó la producción de videos promocionales, sesiones fotográficas de alta calidad y estrategias publicitarias en Instagram, Facebook y TikTok, 
        logrando aumentar la visibilidad de la marca y el reconocimiento del producto.
      </p>
    </section>

    <section class="detalles">
      <h2>Detalles del Proyecto</h2>
      <ul>
        <li>☕ <strong>Cliente:</strong> Café Aromas</li>
        <li>🗓️ <strong>Duración:</strong> Febrero - Abril 2025</li>
        <li>📍 <strong>Ubicación:</strong> Boquete, Chiriquí, Panamá</li>
        <li>🎯 <strong>Objetivo:</strong> Aumentar la visibilidad de la marca en redes sociales y mejorar la percepción de calidad</li>
        <li>💼 <strong>Servicios ofrecidos:</strong> Producción audiovisual, fotografía de producto, edición de video y gestión de redes</li>
      </ul>
    </section>

    <section class="galeria">
      <h2>Galería del Proyecto</h2>
      <div class="imagenes">
        <img src="../assets/proyecto3a.jpg" alt="Sesión fotográfica Café Aromas" class="galeria-img">
        <img src="../assets/proyecto3b.jpg" alt="Video promocional de producto" class="galeria-img">
        <img src="../assets/proyecto3c.jpg" alt="Campaña visual en redes sociales" class="galeria-img">
      </div>
    </section>

    <section class="resumen">
      <h2>Impacto y Resultados</h2>
      <p>
        Gracias a esta campaña, <strong>Café Aromas</strong> experimentó un aumento del <strong>85% en el alcance orgánico</strong> y un 
        <em>crecimiento del 60%</em> en interacciones dentro de los primeros dos meses. 
        La marca pasó de ser local a tener distribución nacional, consolidando su imagen como referente de café artesanal panameño.
      </p>
    </section>

    <div class="volver">
      <a href="../index.php" class="btn-hero">⬅ Volver al inicio</a>
    </div>
  </main>

  <?php include __DIR__ . '/../includes/footer.php'; ?>

  <script src="../js/menu.js" defer></script>
  <script src="../js/theme.js" defer></script>
  <script src="../js/protect.js?v=<?php echo time(); ?>"></script>
  <script src="../js/proyecto.js" defer></script>
</body>
</html>
