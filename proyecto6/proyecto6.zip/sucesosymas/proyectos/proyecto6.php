<!DOCTYPE html>
<?php require_once __DIR__ . '/../includes/init.php'; ?>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tienda Online de Artesanías - SUCESOS y MÁS</title>

  <!-- Cargar tema -->
  <script>
    (function() {
      const theme = localStorage.getItem("theme") || "light";
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.id = "theme-style";
      link.href = theme === "dark" ? "../css/style-dark.css" : "../css/style-light.css";
      document.head.appendChild(link);
      document.documentElement.setAttribute("data-theme", theme);
    })();
  </script>
</head>

<body>
  <?php include __DIR__ . '/../includes/menu.php'; ?>

  <header class="proyecto-header">
    <div class="overlay-hero"></div>
    <img src="../assets/proyecto6.jpg" alt="Tienda Online de Artesanías" class="hero-bg">
    <div class="hero-content">
      <h1>Tienda Online de Artesanías</h1>
      <p>E-commerce para productores locales con pasarela de pago segura</p>
    </div>
  </header>

  <main class="proyecto-main">
    <section class="descripcion">
      <h2>Descripción General</h2>
      <p>
        <strong>Artesanías Panamá</strong> es una plataforma digital creada para apoyar a los productores locales y promover el arte panameño. 
        Desarrollamos un <em>sitio web de comercio electrónico</em> que permite vender productos artesanales de forma segura, sencilla y atractiva.
      </p>
      <p>
        El proyecto incluyó diseño responsivo, sistema de usuarios, carrito de compras, y una <strong>pasarela de pago certificada</strong>, 
        garantizando confianza y accesibilidad tanto a compradores nacionales como internacionales.
      </p>
    </section>

    <section class="detalles">
      <h2>Detalles del Proyecto</h2>
      <ul>
        <li>🧵 <strong>Cliente:</strong> Asociación de Artesanos de Panamá</li>
        <li>🗓️ <strong>Duración:</strong> Mayo - Julio 2025</li>
        <li>📍 <strong>Ubicación:</strong> Panamá, Panamá</li>
        <li>🎯 <strong>Objetivo:</strong> Impulsar las ventas en línea y visibilidad de productos artesanales locales</li>
        <li>💼 <strong>Servicios ofrecidos:</strong> Desarrollo web, diseño UI/UX, integración de pagos y posicionamiento SEO</li>
      </ul>
    </section>

    <section class="galeria">
      <h2>Galería del Proyecto</h2>
      <div class="imagenes">
        <img src="../assets/proyecto6a.jpg" alt="Página principal de la tienda online" class="galeria-img">
        <img src="../assets/proyecto6b.jpg" alt="Catálogo de productos artesanales" class="galeria-img">
        <img src="../assets/proyecto6c.jpg" alt="Proceso de compra con pasarela segura" class="galeria-img">
      </div>
    </section>

    <section class="resumen">
      <h2>Impacto y Resultados</h2>
      <p>
        Con el lanzamiento de la tienda online, más de <strong>300 artesanos locales</strong> pudieron exhibir y vender sus productos digitalmente. 
        En los primeros meses, se registró un <strong>incremento del 65%</strong> en ventas y una <em>expansión internacional</em> del alcance del mercado.
        El proyecto también ayudó a fortalecer la economía creativa y fomentar el comercio justo en Panamá.
      </p>
    </section>

    <div class="volver">
      <a href="../index.php" class="btn-hero">⬅ Volver al inicio</a>
    </div>
  </main>

  <?php include __DIR__ . '/../includes/footer.php'; ?>

  <script src="../js/menu.js" defer></script>
  <script src="../js/theme.js" defer></script>
  <script src="../js/protect.js?v=<?php echo time(); ?>"></script>
  <script src="../js/proyecto.js" defer></script>
</body>
</html>
