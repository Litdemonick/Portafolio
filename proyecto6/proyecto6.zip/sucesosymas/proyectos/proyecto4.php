<!DOCTYPE html>
<?php require_once __DIR__ . '/../includes/init.php'; ?>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Diseño de Logo para TechPlus - SUCESOS y MÁS</title>

  <!-- Cargar tema -->
  <script>
    (function() {
      const theme = localStorage.getItem("theme") || "light";
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.id = "theme-style";
      link.href = theme === "dark" ? "../css/style-dark.css" : "../css/style-light.css";
      document.head.appendChild(link);
      document.documentElement.setAttribute("data-theme", theme);
    })();
  </script>
</head>

<body>
  <?php include __DIR__ . '/../includes/menu.php'; ?>

  <header class="proyecto-header">
    <div class="overlay-hero"></div>
    <img src="../assets/proyecto4.jpg" alt="Diseño de Logo para TechPlus" class="hero-bg">
    <div class="hero-content">
      <h1>Diseño de Logo para TechPlus</h1>
      <p>Creación de identidad corporativa moderna y profesional</p>
    </div>
  </header>

  <main class="proyecto-main">
    <section class="descripcion">
      <h2>Descripción General</h2>
      <p>
        <strong>TechPlus</strong>, una empresa emergente del sector tecnológico, buscaba una identidad visual sólida y moderna que reflejara 
        innovación, confianza y profesionalismo. 
        Nuestro equipo desarrolló un <em>diseño de logo y línea gráfica corporativa</em> adaptada a entornos digitales y de impresión.
      </p>
      <p>
        El proceso incluyó la creación de múltiples propuestas, test A/B con el público objetivo, y un manual de marca que define el uso correcto de colores, tipografía y versiones del logotipo.
      </p>
    </section>

    <section class="detalles">
      <h2>Detalles del Proyecto</h2>
      <ul>
        <li>💼 <strong>Cliente:</strong> TechPlus S.A.</li>
        <li>🗓️ <strong>Duración:</strong> Marzo - Mayo 2025</li>
        <li>🎨 <strong>Objetivo:</strong> Desarrollar una identidad visual coherente y profesional</li>
        <li>🧩 <strong>Servicios ofrecidos:</strong> Diseño de logo, branding, guía de estilo y aplicaciones corporativas</li>
      </ul>
    </section>

    <section class="galeria">
      <h2>Galería del Proyecto</h2>
      <div class="imagenes">
        <img src="../assets/proyecto4a.jpg" alt="Propuesta principal del logo TechPlus" class="galeria-img">
        <img src="../assets/proyecto4b.jpg" alt="Variaciones del logotipo" class="galeria-img">
        <img src="../assets/proyecto4c.jpg" alt="Aplicaciones del logo en papelería y redes" class="galeria-img">
      </div>
    </section>

    <section class="resumen">
      <h2>Impacto y Resultados</h2>
      <p>
        El nuevo diseño de identidad corporativa permitió a <strong>TechPlus</strong> establecer una marca fuerte y coherente visualmente. 
        La marca fue implementada en su sitio web, redes sociales y materiales impresos, generando una <strong>mayor confianza</strong> y 
        un <em>aumento del 40% en reconocimiento de marca</em> durante sus primeros seis meses de lanzamiento.
      </p>
    </section>

    <div class="volver">
      <a href="../index.php" class="btn-hero">⬅ Volver al inicio</a>
    </div>
  </main>

  <?php include __DIR__ . '/../includes/footer.php'; ?>

  <script src="../js/menu.js" defer></script>
  <script src="../js/theme.js" defer></script>
  <script src="../js/protect.js?v=<?php echo time(); ?>"></script>
  <script src="../js/proyecto.js" defer></script>
</body>
</html>
