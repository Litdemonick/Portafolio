<!DOCTYPE html>
<?php require_once __DIR__ . '/../includes/init.php'; ?>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Campaña Ambiental Verde Panamá - SUCESOS y MÁS</title>

  <!-- Cargar tema -->
  <script>
    (function() {
      const theme = localStorage.getItem("theme") || "light";
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.id = "theme-style";
      link.href = theme === "dark" ? "../css/style-dark.css" : "../css/style-light.css";
      document.head.appendChild(link);
      document.documentElement.setAttribute("data-theme", theme);
    })();
  </script>
</head>

<body>
  <?php include __DIR__ . '/../includes/menu.php'; ?>

  <header class="proyecto-header">
    <div class="overlay-hero"></div>
    <img src="../assets/proyecto5.jpg" alt="Campaña Ambiental Verde Panamá" class="hero-bg">
    <div class="hero-content">
      <h1>Campaña Ambiental Verde Panamá</h1>
      <p>Diseño gráfico y web para promover conciencia ecológica</p>
    </div>
  </header>

  <main class="proyecto-main">
    <section class="descripcion">
      <h2>Descripción General</h2>
      <p>
        <strong>Verde Panamá</strong> es una iniciativa ecológica enfocada en fomentar el cuidado del medio ambiente a nivel nacional. 
        Nuestro equipo diseñó una <em>campaña visual y digital</em> centrada en la educación ambiental, reforestación y reciclaje comunitario.
      </p>
      <p>
        Se crearon materiales gráficos, un sitio web informativo y contenido audiovisual para redes sociales, con el objetivo de inspirar 
        la acción ciudadana y fortalecer el compromiso ecológico entre jóvenes y adultos.
      </p>
    </section>

    <section class="detalles">
      <h2>Detalles del Proyecto</h2>
      <ul>
        <li>🌎 <strong>Cliente:</strong> Fundación Verde Panamá</li>
        <li>🗓️ <strong>Duración:</strong> Abril - Junio 2025</li>
        <li>📍 <strong>Ubicación:</strong> Ciudad de Panamá</li>
        <li>🎯 <strong>Objetivo:</strong> Concienciar sobre la importancia del reciclaje y la conservación ambiental</li>
        <li>💼 <strong>Servicios ofrecidos:</strong> Diseño gráfico, desarrollo web, marketing ecológico y gestión de redes sociales</li>
      </ul>
    </section>

    <section class="galeria">
      <h2>Galería del Proyecto</h2>
      <div class="imagenes">
        <img src="../assets/proyecto5a.jpg" alt="Diseño gráfico Verde Panamá" class="galeria-img">
        <img src="../assets/proyecto5b.jpg" alt="Sitio web de la campaña ecológica" class="galeria-img">
        <img src="../assets/proyecto5c.jpg" alt="Actividades de reforestación y reciclaje" class="galeria-img">
      </div>
    </section>

    <section class="resumen">
      <h2>Impacto y Resultados</h2>
      <p>
        La campaña <strong>Verde Panamá</strong> logró un <strong>alcance digital de más de 150,000 personas</strong> en redes sociales 
        y fomentó la participación activa de más de 2,000 voluntarios en jornadas de reforestación. 
        Además, el sitio web se posicionó entre los <em>más visitados</em> en temas ecológicos en Panamá durante su lanzamiento.
      </p>
    </section>

    <div class="volver">
      <a href="../index.php" class="btn-hero">⬅ Volver al inicio</a>
    </div>
  </main>

  <?php include __DIR__ . '/../includes/footer.php'; ?>

  <script src="../js/menu.js" defer></script>
  <script src="../js/theme.js" defer></script>
  <script src="../js/protect.js?v=<?php echo time(); ?>"></script>
  <script src="../js/proyecto.js" defer></script>
</body>
</html>
