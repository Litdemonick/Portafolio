<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <?php include 'includes/preload-theme.php'; ?>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Productos - SUCESOS y MÁS</title>

 
</head>

<body>
  <?php include('includes/menu.php'); ?>
  <?php include('includes/header.php'); ?>

  <main class="productos-page">

    <!-- HERO -->
    <section class="productos-hero">
      <div class="overlay"></div>
      <img src="assets/proyecto5.jpg" alt="Banner Productos" class="hero-bg">
      <div class="hero-content">
        <h1>Innovación y Creatividad</h1>
        <p>Descubre nuestros productos digitales pensados para destacar tu marca en el mundo moderno.</p>
      </div>
    </section>

    <!-- CATÁLOGO DE PRODUCTOS -->
    <section class="productos-catalogo">
      <h2>Catálogo de Soluciones</h2>
      <p class="catalogo-desc">
        En <strong>SUCESOS y MÁS</strong> ofrecemos una variedad de productos que combinan tecnología, diseño y estrategia para impulsar tu presencia digital.
      </p>

      <div class="productos-cards">
        <!-- Producto 1 -->
        <article class="producto-item">
          <div class="producto-img">
            <img src="assets/proyecto1.jpg" alt="Sitios Web Empresariales">
          </div>
          <div class="producto-info">
            <h3>🌐 Sitios Web Empresariales</h3>
            <p>Diseños profesionales, optimizados para SEO y adaptados a todos los dispositivos.</p>
            <a href="proyectos/proyecto1.php" class="btn-detalle">Ver más</a>
          </div>
        </article>

        <!-- Producto 2 -->
        <article class="producto-item reverse">
          <div class="producto-img">
            <img src="assets/proyecto2.jpg" alt="E-commerce y Tiendas Online">
          </div>
          <div class="producto-info">
            <h3>🛒 Tiendas Online</h3>
            <p>Plataformas seguras con pasarela de pago y gestión de inventario automatizada.</p>
            <a href="proyectos/proyecto6.php" class="btn-detalle">Ver más</a>
          </div>
        </article>

        <!-- Producto 3 -->
        <article class="producto-item">
          <div class="producto-img">
            <img src="assets/proyecto3.jpg" alt="Campañas Publicitarias">
          </div>
          <div class="producto-info">
            <h3>🎥 Producción Multimedia</h3>
            <p>Videos, spots y contenido visual de alto impacto para redes y plataformas digitales.</p>
            <a href="proyectos/proyecto3.php" class="btn-detalle">Ver más</a>
          </div>
        </article>

        <!-- Producto 4 -->
        <article class="producto-item reverse">
          <div class="producto-img">
            <img src="assets/proyecto4.jpg" alt="Branding y Diseño Gráfico">
          </div>
          <div class="producto-info">
            <h3>🎨 Branding y Diseño Gráfico</h3>
            <p>Identidades visuales únicas y memorables para destacar tu marca en cualquier medio.</p>
            <a href="proyectos/proyecto4.php" class="btn-detalle">Ver más</a>
          </div>
        </article>

        <!-- Producto 5 -->
        <article class="producto-item">
          <div class="producto-img">
            <img src="assets/proyecto5.jpg" alt="Campañas Sociales">
          </div>
          <div class="producto-info">
            <h3>🌿 Campañas Sociales</h3>
            <p>Proyectos creativos con impacto positivo, comunicación visual y estrategias ecológicas.</p>
            <a href="proyectos/proyecto5.php" class="btn-detalle">Ver más</a>
          </div>
        </article>
      </div>
    </section>

    <!-- CTA FINAL -->
    <section class="productos-contacto">
      <h2>¿Listo para transformar tu presencia digital?</h2>
      <p>Contáctanos y te ayudaremos a desarrollar el producto ideal para tu marca.</p>
      <a href="contacto.php" class="btn-hero">📞 Contáctanos Ahora</a>
    </section>
  </main>

  <?php include('includes/footer.php'); ?>

  <script src="js/menu.js" defer></script>
  <script src="js/theme.js"></script>
  <script src="js/protect.js?v=<?php echo time(); ?>"></script>
</body>
</html>
