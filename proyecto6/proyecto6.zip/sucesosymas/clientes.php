<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <?php include 'includes/preload-theme.php'; ?>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Clientes - SUCESOS y MÁS</title>

 
</head>

<body>
  <?php include('includes/menu.php'); ?>
  <?php include('includes/header.php'); ?>

  <main class="clientes-main">
    <section class="clientes-intro">
      <h2>Nuestros Clientes</h2>
      <p>En <strong>SUCESOS y MÁS</strong> trabajamos con marcas y organizaciones que confían en nuestra creatividad, estrategia y resultados comprobados.</p>
    </section>

    <section class="clientes-grid">

      <!-- Cliente 1 -->
      <a href="proyectos/proyecto1.php" class="cliente-card-link">
        <article class="cliente-card">
          <img src="assets/proyecto1.jpg" alt="Hotel Sol de Verano">
          <h3>Hotel Sol de Verano</h3>
          <p>Campaña publicitaria integral de verano 2025 — incremento del 45% en reservas online.</p>
        </article>
      </a>

      <!-- Cliente 2 -->
      <a href="proyectos/proyecto2.php" class="cliente-card-link">
        <article class="cliente-card">
          <img src="assets/proyecto2.jpg" alt="Tienda FashionMix">
          <h3>FashionMix</h3>
          <p>Portal web e-commerce moderno y dinámico para tienda de moda local — aumento del 70% en ventas.</p>
        </article>
      </a>

      <!-- Cliente 3 -->
      <a href="proyectos/proyecto3.php" class="cliente-card-link">
        <article class="cliente-card">
          <img src="assets/proyecto3.jpg" alt="Café Aromas">
          <h3>Café Aromas</h3>
          <p>Campaña audiovisual profesional para redes sociales — alcance orgánico creció un 85%.</p>
        </article>
      </a>

      <!-- Cliente 4 -->
      <a href="proyectos/proyecto4.php" class="cliente-card-link">
        <article class="cliente-card">
          <img src="assets/proyecto4.jpg" alt="TechPlus">
          <h3>TechPlus</h3>
          <p>Diseño de logotipo e identidad corporativa moderna para empresa tecnológica en expansión.</p>
        </article>
      </a>

      <!-- Cliente 5 -->
      <a href="proyectos/proyecto5.php" class="cliente-card-link">
        <article class="cliente-card">
          <img src="assets/proyecto5.jpg" alt="Verde Panamá">
          <h3>Verde Panamá</h3>
          <p>Campaña ambiental nacional con sitio web y diseño gráfico — más de 150,000 personas alcanzadas.</p>
        </article>
      </a>

      <!-- Cliente 6 -->
      <a href="proyectos/proyecto6.php" class="cliente-card-link">
        <article class="cliente-card">
          <img src="assets/proyecto6.jpg" alt="Artesanías Panamá">
          <h3>Artesanías Panamá</h3>
          <p>Tienda online para productores locales — pasarela de pago segura y crecimiento del 65% en ventas.</p>
        </article>
      </a>
    </section>

    <section class="clientes-cta">
      <h2>¿Quieres ser nuestro próximo cliente?</h2>
      <p>Contáctanos para impulsar tu marca con estrategias digitales, branding y desarrollo web de alta calidad.</p>
      <a href="contacto.php" class="btn-hero">📧 Contáctanos</a>
    </section>
  </main>

  <?php include('includes/footer.php'); ?>

  <script src="js/menu.js" defer></script>
  <script src="js/theme.js"></script>
  <script src="js/protect.js?v=<?php echo time(); ?>"></script>
</body>
</html>
