<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <?php include 'includes/preload-theme.php'; ?>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contacto - SUCESOS y MÁS</title>


</head>

<body>
  <?php include('includes/menu.php'); ?>
  <?php include('includes/header.php'); ?>

  <main class="contacto-main">
    <section class="contacto-hero">
      <h2>Contáctanos</h2>
      <p>¿Tienes un proyecto en mente? Escríbenos y te ayudaremos a hacerlo realidad.</p>
    </section>

    <section class="contacto-container">
      <div class="contacto-formulario">
        <h3>📩 Envíanos un mensaje</h3>

        <form class="contact-form" id="contactForm" action="#" method="post">
          <label for="nombre">Nombre completo:</label>
          <input type="text" id="nombre" name="nombre" placeholder="Tu nombre completo" required>

          <label for="email">Correo electrónico:</label>
          <input type="email" id="email" name="email" placeholder="correo@ejemplo.com" required>

          <label for="asunto">Asunto:</label>
          <input type="text" id="asunto" name="asunto" placeholder="Motivo de tu mensaje" required>

          <label for="mensaje">Mensaje:</label>
          <textarea id="mensaje" name="mensaje" rows="5" placeholder="Escribe tu mensaje aquí..." required></textarea>

          <button type="submit" class="btn-enviar">📤 Enviar Mensaje</button>
        </form>

        <!-- Mensaje de confirmación -->
        <div id="mensajeConfirmacion" class="mensaje-confirmacion"></div>
      </div>

      <div class="contacto-info">
        <h3>📍 Información de Contacto</h3>
        <ul>
          <li>📧 <strong>Email:</strong> sucesosymas@gmail.com</li>
          <li>📞 <strong>Teléfono:</strong> +507 6000-1234</li>
          <li>🏢 <strong>Oficina:</strong> Ciudad de Panamá, Panamá</li>
          <li>🕒 <strong>Horario:</strong> Lunes a Viernes — 8:00 a.m. a 6:00 p.m.</li>
        </ul>

        <div class="mapa">
          <img src="assets/mapa.jpg" alt="Ubicación de la empresa" />
          <p><em>Estamos ubicados en el corazón de la ciudad. ¡Visítanos!</em></p>
        </div>
      </div>
    </section>

    <section class="contacto-final">
      <h2>¿Listo para dar el siguiente paso?</h2>
      <p>En <strong>SUCESOS y MÁS</strong> transformamos ideas en resultados.  
      Permítenos acompañarte en tu crecimiento digital.</p>
      <a href="clientes.php" class="btn-hero">👥 Ver nuestros clientes</a>
    </section>
  </main>

  <?php include('includes/footer.php'); ?>

  <script src="js/menu.js" defer></script>
  <script src="js/theme.js"></script>
  <script src="js/protect.js?v=<?php echo time(); ?>"></script>

  <!-- Script del mensaje de confirmación -->
  <script>
    document.getElementById("contactForm").addEventListener("submit", function(e) {
      e.preventDefault(); // Evita recargar la página

      const mensaje = document.getElementById("mensajeConfirmacion");
      mensaje.textContent = "✅ Tu mensaje ha sido enviado correctamente.";
      mensaje.style.display = "block";
      mensaje.classList.add("visible");

      // Limpia los campos del formulario
      this.reset();

      // Oculta el mensaje luego de unos segundos
      setTimeout(() => {
        mensaje.classList.remove("visible");
        setTimeout(() => mensaje.style.display = "none", 500);
      }, 4000);
    });
  </script>
</body>
</html>
