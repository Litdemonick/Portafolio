document.addEventListener("DOMContentLoaded", () => {
  const toggleBtn = document.getElementById("toggle-theme");
  let themeLink = document.getElementById("theme-style");

  // ✅ Crear <link> si no existe
  if (!themeLink) {
    themeLink = document.createElement("link");
    themeLink.rel = "stylesheet";
    themeLink.id = "theme-style";
    document.head.appendChild(themeLink);
  }

  // ✅ Ruta raíz de estilos
  const basePath = "/sucesosymas/";

  // === Cambia el tema ===
  function setTheme(theme, updateButton = true) {
    const href =
      theme === "dark"
        ? `${basePath}css/style-dark.css`
        : `${basePath}css/style-light.css`;

    // Solo recarga si cambia
    if (!themeLink.href.endsWith(href)) {
      themeLink.href = href;
    }

    // Actualiza el texto del botón
    if (updateButton && toggleBtn) {
      toggleBtn.textContent =
        theme === "dark" ? "☀️ Modo Claro" : "🌙 Modo Oscuro";
    }

    // Guarda y aplica visualmente
    localStorage.setItem("theme", theme);
    document.documentElement.setAttribute("data-theme", theme);
  }

  // === Evento del botón ===
  if (toggleBtn) {
    toggleBtn.addEventListener("click", () => {
      const current = localStorage.getItem("theme") || "light";
      const newTheme = current === "dark" ? "light" : "dark";
      setTheme(newTheme);
    });
  }

  // === Aplicar al cargar ===
  const savedTheme = localStorage.getItem("theme") || "light";
  setTheme(savedTheme, true);

  // === Forzar texto correcto tras carga de CSS ===
  themeLink.addEventListener("load", () => {
    const activeTheme = localStorage.getItem("theme") || "light";
    if (toggleBtn) {
      toggleBtn.textContent =
        activeTheme === "dark" ? "☀️ Modo Claro" : "🌙 Modo Oscuro";
    }
  });
});
