// js/protect.js
(function(){
  // Evitar menú contextual (clic derecho)
  document.addEventListener('contextmenu', function(e){
    e.preventDefault();
  });

  // Evitar selección de texto y arrastre
  document.addEventListener('selectstart', function(e){ e.preventDefault(); });
  document.addEventListener('dragstart', function(e){ e.preventDefault(); });

  // Evitar copiar con Ctrl+C (no 100% recomendable bloquear todo, lo ponemos para capa extra)
  document.addEventListener('copy', function(e){ e.preventDefault(); });

  // Evitar atajos de teclado que abren devtools o ver fuente
  document.addEventListener('keydown', function(e){
    // teclas de función F12
    if (e.key === 'F12') { e.preventDefault(); e.stopPropagation(); }

    // Ctrl+Shift+I, Ctrl+Shift+C, Ctrl+Shift+J (devtools)
    if (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'C' || e.key === 'J')) {
      e.preventDefault(); e.stopPropagation();
    }

    // Ctrl+U (ver fuente), Ctrl+S (guardar página), Ctrl+P (imprimir)
    if (e.ctrlKey && (e.key === 'U' || e.key === 'S' || e.key === 'P')) {
      e.preventDefault(); e.stopPropagation();
    }

    // Ctrl+Shift+S / Ctrl+Shift+R (recargar en algunos navegadores)
    if (e.ctrlKey && e.shiftKey && (e.key === 'R' || e.key === 'S')) {
      e.preventDefault(); e.stopPropagation();
    }
  }, true);

  // Evitar inspección con tecla derecha del ratón y teclas del navegador (capa extra)
  // Nota: bibliotecas/usuarios avanzados pueden desactivar esto o abrir devtools de formas distintas.
})();
