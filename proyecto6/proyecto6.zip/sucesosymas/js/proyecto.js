// js/proyecto.js
document.addEventListener("DOMContentLoaded", () => {
  const imagenes = document.querySelectorAll(".galeria-img");
  const lightbox = document.createElement("div");
  const lightboxImg = document.createElement("img");
  const cerrarBtn = document.createElement("span");

  // Estructura del lightbox
  lightbox.classList.add("lightbox");
  lightboxImg.classList.add("lightbox-img");
  cerrarBtn.classList.add("cerrar");
  cerrarBtn.textContent = "✖";

  // Insertar elementos en el body
  lightbox.appendChild(lightboxImg);
  lightbox.appendChild(cerrarBtn);
  document.body.appendChild(lightbox);

  // Abrir imagen al hacer clic
  imagenes.forEach(img => {
    img.addEventListener("click", () => {
      lightbox.style.display = "flex";
      lightboxImg.src = img.src;
      lightboxImg.alt = img.alt;
    });
  });

  // Cerrar al hacer clic en el botón
  cerrarBtn.addEventListener("click", () => {
    lightbox.style.display = "none";
  });

  // Cerrar al hacer clic fuera de la imagen
  lightbox.addEventListener("click", (e) => {
    if (e.target === lightbox) {
      lightbox.style.display = "none";
    }
  });
});
