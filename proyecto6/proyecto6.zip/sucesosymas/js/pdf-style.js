document.addEventListener("DOMContentLoaded", () => {
  const btnPDF = document.getElementById("btnDescargarPDF");

  if (!btnPDF) return;

  btnPDF.addEventListener("click", async () => {
    btnPDF.style.transform = "scale(0.96)";
    setTimeout(() => (btnPDF.style.transform = "scale(1)"), 150);

    // === Fecha actual ===
    const fecha = new Date().toLocaleDateString("es-ES");

    // === Contenido HTML del PDF ===
    const contenidoHTML = `
      <div style="
        font-family: 'Poppins', sans-serif;
        background: #ffffff;
        color: #000000;
        width: 200mm;
        min-height: 260mm;
        margin: 0 auto;
        padding: 20mm;
        box-sizing: border-box;
      ">
        <div style="text-align:center; margin-bottom:25px;">
          <h1 style="color:#0078ff; font-size:26px; margin:0;">Factura - SUCESOS y MÁS</h1>
          <p style="font-size:14px; color:#333; margin:8px 0;">Emitida el ${fecha}</p>
          <hr style="border:1px solid #0078ff; width:80%; margin:auto;">
        </div>

        <table style="width:100%; border-collapse:collapse; margin-top:30px;">
          <thead>
            <tr style="background:#0078ff; color:#fff;">
              <th style="padding:10px; text-align:left;">Servicio</th>
              <th style="padding:10px; text-align:left;">Descripción</th>
              <th style="padding:10px; text-align:left;">Costo (USD)</th>
            </tr>
          </thead>
          <tbody>
            <tr style="background:#f9f9f9;">
              <td style="padding:10px; border:1px solid #ddd;">Desarrollo Web (PHP + CSS)</td>
              <td style="padding:10px; border:1px solid #ddd;">Creación completa del sitio SUCESOS y MÁS</td>
              <td style="padding:10px; border:1px solid #ddd; text-align:right;">350.00</td>
            </tr>
            <tr>
              <td style="padding:10px; border:1px solid #ddd;">Hosting (1 año)</td>
              <td style="padding:10px; border:1px solid #ddd;">Servidor local con XAMPP o remoto</td>
              <td style="padding:10px; border:1px solid #ddd; text-align:right;">50.00</td>
            </tr>
            <tr style="background:#f9f9f9;">
              <td style="padding:10px; border:1px solid #ddd;">Dominio (1 año)</td>
              <td style="padding:10px; border:1px solid #ddd;">sucesosymas.com</td>
              <td style="padding:10px; border:1px solid #ddd; text-align:right;">25.00</td>
            </tr>
            <tr>
              <td style="padding:10px; border:1px solid #ddd;">Servicio futuro (SEO, soporte)</td>
              <td style="padding:10px; border:1px solid #ddd;">Mantenimiento y posicionamiento</td>
              <td style="padding:10px; border:1px solid #ddd; text-align:right;">75.00</td>
            </tr>
            <tr style="background:#eaf5ff; font-weight:bold;">
              <td colspan="2" style="padding:10px; text-align:right; border:1px solid #0078ff;">Total</td>
              <td style="padding:10px; text-align:right; border:1px solid #0078ff;">500.00</td>
            </tr>
          </tbody>
        </table>

        <div style="
          background:#f2f8ff;
          border-radius:8px;
          padding:15px;
          margin-top:25px;
          font-size:14px;
          line-height:1.6;
        ">
          <p><strong>Fecha de emisión:</strong> ${fecha}</p>
          <p><strong>Desarrolladores:</strong> Carlos Miranda y Mariam Harris — Proyecto académico profesional</p>
          <p><strong>Contacto:</strong> sucesosymas@gmail.com</p>
        </div>

        <div style="text-align:center; margin-top:40px; color:#555; font-size:12px;">
          <hr style="border:0.5px solid #ccc; margin-bottom:8px;">
          <p>© 2025 SUCESOS y MÁS — Proyecto académico de Carlos Miranda y Mariam Harris</p>
        </div>
      </div>
    `;

    // === Crear contenedor temporal invisible ===
    const wrapper = document.createElement("div");
    wrapper.innerHTML = contenidoHTML;
    document.body.appendChild(wrapper);

    // === Opciones de exportación ===
    const opciones = {
      margin: 0,
      filename: `Factura_SucesosYMas_${new Date().toISOString().split("T")[0].replace(/-/g, "")}.pdf`,
      image: { type: "jpeg", quality: 1 },
      html2canvas: {
        scale: 2.2,
        useCORS: true,
        scrollY: 0,
        backgroundColor: "#ffffff",
      },
      jsPDF: {
        unit: "mm",
        format: [215.9, 279.4], // carta
        orientation: "portrait",
      },
    };

    // === Generar PDF ===
    await html2pdf().set(opciones).from(wrapper).save();

    // === Eliminar contenido temporal ===
    document.body.removeChild(wrapper);
  });
});
