// js/menu.js
document.addEventListener("DOMContentLoaded", () => {
  const menu = document.getElementById("sideMenu");
  const openBtn = document.getElementById("menuToggle");
  const closeBtn = document.getElementById("closeMenu");
  const overlay = document.getElementById("overlay");

  if (!menu || !openBtn || !closeBtn || !overlay) {
    console.warn("⚠️ Elementos del menú no encontrados.");
    return;
  }

  const openMenu = () => {
    menu.classList.add("open");
    overlay.classList.add("active");
    menu.setAttribute("aria-hidden", "false");
  };

  const closeMenu = () => {
    menu.classList.remove("open");
    overlay.classList.remove("active");
    menu.setAttribute("aria-hidden", "true");
  };

  const toggleMenu = () => {
    if (menu.classList.contains("open")) {
      closeMenu();
    } else {
      openMenu();
    }
  };

  // === Eventos ===
  openBtn.addEventListener("click", toggleMenu);
  closeBtn.addEventListener("click", closeMenu);
  overlay.addEventListener("click", closeMenu);

  // Tecla ESC
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeMenu();
  });
});
